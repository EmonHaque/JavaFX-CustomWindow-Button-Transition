package abstracts;

import java.util.List;

import helpers.Constants;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class View extends BorderPane {
    String header;
    public String icon;
    public String toolTip;
    public StackPane headerPane;
    public boolean isSeen;
    protected List<View> views;
    
    public View() {
        icon = getIcon();
        header = getHeader();
        toolTip = getTip();
        
        if (header != null) {
            headerPane = new StackPane();
            var text = new Text(header);
            text.setFont(Font.font(Font.getDefault().getFamily(), FontWeight.BOLD, 14));
            text.setFill(Color.DARKGRAY);
            StackPane.setAlignment(text, Pos.CENTER_LEFT);
            headerPane.getChildren().add(text);
            headerPane.setBorder(Constants.BottomLine);
            setTop(headerPane);
        }
        
        if(!isContainer()){
            setPadding(new Insets(10));
            setBackground(new Background(new BackgroundFill(Constants.BackgroundColor, new CornerRadii(5, false), null)));
        }
    }
    public boolean isContainer(){ return false; }
    protected String getIcon() {
        /* virtual */ return null;
    }

    protected String getHeader() {
        /* virtual */ return null;
    };

    protected String getTip() {
        /* virtual */ return null;
    };

    public void onFirstSight(){
        /* virtual */ isSeen = true;
    }
    public List<View> initialViews(){
        /* virtual */ return null;
    }
}

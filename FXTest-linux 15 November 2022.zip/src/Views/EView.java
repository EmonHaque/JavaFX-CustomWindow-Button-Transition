package Views;

import java.util.ArrayList;

import Views.ESubViews.EAView;
import Views.ESubViews.EBView;
import Views.ESubViews.ECView;
import abstracts.View;
import abstracts.ViewContainer;
import enums.NavOverlap;
import enums.NavPosition;
import helpers.Icons;

public class EView extends ViewContainer {
    View A;
    public EView() {
        super();
        // /super(NavPosition.LeftCenter, NavOverlap.None);
        A = new EAView();
        var B = new EBView();
        var C = new ECView();
        
        addView(A);
        addView(B);
        addView(C);
    }
    @Override
    public View initialView() {
        return A;
    }
    @Override
    protected String getIcon() {
        return Icons.ECircle;
    }

    @Override
    protected String getTip() {
        return "E View";
    }
    
}

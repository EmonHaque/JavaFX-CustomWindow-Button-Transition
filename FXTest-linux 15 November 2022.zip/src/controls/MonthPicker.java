package controls;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import helpers.Constants;
import helpers.Icons;
import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.TranslateTransition;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.skin.TextFieldSkin;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import javafx.util.Duration;

public class MonthPicker extends GridPane {
    int year, selectedYear, selectedMonth;
    Text yearText, selectedText;
    Popup popup;
    GridPane popupGrid;
    ActionButton forward, backward, open, close;
    TextField input;
    SVGIcon leftIcon;
    boolean isOpen;
    Label hintLabel;
    TranslateTransition moveHint;
    boolean isHintMoved;
    HBox selectedBox;
    DateTimeFormatter formatter;

    public MonthPicker(String hint) {
        leftIcon = new SVGIcon(Icons.Month);
    
        input = new TextField();
        input.setBackground(null);
        input.setDisable(true);
        input.setSkin(new TextFieldSkin(input) {
            {
                setTextFill(Color.WHITE);
            }
        });
        setHgrow(input, Priority.ALWAYS);
        open = new ActionButton(Icons.MonthPicker, 16, "show");
        addRow(0, leftIcon, input, open);
        hintLabel = new Label(hint);
        hintLabel.setTextFill(Color.GRAY);
        setMargin(hintLabel, new Insets(0,0,0,5));
        add(hintLabel,1,0);
        setBorder(Constants.BottomLine);

        moveHint = new TranslateTransition(Duration.millis(100));
        moveHint.setInterpolator(Interpolator.EASE_IN);
        moveHint.setNode(hintLabel);

        addPopup();
        addSelectedBox();
        moveHintUp();
        setMinHeight(40);
        setAlignment(Pos.BOTTOM_LEFT);

        close.setAction(this::removeSelected);
        open.setAction(this::togglePopup);
        input.setOnKeyPressed(this::onInputKey);
        selectedBox.setOnMouseClicked(e -> togglePopup());
        popup.setOnHidden(e -> isOpen = false);
        
        addEventHandler(MouseEvent.ANY, this::onMouseEvents);
    }

    void addPopup() {
        popupGrid = new GridPane();
        popupGrid.setVgap(10);
        popupGrid.setHgap(10);
        popupGrid.setBackground(new Background(new BackgroundFill(Constants.BackgroundColor, new CornerRadii(5, false), null)));
        popupGrid.setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5, 5, 5, 5, false), new BorderWidths(0.25))));
        popupGrid.setPadding(new Insets(10));
        popup = new Popup();
        popup.setAutoHide(true);
        addTopSection();
        addMonths();
        popup.getContent().add(popupGrid);
    }
    void addSelectedBox() {
        selectedText = new Text();
        selectedText.setFill(Color.WHITE);
        setSelected(LocalDate.now());
        var spacer = new Region();
        close = new ActionButton(Icons.CloseCircle, 16, "remove");
        selectedBox = new HBox(selectedText, spacer, close);
        HBox.setHgrow(spacer, Priority.ALWAYS);
        HBox.setMargin(selectedText, new Insets(0,0,0,5));
        selectedBox.setAlignment(Pos.CENTER_LEFT);
        selectedBox.setBackground(new Background(new BackgroundFill(Constants.BackgroundColorLight, null, null)));
        setMargin(selectedBox, new Insets(0,5,0,5));
        add(selectedBox, 1,0);

    }
    void setSelected(LocalDate date){
        formatter = DateTimeFormatter.ofPattern("MMMM, yyyy");
        selectedText.setText(formatter.format(date));
        selectedYear = date.getYear();
        selectedMonth = date.getMonthValue();
    }
    void onInputKey(KeyEvent e){
        if(e.getCode() != KeyCode.ENTER) return;
        var splits = input.getText().split("/");
        int year = Integer.parseInt(splits[1]);
        int month = Integer.parseInt(splits[0]);
        var date =  LocalDate.of(year, month, 1);

        this.year = year;
        yearText.setText(splits[1]);
        setSelected(date);
        var children = popupGrid.getChildren();
        for (var c : children){
            if(c instanceof MonthLabel label){
                if(label.getMonthNo() == selectedMonth)
                    label.setSelected(true);
                else if(label.isSelected)
                    label.setSelected(false);
            }
        }
        input.setDisable(true);
        selectedBox.setVisible(true);
    }
    void removeSelected(){
        input.setText("");
        selectedBox.setVisible(false);
        input.setDisable(false);
        input.requestFocus();

        year = LocalDate.now().getYear();
        yearText.setText(String.valueOf(year));
        var children = popupGrid.getChildren();
        for (var c : children) {
            if (c instanceof MonthLabel label)
                if(label.isSelected)
                    label.setSelected(false);
        }
    }
    void togglePopup(){
        if(!isOpen) {
            var point = input.localToScreen(0,0);
            popup.show(input, point.getX(), point.getY() + input.getHeight());
            isOpen = true;
        }
        else {
            popup.hide();
            isOpen = false;
        }
    }
    void onMouseEvents(MouseEvent e){
        if(moveHint.getStatus() == Animation.Status.RUNNING) return;
        if(e.getEventType() == MouseEvent.MOUSE_ENTERED) {
            setFocusColor();
            if(!selectedBox.isVisible() && input.getText().isEmpty()){
                if(!isHintMoved) moveHintUp();
                input.requestFocus();
            }
        }
        else if(e.getEventType() == MouseEvent.MOUSE_EXITED) {
            resetFocusColor();
            if(!selectedBox.isVisible() && input.getText().isEmpty()){
                if(isHintMoved) moveHintDown();
                leftIcon.requestFocus();
            }
        }
    }
    void addTopSection() {
        year = LocalDate.now().getYear();
        yearText = new Text(String.valueOf(year));
        yearText.setFont(Font.font(null, FontWeight.BOLD, 14));
        yearText.setFill(Color.WHITE);
        backward = new ActionButton(Icons.ScrollLeft, 18, "back");
        forward = new ActionButton(Icons.ScrollRight, 18, "forward");
        popupGrid.addRow(0, backward, yearText, forward);
        setColumnSpan(yearText, 2);
        setColumnIndex(forward, 3);

        GridPane.setHalignment(backward, HPos.LEFT);
        GridPane.setHalignment(yearText, HPos.CENTER);
        GridPane.setHalignment(forward, HPos.RIGHT);

        forward.setAction(this::increment);
        backward.setAction(this::decrement);
    }
    void addMonths() {
        int monthNo = 1;
        for (int row = 2; row < 5; row++){
            for (int col = 0; col < 4; col++){
                var label = new MonthLabel(monthNo);

                label.setOnMouseClicked(this::onMonthClicked);
                popupGrid.add(label, col, row);
                monthNo++;
                if(monthNo == selectedMonth) label.setSelected(true);
            }
        }
    }
    void increment(){
        year++;
        yearText.setText(String.valueOf(year));
        resetSelectedLabel();
    }
    void decrement(){
        year--;
        yearText.setText(String.valueOf(year));
        resetSelectedLabel();
    }
    void resetSelectedLabel(){
        var children = popupGrid.getChildren();
        if(year == selectedYear){
            for (var c : children){
                if(c instanceof MonthLabel label){
                    if(label.getMonthNo() == selectedMonth)
                        label.setSelected(true);
                }
            }
        }else{
            for (var c : children){
                if(c instanceof MonthLabel label){
                    if(label.isSelected)
                        label.setSelected(false);
                }
            }
        }
    }
    void setFocusColor(){
        leftIcon.setFill(Color.CORNFLOWERBLUE);
        //line.setBorder(new Border(new BorderStroke(Color.CORNFLOWERBLUE, Color.TRANSPARENT, Color.TRANSPARENT,Color.TRANSPARENT, BorderStrokeStyle.SOLID, BorderStrokeStyle.NONE,BorderStrokeStyle.NONE,BorderStrokeStyle.NONE, null, null, null)));
    }
    void resetFocusColor(){
        leftIcon.setFill(Color.LIGHTBLUE);
        //line.setBorder(new Border(new BorderStroke(Color.LIGHTBLUE, Color.TRANSPARENT, Color.TRANSPARENT,Color.TRANSPARENT, BorderStrokeStyle.SOLID, BorderStrokeStyle.NONE,BorderStrokeStyle.NONE,BorderStrokeStyle.NONE, null, null, null)));
    }
    void moveHintUp(){
        moveHint.setByY(-20);
        moveHint.setByX(-5);
        moveHint.play();
        isHintMoved = true;
    }
    void moveHintDown(){
        moveHint.setByY(20);
        moveHint.setByX(5);
        moveHint.play();
        isHintMoved = false;
    }
    void onMonthClicked(MouseEvent e){
        var month = (MonthLabel)e.getSource();
        setSelected(LocalDate.of(year, month.getMonthNo(), 1));
        month.setSelected(true);
        if(!selectedBox.isVisible()){
            moveHintUp();
            moveHint.setOnFinished(ev -> {
                selectedBox.setVisible(true);
                moveHint.setOnFinished(null);
            });
        }

        var children = popupGrid.getChildren();
        for (var c : children){
            if(c instanceof MonthLabel label){
                if(label == month) continue;
                if(label.isSelected){
                    label.setSelected(false);
                }
            }
        }
        popup.hide();
    }
}
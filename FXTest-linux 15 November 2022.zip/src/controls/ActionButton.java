package controls;
import interfaces.IExecute;
import javafx.animation.Animation;
import javafx.animation.FillTransition;
import javafx.geometry.Point2D;
import javafx.scene.control.Button;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.SVGPath;
import javafx.util.Duration;

public class ActionButton extends Button {
    SVGPath path;
    FillTransition anim;
    Tooltip toolTip;
    boolean isActive;
    IExecute executor;
    public ActionButton(String icon, double size, String tip) {
        setBackground(new Background(new BackgroundFill(Color.TRANSPARENT, null, null)));
        setMinSize(size,size);
        setMaxSize(size,size);
        setPrefSize(size,size);
        addEventHandler(MouseEvent.ANY, this::handleState);

        path = new SVGPath();
        path.setContent(icon);
        path.setFill(Color.WHITE);
        double newSize = size - 4;
        path.setScaleX(newSize / path.prefWidth(-1));
        path.setScaleY(newSize / path.prefHeight(-1));
        anim = new FillTransition(Duration.millis(300));
        anim.setShape(path);
        toolTip = new Tooltip(tip);
        setGraphic(path);
        setTooltip(toolTip);
    }
    void animate(Color color){
        if(anim.getStatus() == Animation.Status.RUNNING) anim.stop();
        anim.setToValue(color);
        anim.play();
    }
    void handleState(MouseEvent e){
        if(isActive) return;
        if(e.getEventType() == MouseEvent.MOUSE_ENTERED){
            animate(Color.CORAL);
        }
        else if(e.getEventType() == MouseEvent.MOUSE_PRESSED){
            animate(Color.RED);
        }
        else if(e.getEventType() == MouseEvent.MOUSE_RELEASED){
            if(contains(new Point2D(e.getX(), e.getY()))){
                animate(Color.CORAL);
                if(executor != null) executor.execute();
            }
        }
        else if (e.getEventType() == MouseEvent.MOUSE_EXITED){
            animate(Color.WHITE);
        }
    }
    public void setAction(IExecute executor){
        this.executor = executor;
    }
    public void setIcon(String icon){
        path.setContent(icon);
    }
    public void setTip(String tip){
        toolTip.setText(tip);
    }
    public void setActive(boolean value){
        isActive = value;
        if(isActive) animate(Color.CORNFLOWERBLUE);
        else animate(Color.WHITE);
    }
}

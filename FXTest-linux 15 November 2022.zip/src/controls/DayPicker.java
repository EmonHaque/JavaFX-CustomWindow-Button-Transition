package controls;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import enums.CalendarState;
import helpers.Constants;
import helpers.Icons;
import javafx.animation.Interpolator;
import javafx.animation.TranslateTransition;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.skin.TextFieldSkin;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import javafx.util.Duration;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

public class DayPicker extends GridPane {
    Popup popup;
    GridPane popupGrid, headerContainer, dayMonthYearContainer, dayNameContainer;
    TextField input;
    Text headerText, selectedText;
    SVGIcon leftIcon;
    boolean isOpen, isLoaded;
    Label hintLabel;
    TranslateTransition moveHint;
    boolean isHintMoved;
    HBox selectedBox;
    LocalDate currentDate;
    LocalDate today = LocalDate.now();
    DateTimeFormatter formatter;
    ActionButton open, close, back, forward;
    CalendarState currentState;
    int floorYear, capYear;
    public ObjectProperty<LocalDate> selectedDate, startDate, endDate;

    public DayPicker() {
        selectedDate = new SimpleObjectProperty<>();
        startDate = new SimpleObjectProperty<>();
        endDate = new SimpleObjectProperty<>();

        leftIcon = new SVGIcon(Icons.Month);

        input = new TextField();
        input.setBackground(null);
        input.setDisable(true);
        input.setSkin(new TextFieldSkin(input) {
            {
                setTextFill(Color.WHITE);
            }
        });

        setHgrow(input, Priority.ALWAYS);
        open = new ActionButton(Icons.MonthPicker, 16, "show");
        addRow(0, leftIcon, input, open);
        hintLabel = new Label("Date");
        hintLabel.setTextFill(Color.GRAY);
        setMargin(hintLabel, new Insets(0, 0, 0, 5));
        add(hintLabel, 1, 0);
        setBorder(Constants.BottomLine);

        moveHint = new TranslateTransition(Duration.millis(100));
        moveHint.setInterpolator(Interpolator.EASE_IN);
        moveHint.setNode(hintLabel);

        addSelectedBox();
        addPopup();

        moveHintUp();
        setMinHeight(40);
        setAlignment(Pos.BOTTOM_LEFT);

        close.setAction(this::removeSelected);
        open.setAction(this::togglePopup);
        input.setOnKeyPressed(this::onInputKey);
        selectedBox.setOnMouseClicked(e -> togglePopup());
        popup.setOnHidden(e -> isOpen = false);

        // addEventHandler(MouseEvent.ANY, this::onMouseEvents);

        selectedDate.addListener((obs, oldValue, newValue) -> {
            if (newValue != null) {
                if (!isLoaded && !currentDate.isEqual(newValue)) {
                    addDays(newValue);
                    checkDateValidity();
                    isLoaded = true;
                }
                currentDate = newValue;
                setSelected(newValue);

            }
        });
        popup.setOnShowing(e -> {
            if (selectedDate.get() != null) {
                if (!selectedDate.get().isEqual(currentDate)) {
                    currentDate = selectedDate.get();
                    addDays(currentDate);
                    checkDateValidity();
                }
            }
            if (currentState != CalendarState.Day) {
                currentState = CalendarState.Day;
                addDays(currentDate);
                checkDateValidity();
            }
        });
    }

    void addPopup() {
        popupGrid = new GridPane();
        popupGrid.setBackground(new Background(new BackgroundFill(Constants.BackgroundColor, new CornerRadii(5, false), null)));
        popupGrid.setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5, 5, 5, 5, false), new BorderWidths(0.25))));
        popupGrid.setPadding(new Insets(10));
        popup = new Popup();
        popup.setAutoHide(true);

        initializeDayContainer();
        addHeader();
        if (selectedDate.get() == null) {
            currentDate = LocalDate.now();
            selectedDate.set(currentDate);
            addDays(currentDate);
            setSelected(currentDate);
        }
        else
            addDays(selectedDate.get());

        popup.getContent().add(popupGrid);
    }

    void addHeader() {
        headerText = new Text("Some Text");
        headerText.setFill(Color.WHITE);
        headerText.setFont(Font.font(null, FontWeight.BOLD, -1));

        back = new ActionButton(Icons.ScrollLeft, 16, "back");
        forward = new ActionButton(Icons.ScrollRight, 16, "forward");
        back.setAction(this::decrease);
        forward.setAction(this::increase);

        headerContainer = new GridPane();
        headerContainer.addColumn(0, back);
        headerContainer.addColumn(1, headerText);
        headerContainer.addColumn(2, forward);
        GridPane.setHgrow(headerText, Priority.ALWAYS);
        GridPane.setHalignment(headerText, HPos.CENTER);
        popupGrid.addRow(0, headerContainer);
        GridPane.setMargin(headerContainer, new Insets(0, 0, 5, 0));
        headerContainer.setBorder(Constants.BottomLine);
        headerContainer.setPadding(new Insets(0, 0, 5, 0));
        headerText.addEventHandler(MouseEvent.MOUSE_PRESSED, this::resetState);
    }

    void initializeDayContainer() {
        String[] days = { "Sat", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri" };
        dayMonthYearContainer = new GridPane();
        dayNameContainer = new GridPane();
        for (int i = 0; i < 7; i++) {
            var dayName = new Text(days[i]);
            dayName.setFill(Color.WHITE);
            dayName.setFont(Font.font(null, FontWeight.BOLD, -1));
            dayNameContainer.addColumn(i, dayName);
            GridPane.setHgrow(dayName, Priority.ALWAYS);
            GridPane.setHalignment(dayName, HPos.CENTER);
        }
        dayNameContainer.setBorder(Constants.BottomLine);
        dayNameContainer.setPadding(new Insets(0, 0, 2.5, 0));
        GridPane.setMargin(dayMonthYearContainer, new Insets(5, 0, 0, 0));
        dayNameContainer.setHgap(5);

        popupGrid.addRow(2, dayMonthYearContainer);
        dayMonthYearContainer.setHgap(5);
        dayMonthYearContainer.setVgap(5);
    }

    void onDayClicked(MouseEvent e) {
        var day = (DayLabel) e.getSource();
        currentDate = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), day.getDayNo());
        selectedDate.set(currentDate);
        setSelected(currentDate);
        popup.hide();
        isOpen = false;
        addDays(currentDate);
    }

    void onMonthClicked(MouseEvent e) {
        var month = (MonthLabel) e.getSource();
        currentDate = LocalDate.of(currentDate.getYear(), month.getMonthNo(), 1);
        addDays(currentDate);
        checkDateValidity();
    }

    void onYearClicked(MouseEvent e) {
        var year = (YearLabel) e.getSource();
        currentDate = LocalDate.of(year.getYearNo(), 1, 1);
        addMonths();
        checkDateValidity();
    }

    void increase() {
        switch (currentState) {
            case Day:
                currentDate = currentDate.plusMonths(1);
                currentDate = LocalDate.of(currentDate.getYear(), currentDate.getMonthValue(), currentDate.lengthOfMonth());
                addDays(currentDate);
                break;
            case Month:
                currentDate = currentDate.plusYears(1);
                currentDate = LocalDate.of(currentDate.getYear(), 12, 31);
                addMonths();
                break;
            case Year:
                floorYear = currentDate.getYear();
                currentDate = currentDate.plusYears(12);
                capYear = currentDate.getYear();
                addYears();
                break;
        }
        checkDateValidity();
    }

    void decrease() {
        switch (currentState) {
            case Day:
                currentDate = currentDate.minusMonths(1);
                currentDate = LocalDate.of(currentDate.getYear(), currentDate.getMonthValue(), 1);
                addDays(currentDate);
                break;
            case Month:
                currentDate = currentDate.minusYears(1);
                currentDate = LocalDate.of(currentDate.getYear(), 1, 31);
                addMonths();
                break;
            case Year:
                capYear = currentDate.getYear();
                currentDate = currentDate.minusYears(12);
                floorYear = currentDate.getYear();
                addYears();
                break;
        }
        checkDateValidity();
    }

    void resetState(MouseEvent e) {
        switch (currentState) {
            case Day:
                addMonths();
                break;
            case Month:
                addYears();
                break;
            case Year:
                currentDate = selectedDate == null ? LocalDate.now() : selectedDate.get();
                addDays(currentDate);
                break;
        }
        checkDateValidity();
    }

    void checkDateValidity() {
        if (endDate == null && startDate == null)
            return;
        if (currentState == CalendarState.Day) {
            if (currentDate.getMonthValue() == endDate.get().getMonthValue() && currentDate.getYear() == endDate.get().getYear()) {
                forward.setDisable(true);
            }
            else
                forward.setDisable(false);
            if (currentDate.getMonthValue() == startDate.get().getMonthValue() && currentDate.getYear() == startDate.get().getYear()) {
                back.setDisable(true);
            }
            else
                back.setDisable(false);
        }
        else if (currentState == CalendarState.Month) {
            if (currentDate.getYear() < endDate.get().getYear())
                forward.setDisable(false);
            else
                forward.setDisable(true);

            if (currentDate.getYear() > startDate.get().getYear())
                back.setDisable(false);
            else
                back.setDisable(true);
        }
        else {
            if (capYear < endDate.get().getYear())
                forward.setDisable(false);
            else
                forward.setDisable(true);

            if (floorYear > startDate.get().getYear())
                back.setDisable(false);
            else
                back.setDisable(true);
        }
    }

    void addDays(LocalDate currentDate) {
        currentState = CalendarState.Day;
        formatter = DateTimeFormatter.ofPattern("MMMM, yyyy");
        headerText.setText(formatter.format(currentDate));
        dayMonthYearContainer.getChildren().clear();

        var numberOfDays = currentDate.lengthOfMonth();
        var currentDay = 1;
        var dayOfWeek = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), currentDay).getDayOfWeek().getValue();
        int newDayOfWeek = 0;
        switch (dayOfWeek) {
            case 6:
                newDayOfWeek = 0;
                break;
            case 7:
                newDayOfWeek = 1;
                break;
            default:
                newDayOfWeek = dayOfWeek + 1;
                break;
        }

        int requiredRows = 1;
        var remainingDays = numberOfDays - 7 + newDayOfWeek;
        requiredRows += remainingDays / 7;
        var remainder = remainingDays % 7;
        if (remainder != 0)
            requiredRows++;

        if (!popupGrid.getChildren().contains(dayNameContainer))
            popupGrid.addRow(1, dayNameContainer);

        var isInSelectedMonth = selectedDate.get() != null ? (selectedDate.get().getMonthValue() == currentDate.getMonthValue() && selectedDate.get().getYear() == currentDate.getYear()) : false;

        for (int i = 0; i < requiredRows; i++) {
            int k = currentDay == 1 ? newDayOfWeek : 0;
            for (int j = k; j < 7; j++) {
                if (currentDay < numberOfDays + 1) {
                    var day = new DayLabel(currentDay);
                    day.setOnMouseClicked(this::onDayClicked);

                    if (isInSelectedMonth) {
                        if (selectedDate.get() != null) {
                            if (currentDay == selectedDate.get().getDayOfMonth())
                                day.setSelected(true);
                        }
                    }
                    if (currentDay == today.getDayOfMonth() && currentDate.getMonthValue() == today.getMonthValue() && currentDate.getYear() == today.getYear()) {
                        day.setToday(true);
                    }

                    if (startDate.get() != null && endDate.get() != null) {
                        if (currentDate.getMonthValue() == startDate.get().getMonthValue() && currentDate.getYear() == startDate.get().getYear()) {
                            if (currentDay < startDate.get().getDayOfMonth())
                                day.setVisible(false);
                        }
                        if (currentDate.getMonthValue() == endDate.get().getMonthValue() && currentDate.getYear() == endDate.get().getYear()) {
                            if (currentDay > endDate.get().getDayOfMonth())
                                day.setVisible(false);
                        }
                    }
                    dayMonthYearContainer.add(day, j, i);
                    currentDay++;
                }
            }
        }
    }

    void addMonths() {
        currentState = CalendarState.Month;
        formatter = DateTimeFormatter.ofPattern("yyyy");
        headerText.setText(formatter.format(currentDate));
        dayMonthYearContainer.getChildren().clear();
        popupGrid.getChildren().remove(dayNameContainer);

        int currentMonth = 1;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 4; j++) {
                var month = new MonthLabel(currentMonth);
                month.setOnMouseClicked(this::onMonthClicked);
                if (selectedDate.get() != null) {
                    if (currentMonth == selectedDate.get().getMonthValue() && currentDate.getYear() == selectedDate.get().getYear()) {
                        month.setSelected(true);
                    }
                }
                if (currentMonth == today.getMonth().getValue() && currentDate.getYear() == today.getYear()) {
                    month.setThisMonth(true);
                }
                if (startDate.get() != null && endDate.get() != null) {
                    if (currentDate.getYear() == startDate.get().getYear()) {
                        if (currentMonth < startDate.get().getMonth().getValue())
                            month.setVisible(false);
                    }
                    if (currentDate.getYear() == endDate.get().getYear()) {
                        if (currentMonth > endDate.get().getMonth().getValue())
                            month.setVisible(false);
                    }
                }
                dayMonthYearContainer.add(month, j, i);
                currentMonth++;
            }
        }
    }

    void addYears() {
        currentState = CalendarState.Year;
        capYear = currentDate.getYear();
        int currentYear = currentDate.getYear() - 11;
        floorYear = currentYear;
        headerText.setText(currentYear + " - " + currentDate.getYear());
        dayMonthYearContainer.getChildren().clear();
        popupGrid.getChildren().remove(dayNameContainer);

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 4; j++) {
                var year = new YearLabel(currentYear);
                year.setOnMouseClicked(this::onYearClicked);
                if (selectedDate.get() != null) {
                    if (currentYear == selectedDate.get().getYear()) {
                        year.setSelected(true);
                    }
                }
                if (currentYear == today.getYear()) {
                    year.setThisYear(true);
                }
                if (startDate.get() != null && endDate.get() != null) {
                    if (currentYear < startDate.get().getYear())
                        year.setVisible(false);
                    if (currentYear > endDate.get().getYear())
                        year.setVisible(false);
                }
                dayMonthYearContainer.add(year, j, i);
                currentYear++;
            }
        }
    }

    void addSelectedBox() {
        selectedText = new Text();
        selectedText.setFill(Color.WHITE);
        var spacer = new Region();
        close = new ActionButton(Icons.CloseCircle, 16, "remove");
        selectedBox = new HBox(selectedText, spacer, close);
        HBox.setHgrow(spacer, Priority.ALWAYS);
        HBox.setMargin(selectedText, new Insets(0, 0, 0, 5));
        selectedBox.setAlignment(Pos.CENTER_LEFT);
        selectedBox.setBackground(new Background(new BackgroundFill(Constants.BackgroundColorLight, null, null)));
        setMargin(selectedBox, new Insets(0, 5, 0, 5));
        add(selectedBox, 1, 0);
    }

    void setSelected(LocalDate date) {
        formatter = DateTimeFormatter.ofPattern("dd MMMM yyyy");
        if (!selectedBox.isVisible()) {
            input.setDisable(false);
            selectedBox.setVisible(true);
        }
        selectedText.setText(formatter.format(date));
    }

    void onInputKey(KeyEvent e) {
        if (isOpen) {
            popup.hide();
            isOpen = false;
        }
        if (e.getCode() != KeyCode.ENTER)
            return;

        formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate inputDate = null;
        boolean isSuccess = false;
        try {
            inputDate = LocalDate.parse(input.getText(), formatter);
            if (startDate.get() != null) {
                if (inputDate.isEqual(startDate.get()) || inputDate.isAfter(startDate.get())) {
                    isSuccess = true;
                }
            }
            else {
                isSuccess = true;
            }
            if (isSuccess) {
                if (endDate.get() != null) {
                    if (inputDate.isEqual(endDate.get()) || inputDate.isBefore(endDate.get())) {
                        isSuccess = true;
                    }
                    else
                        isSuccess = false;
                }
                else {
                    isSuccess = true;
                }
            }

        }
        catch (Exception ex) {
            isSuccess = false;
        }
        if (isSuccess) {
            selectedDate.set(inputDate);
            input.setDisable(true);
            selectedBox.setVisible(true);
            addDays(currentDate);
            checkDateValidity();
        }
    }

    void removeSelected() {
        selectedDate.set(null);
        input.setText("");
        selectedBox.setVisible(false);
        input.setDisable(false);
        input.requestFocus();
        addDays(currentDate);
    }

    void togglePopup() {
        if (!isOpen) {
            var point = input.localToScreen(0, 0);
            popup.show(input, point.getX(), point.getY() + input.getHeight());
            isOpen = true;
        }
        else {
            popup.hide();
            isOpen = false;
        }
    }

    // void onMouseEvents(MouseEvent e) {
    // if (moveHint.getStatus() == Animation.Status.RUNNING)
    // return;
    // if(e.getEventType() == MouseEvent.MOUSE_ENTERED) {
    // setFocusColor();
    // if(!selectedBox.isVisible() && input.getText().isEmpty()){
    // if(!isHintMoved) moveHintUp();
    // input.requestFocus();
    // }
    // }
    // else if(e.getEventType() == MouseEvent.MOUSE_EXITED) {
    // resetFocusColor();
    // if(!selectedBox.isVisible() && input.getText().isEmpty()){
    // if(isHintMoved) moveHintDown();
    // leftIcon.requestFocus();
    // }
    // }
    // }

    void moveHintUp() {
        moveHint.setByY(-20);
        moveHint.setByX(-5);
        moveHint.play();
        isHintMoved = true;
    }

    void moveHintDown() {
        moveHint.setByY(20);
        moveHint.setByX(5);
        moveHint.play();
        isHintMoved = false;
    }
}

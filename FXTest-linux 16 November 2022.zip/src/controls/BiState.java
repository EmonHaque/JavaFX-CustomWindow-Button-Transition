package controls;

import helpers.Icons;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.VPos;
import javafx.scene.Group;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class BiState extends GridPane {

    private SVGIcon checked, unchecked;
    private Text textLabel;
    private Group iconGroup;
    private BooleanProperty checkedProperty;

    public BiState(boolean isChecked) {
        checked = new SVGIcon(Icons.CheckCircle);
        unchecked = new SVGIcon(Icons.CloseCircle);
        checked.setFill(Color.LIGHTGREEN);
        unchecked.setFill(Color.LIGHTCORAL);

        iconGroup = new Group(checked, unchecked);
        addColumn(0, iconGroup);
        setValignment(iconGroup, VPos.CENTER);

        checkedProperty = new SimpleBooleanProperty();
        
        checkedProperty.addListener(this::onCheckedChanged);
        checkedProperty.set(isChecked);

        // bound property cannot be modified!
        setOnMouseClicked(e -> checkedProperty.set(!checkedProperty.get()));
    }

    public BiState(boolean isChecked, String text) {
        this(isChecked);
        textLabel = new Text(text);
        textLabel.setFill(Color.WHITE);
        addColumn(1, textLabel);
        setValignment(textLabel, VPos.CENTER);
        setHgap(5);
    }

    private void onCheckedChanged(ObservableValue<?> obs, boolean oldValue, boolean newValue) {
        if (newValue) {
            unchecked.setVisible(false);
            checked.setVisible(true);
        }
        else {
            checked.setVisible(false);
            unchecked.setVisible(true);
        }
    }
    
    public void setChecked(boolean value){
        checkedProperty.set(value);
    }

    public StringProperty textProperty() {
        // null if you don't give it text in constructor
        return textLabel.textProperty();
    }

    public BooleanProperty isCheckedProperty() {
        return checkedProperty;
    }
}

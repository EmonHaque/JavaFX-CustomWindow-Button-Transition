package dialogs;

import controls.ActionButton;
import helpers.Constants;
import helpers.Icons;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import skinned.ExtendedTextArea;

public class ErrorDialog extends Stage {
    BorderPane root;
    ActionButton closeButton;

    public ErrorDialog(String title, String message) {
        var radius = Constants.CardRadius;
        root = new BorderPane();
        var titlePane = new StackPane();
        var buttonsPane = new GridPane();

        root.setBackground(new Background(new BackgroundFill(Color.rgb(0, 0, 0, 0.5), new CornerRadii(radius, false), null)));
        titlePane.setBackground(new Background(new BackgroundFill(Color.rgb(0, 0, 1), new CornerRadii(radius, radius, 0, 0, false), null)));
        buttonsPane.setBackground(new Background(new BackgroundFill(Color.rgb(0, 0, 1), new CornerRadii(0, 0, radius, radius, false), null)));

        root.setTop(titlePane);
        root.setBottom(buttonsPane);

        var titlelabel = new Label(title);
        var messageText = new ExtendedTextArea("Hint", Icons.ACircle);
        messageText.setText(message);
        messageText.setReadOnly(true);
        titlelabel.setFont(Font.font(null, FontWeight.BOLD, -1));
        titlelabel.setTextFill(Color.WHITE);

        StackPane.setMargin(titlelabel, new Insets(10, 0, 10, 0));
        titlePane.getChildren().add(titlelabel);
        root.setCenter(messageText);

        closeButton = new ActionButton(Icons.CloseCircle, 16, "close");
        closeButton.setAction(this::close);
        buttonsPane.getChildren().add(closeButton);
        GridPane.setHgrow(closeButton, Priority.ALWAYS);
        GridPane.setHalignment(closeButton, HPos.RIGHT);
        GridPane.setMargin(closeButton, new Insets(5, 5, 5, 0));
        BorderPane.setMargin(messageText, new Insets(0, 5, 0, 0));

        initStyle(StageStyle.TRANSPARENT);
        initModality(Modality.APPLICATION_MODAL);
    }

    public void showDialog(double width, double height) {
        var scene = new Scene(root, width, height);
        scene.setFill(Color.TRANSPARENT);
        setScene(scene);
        show();
    }
}

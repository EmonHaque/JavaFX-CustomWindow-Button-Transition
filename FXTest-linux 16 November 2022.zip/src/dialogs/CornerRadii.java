package dialogs;

public class CornerRadii {

}

package skinned;

import controls.SVGIcon;
import helpers.Constants;
import javafx.geometry.Insets;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import skins.ExtendedTextAreaSkin;

public class ExtendedTextArea extends BorderPane {
    private TextArea input;
    private SVGIcon leftIcon;
    boolean isLoaded;

    public ExtendedTextArea(String hint, String icon) {
        input = new TextArea();
        input.setSkin(new ExtendedTextAreaSkin(input));
        leftIcon = new SVGIcon(icon);
        setLeft(leftIcon);
        setCenter(input);
        setBorder(Constants.BottomLine);
        setMargin(input, new Insets(0, 0, 2.5, 0));
    }
    public void setText(String value){
        input.setText(value);
    }
    public void setReadOnly(boolean value){
        input.setEditable(!value);
    }
}

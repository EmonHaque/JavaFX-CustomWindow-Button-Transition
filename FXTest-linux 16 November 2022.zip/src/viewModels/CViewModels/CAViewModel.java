package viewModels.CViewModels;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Person2;

public class CAViewModel {
    public ObservableList<Person2> people;
    public static ObjectProperty<Person2> selected;

    public CAViewModel() {
        selected = new SimpleObjectProperty<>();
        people = FXCollections.observableArrayList();
        for (int i = 0; i < 10; i++) {
            var p = new Person2("Person " + i, i, i % 2 == 0);
            people.add(p);
        }
    }
}

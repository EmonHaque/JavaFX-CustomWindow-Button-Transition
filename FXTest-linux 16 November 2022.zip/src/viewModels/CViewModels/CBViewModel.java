package viewModels.CViewModels;

import java.io.PrintWriter;
import java.io.StringWriter;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import model.Person2;

public class CBViewModel {
    private int editCount;
    private String status;
    private Person2 selected;

    public Person2 edited;
    public BooleanProperty dialogTrigger;
    public String dialogHeader, dialogMessage;

    public String getStatus() {
        return status;
    }

    public void setStatus(String value) {
        status = value;
    }

    public CBViewModel() {
        editCount = 0;
        setStatus("you can't update it!");
        edited = new Person2(null, 0, false);
        dialogTrigger = new SimpleBooleanProperty();
        CAViewModel.selected.addListener((o, ov, nv) -> {
            edited.name.set(nv.name.get());
            edited.age.set(nv.age.get());
            edited.isMale.set(nv.isMale.get());
            selected = nv;
        });
    }

    public void update() {
        if (selected == null || selected.equals(edited)) {
            dialogHeader = "Information";
            dialogMessage = "Same thing";
            dialogTrigger.set(true);
            return;
        }
        selected.name.set(edited.name.get());
        selected.age.set(edited.age.get());
        selected.isMale.set(edited.isMale.get());
        editCount++;
        setStatus("edited " + editCount + " times"); // doesn't do anything in View
    }

    public void throwException() {
        try {
            throw new NullPointerException("hmm");
        }
        catch (Exception e) {
            dialogHeader = "Error";
            var sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            dialogMessage = sw.toString();
            dialogTrigger.set(true);
        }
    }
}

package viewModels;

import controls.Slice;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import model.Person;

import java.time.LocalDate;
import java.util.Random;

public class AViewModel {
    int count;
    public StringProperty labelTextProperty; // bound OneWay
    public StringProperty box1TextProperty; // bound OneWayToSource
    public StringProperty box2TextProperty; // bound TwoWay
    public StringProperty query;
    public ObjectProperty<Person> selectedPerson;
    public BooleanProperty isChecked;
    public StringProperty checkText;

    private ObservableList<Person> privatePeople;
    public FilteredList<Person> people;

    private LocalDate startDate;
    private LocalDate endDate;
    public ObjectProperty<LocalDate> selectedDate;

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    // public LocalDate getSelectedDate(){
    // return selectedDate;
    // }

    public AViewModel() {
        startDate = LocalDate.of(2022, 6, 5);
        endDate = LocalDate.of(2023, 12, 13);
        selectedDate = new SimpleObjectProperty<>();
        selectedDate.set(LocalDate.now().plusDays(5));

        privatePeople = FXCollections.observableArrayList();
        var rand = new Random();
        for (int i = 0; i < 40; i++) {
            var p = new Person();
            p.name = "Person " + i;
            p.phone = String.valueOf(rand.nextInt(10000) + 100000);
            privatePeople.add(p);
        }
        people = new FilteredList<>(privatePeople);
        labelTextProperty = new SimpleStringProperty();
        box1TextProperty = new SimpleStringProperty();
        box2TextProperty = new SimpleStringProperty();
        selectedPerson = new SimpleObjectProperty<>();
        selectedPerson.addListener((observable, oldValue, newValue) -> {
            if (newValue != null)
                System.out.println(newValue.name + " | " + newValue.phone);
            else
                System.out.println("Null");
        });
        query = new SimpleStringProperty();
        query.addListener((observable, oldValue, newValue) -> {
            people.setPredicate(p -> p.name.toLowerCase().contains(newValue));
        });
        Slice.setExecutor(AViewModel::sliceExecute);


        checkText = new SimpleStringProperty();
        checkText.set("Some Text");
        isChecked = new SimpleBooleanProperty();
        isChecked.set(true);
        isChecked.addListener((o, ov, nv) -> {
            checkText.set(nv ? "Some text" : "Some other text");
            //checkText = nv ? "Some other Text" : "Some Text";
            System.out.println(nv + " " + checkText.get());
        });
    }

    public void setText() {
        System.out.println("Start " + startDate);
        System.out.println("End " + endDate);
        System.out.println("Selected " + selectedDate.get());

        // var text = "Clicked " + ++count;
        // labelTextProperty.set(text);
        // System.out.println("Box 1: " + box1TextProperty.get());
        // System.out.println("Box 2: " + box2TextProperty.get());
        // box2TextProperty.set("");
    }

    public static void sliceExecute(Slice s) {
        System.out.println("Executed " + s.getSeries().title);
    }
}

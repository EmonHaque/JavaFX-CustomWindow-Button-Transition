package model;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Person2 {
    public StringProperty name;
    public IntegerProperty age;
    public BooleanProperty isMale;

    public Person2(String name, int age, boolean isMale) {
        this.name = new SimpleStringProperty(name);
        this.age = new SimpleIntegerProperty(age);
        this.isMale = new SimpleBooleanProperty(isMale);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this)
            return true;
        if (!(obj instanceof Person2))
            return false;
        var other = (Person2) obj;
        return name.get().equals(other.name.get())
                && age.get() == other.age.get()
                && isMale.get() == other.isMale.get();
    }
}

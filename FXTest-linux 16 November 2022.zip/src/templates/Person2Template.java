package templates;

import controls.BiState;
import helpers.Constants;
import javafx.beans.binding.StringBinding;
import javafx.scene.control.ListCell;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import model.Person2;

public class Person2Template extends ListCell<Person2> {

    @Override
    protected void updateItem(Person2 item, boolean empty) {
        super.updateItem(item, empty);
        setText(null);
        if (item == null || empty) {
            setGraphic(null);
            setBackground(null);
        }
        else {
            prefWidth(0);
            var name = new Text();
            var age = new Text();
            var isMale = new BiState(true, "is male");
            name.setFill(Color.WHITE);
            age.setFill(Color.WHITE);

            name.textProperty().bind(item.name);
            age.textProperty().bind(new StringBinding() {
                { bind(item.age); }
                @Override
                protected String computeValue() {
                    return String.valueOf(item.age.get());
                }
            });
            isMale.isCheckedProperty().bind(item.isMale);

            var box = new HBox(name, age, isMale);
            box.setSpacing(20);
            box.setMouseTransparent(true);
            setGraphic(box);

            if (isSelected())
                setBackground(new Background(new BackgroundFill(Constants.BackgroundColorLight, null, null)));
            else
                setBackground(null);
        }
    }
}

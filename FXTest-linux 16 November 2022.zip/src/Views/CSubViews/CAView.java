package Views.CSubViews;

import abstracts.View;
import skinned.ExtendedListView;
import templates.Person2Template;
import viewModels.CViewModels.CAViewModel;

public class CAView extends View {
    
    @Override
    protected String getHeader() {
        return "CA View";
    }
    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight CAView");

        var vm = new CAViewModel();
        var list = new ExtendedListView<>(vm.people);
        list.setCellFactory(v -> new Person2Template());
        setCenter(list);

        CAViewModel.selected.bind(list.getSelectionModel().selectedItemProperty());
    }
}

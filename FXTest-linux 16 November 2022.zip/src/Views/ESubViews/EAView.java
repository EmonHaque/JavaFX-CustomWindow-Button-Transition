package Views.ESubViews;

import java.util.ArrayList;
import java.util.List;

import Views.BView;
import Views.DView;
import Views.CSubViews.CAView;
import abstracts.View;
import abstracts.ViewContainer;
import enums.NavOverlap;
import enums.NavPosition;
import helpers.Icons;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;

public class EAView extends View {

    private BView container1InitialView;
    private CAView container2InitialView;
    private ECView container3InitialView;

    public EAView() {
        container1InitialView = new BView();
        container2InitialView = new CAView();
        container3InitialView = new ECView();
    }

    @Override
    protected String getIcon() {
        return Icons.ASquare;
    }

    @Override
    protected String getTip() {
        return "EA View";
    }

    @Override
    public boolean isContainer() {
        return true;
    }

    @Override
    public List<View> initialViews() {
        
        super.views = new ArrayList<>();
        views.add(container1InitialView);
        views.add(container2InitialView);
        views.add(container3InitialView);

        return views;
    }
    
    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight EA View");
        
        var container1 = new ViewContainer(NavPosition.TopRightVertical, NavOverlap.Right);
        var container3 = new ViewContainer(NavPosition.TopRightVertical, NavOverlap.Right);
        var container2 = new ViewContainer(NavPosition.BottomLeftVertical, NavOverlap.Left);

        container1.iconSize = container2.iconSize = container3.iconSize = 14;

        container1.addView(container1InitialView);
        container1.addView(new CAView());

        container2.addView(container2InitialView);
        container2.addView(new DView());

        container3.addView(container3InitialView);
        container3.addView(new EBView());

        var grid = new GridPane();

        var colCon = new ColumnConstraints();
        colCon.setPercentWidth(50);
        grid.getColumnConstraints().add(colCon);
        grid.getColumnConstraints().add(colCon);

        var rowCon = new RowConstraints();
        rowCon.setPercentHeight(50);
        grid.getRowConstraints().add(rowCon);
        grid.getRowConstraints().add(rowCon);

        grid.add(container1, 0, 0);
        grid.add(container2, 1, 0);
        grid.add(container3, 0, 1);

        GridPane.setRowSpan(container2, 2);
        setCenter(grid);
    }
    
}

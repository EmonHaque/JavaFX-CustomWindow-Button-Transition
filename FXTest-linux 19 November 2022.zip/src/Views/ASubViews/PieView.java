package Views.ASubViews;

import java.util.ArrayList;
import java.util.List;

import abstracts.View;
import controls.Pie;
import model.PieSeries;

public class PieView extends View{
    @Override
    protected String getHeader() {
        return "Pie View";
    }
    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight PieView");

        List<PieSeries> pieSeries = new ArrayList<>();
        pieSeries.add(new PieSeries("A Title", 100));
        pieSeries.add(new PieSeries("B Title", 70));
        pieSeries.add(new PieSeries("C Title", 50));
        pieSeries.add(new PieSeries("D Title", 120));
        pieSeries.add(new PieSeries("E Title", 20));
        var pie = new Pie(pieSeries);
        setCenter(pie);
    }
}

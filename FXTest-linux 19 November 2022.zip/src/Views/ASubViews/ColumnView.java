package Views.ASubViews;

import java.util.List;

import abstracts.View;
import controls.Columns;
import model.ColumnSeries;

public class ColumnView extends View {
    @Override
    protected String getHeader() {
        return "Column View";
    }
    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight ColumnView");

        List<ColumnSeries> columnSeries = List.of(
                new ColumnSeries("A Title", List.of(100d, 200d)),
                new ColumnSeries("B Title", List.of(50d, 100d)),
                new ColumnSeries("C Title", List.of(200d, 30d)),
                new ColumnSeries("D Title", List.of(300d, 0d)),
                new ColumnSeries("E Title", List.of(70d, 30d)));
        var column = new Columns(columnSeries);
        setCenter(column);
    }
}

package controls;

import javafx.animation.*;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.util.Duration;
import model.PieSeries;
import java.util.List;

import helpers.Constants;

public class Pie extends Region {
    private Circle circle;
    private ScaleTransition circleAnim, infoAnim;
    private double total;
    private Group info;
    private Text label, value, percent;
    private Slice selected;

    public Pie(List<PieSeries> values) {
        double startAngle = 0;
        total = values.stream().mapToDouble(x -> x.value).sum();
        for (PieSeries s : values) {
            var degree = s.value / total * 360.0;
            var endAngle = degree * Math.PI / 180;
            var isLarge = s.value / total > 0.5;
            var slice = new Slice(startAngle, endAngle, isLarge, s);
            startAngle += endAngle;
            getChildren().add(slice);
            slice.setManaged(false);
            slice.addEventHandler(MouseEvent.ANY, this::onMouse);
        }
        circle = new Circle();
        circle.setFill(Constants.BackgroundColor);
        getChildren().add(circle);
        circle.setManaged(false);

        circleAnim = new ScaleTransition(Duration.millis(500), circle);
        circleAnim.setDelay(Duration.millis(250));
        circle.setScaleX(0);
        circle.setScaleY(0);

        label = new Text();
        label.setFont(Font.font(null, FontWeight.BOLD, 14));
        label.setFill(Color.CORNFLOWERBLUE);
        value = new Text();
        value.setFont(Font.font(null, FontWeight.BOLD, 12));
        value.setFill(Color.GREEN);
        percent = new Text();
        percent.setFont(Font.font(null, FontPosture.ITALIC, 12));
        percent.setFill(Color.GRAY);

        var infoBox = new VBox(label, value, percent);
        infoBox.setAlignment(Pos.CENTER);
        info = new Group(infoBox);
        infoBox.setMouseTransparent(true);
        getChildren().add(info);

        infoAnim = new ScaleTransition(Duration.millis(500), info);
        info.setScaleX(0);
        info.setScaleY(0);
    }

    @Override
    protected void layoutChildren() {
        super.layoutChildren();
        var width = getWidth();
        var height = getHeight();
        var cx = width / 2;
        var cy = height / 2;
        var children = getChildren();
        double radius = width > height ? height / 2 - 20 : width / 2 - 20;

        for (var child : children) {
            if (child instanceof Slice slice) {
                slice.setValue(new Point2D(cx, cy), radius);
            }
            else if (child instanceof Circle circle) {
                circle.setRadius(radius * .7);
                circle.setCenterX(cx);
                circle.setCenterY(cy);
            }
            else {
                info.setTranslateX(cx - child.prefWidth(-1) / 2);
                info.setTranslateY(cy - child.prefHeight(-1) / 2);
            }
        }
    }

    void onMouse(MouseEvent e) {
        if (e.getEventType() == MouseEvent.MOUSE_ENTERED) {
            var slice = (Slice) e.getSource();
            label.setText(slice.getSeries().title);
            value.setText((int) slice.getSeries().value + "");
            percent.setText(String.format("%.2f", slice.getSeries().value / total * 100) + "%");

            if (selected != null)
                return;

            if (circleAnim.getStatus() == Animation.Status.RUNNING) {
                circleAnim.stop();
            }
            if (infoAnim.getStatus() == Animation.Status.RUNNING) {
                infoAnim.stop();
            }
            circleAnim.setFromX(circle.getScaleX());
            circleAnim.setFromY(circle.getScaleY());
            circleAnim.setToX(1);
            circleAnim.setToY(1);
            circleAnim.play();

            infoAnim.setDelay(Duration.millis(250));
            infoAnim.setFromX(info.getScaleX());
            infoAnim.setFromY(info.getScaleY());
            infoAnim.setToX(1);
            infoAnim.setToY(1);
            infoAnim.play();

        }
        else if (e.getEventType() == MouseEvent.MOUSE_EXITED) {
            if (selected != null)
                return;

            if (circleAnim.getStatus() == Animation.Status.RUNNING) {
                circleAnim.stop();
            }

            if (infoAnim.getStatus() == Animation.Status.RUNNING) {
                infoAnim.stop();
            }
            infoAnim.setDelay(Duration.millis(100));
            infoAnim.setFromX(info.getScaleX());
            infoAnim.setFromY(info.getScaleY());
            infoAnim.setToX(0);
            infoAnim.setToY(0);
            infoAnim.play();

            circleAnim.setFromX(circle.getScaleX());
            circleAnim.setFromY(circle.getScaleY());
            circleAnim.setToX(0);
            circleAnim.setToY(0);
            circleAnim.play();

        }
        else if (e.getEventType() == MouseEvent.MOUSE_RELEASED) {
            if (!(e.getSource() instanceof Slice))
                return;
            var source = (Slice) e.getSource();
            if (selected != null) {
                if (selected == source) {
                    selected = null;
                }
                else {
                    selected.setSelected(false);
                    selected = source;
                }
            }
            else {
                selected = source;
            }
        }
    }
}

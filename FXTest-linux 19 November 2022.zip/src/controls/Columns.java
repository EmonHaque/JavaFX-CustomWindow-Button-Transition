package controls;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;
import javafx.scene.transform.Scale;
import model.ColumnSeries;
import java.util.List;

public class Columns extends Region {
    double labelHeight, labelWidth, min, max;
    double gap = 15;
    List<ColumnSeries> series;

    public Columns(List<ColumnSeries> series) {
        this.series = series;
        min = 0;
        for (int i = 0; i < series.size(); i++) {
            var total = series.get(i).getValues().stream().mapToDouble(x -> x).sum();
            if (max < total) max = total;
        }
        double step = max / 5;
        double current = min;
        for (int i = 0; i < 6; i++) {
            var line = new Line();
            line.setStroke(Color.GRAY);

            line.getStrokeDashArray().addAll(5d, 2d);
            getChildren().add(line);
            var label = new Text(String.format("%.1f", current));
            label.setFill(Color.WHITE);
            current += step;
            getChildren().add(label);
            labelWidth = label.prefWidth(-1);
            labelHeight = label.prefHeight(-1);
            line.setManaged(false);
            label.setManaged(false);
        }
        for (var s : series) {
            var column = new ColumnStack(s);
            column.getTransforms().add(new Scale(1,-1));
            getChildren().add(column);
            column.setManaged(false);
        }
    }

    @Override
    protected void layoutChildren() {
        super.layoutChildren();
        var children = getChildren();
        var height = getHeight();
        var width = getWidth();
        var vSpace = height / 6;
        var colWidth = (width - labelWidth - series.size() * gap) / series.size();

        double lineY = height;
        double labelY = lineY - 5;
        double x = labelWidth + gap;

        for (var child : children) {
            if(child instanceof Line line){
                line.setStartY(lineY);
                line.setEndY(lineY);
                line.setEndX(width);
                lineY -= vSpace;
            }
            else if(child instanceof Text text){
                text.setY(labelY);
                labelY -= vSpace;
            }
            else if(child instanceof ColumnStack column){
                var h = column.getTotal() * (height - vSpace) / max;
                column.makeColumn(colWidth, h);
                column.setTranslateX(x);
                column.setTranslateY(height);
                x += colWidth + gap;
            }
        }
    }
}

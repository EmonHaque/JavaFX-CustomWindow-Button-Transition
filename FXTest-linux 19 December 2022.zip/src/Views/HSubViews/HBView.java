package Views.HSubViews;

import abstracts.View;
import helpers.Constants;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import viewModels.HViewModel;

public class HBView extends View {
    private HTreeView tree;
    private HViewModel vm;

    @Override
    protected String getHeader() {
        return "HB View";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        vm = new HViewModel();
        var header = new GridPane(){{
            getColumnConstraints().addAll(
                new ColumnConstraints(){{ setHgrow(Priority.ALWAYS);}},
                new ColumnConstraints(74){{ setHalignment(HPos.RIGHT);}},
                new ColumnConstraints(74){{ setHalignment(HPos.RIGHT);}},
                new ColumnConstraints(74){{ setHalignment(HPos.RIGHT);}},
                new ColumnConstraints(74){{ setHalignment(HPos.RIGHT);}},
                new ColumnConstraints(74){{ setHalignment(HPos.RIGHT);}}
            );
            add(new Text("Name"){{ setFill(Color.WHITE);}}, 0, 0);
            add(new Text("Age1"){{ setFill(Color.WHITE);}}, 1, 0);
            add(new Text("Age2"){{ setFill(Color.WHITE);}}, 2, 0);
            add(new Text("Age3"){{ setFill(Color.WHITE);}}, 3, 0);
            add(new Text("Age4"){{ setFill(Color.WHITE);}}, 4, 0);
            add(new Text("Age5"){{ setFill(Color.WHITE);}}, 5, 0);

            setPadding(new Insets(0, Constants.ScrollBarSize, 0, 0));
            setBorder(Constants.BottomLine);
        }};
        tree = new HTreeView(vm.list, false);
        var box = new VBox(header, tree){{ 
            setVgrow(tree, Priority.ALWAYS);
            setSpacing(5);
            setPadding(new Insets(5,0,0,0));
        }};
        setCenter(box);
    }
}

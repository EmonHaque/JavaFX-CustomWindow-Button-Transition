package Views.HSubViews;

import javafx.collections.ObservableList;
import javafx.scene.control.TreeItem;
import model.ATreeModel;
import skinned.ExtendedTreeView;
import templates.CellLabel;
import templates.CellTextFlow;

public class HTreeView extends ExtendedTreeView<ATreeModel> {
    private TreeItem<ATreeModel> root;

    public HTreeView(ObservableList<ATreeModel> list, boolean islabelCell) {
       root = new TreeItem<>();
       
       for(var model : list){
            boolean hasit = false;
            TreeItem<ATreeModel> item = null;
            for(var node : root.getChildren()){
                if(node.getValue().getTitle().equals(model.getTitle())){
                    hasit = true;
                    item = node;
                    item.getValue().setAge(item.getValue().getAge() + model.getAge());
                    break;
                }
            }
            if(!hasit){
                item = new TreeItem<>(new ATreeModel(model.getTitle(), "", model.getAge()));
                root.getChildren().add(item);
            }
            item.getChildren().add(new TreeItem<>(model));
       }

       setRoot(root);
       setShowRoot(false);
    
       setCellFactory(islabelCell ?  x -> new CellLabel() : x -> new CellTextFlow());
    }
}

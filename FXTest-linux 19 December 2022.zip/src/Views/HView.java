package Views;

import java.util.ArrayList;
import java.util.List;

import Views.HSubViews.HAView;
import Views.HSubViews.HBView;
import abstracts.View;
import helpers.Constants;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;

public class HView extends View {
    private View haView, hbView;
    @Override
    protected String getIcon() {
        return Icons.HCircle;
    }
    @Override
    protected String getTip() {
        return "HView";
    }
    @Override
    public boolean isContainer() {
        return true;
    }
    @Override
    public List<View> initialViews() {
        haView = new HAView();
        hbView = new HBView();    

        super.views = new ArrayList<>();
        views.add(haView);
        views.add(hbView);
        return super.views;
    }
    @Override
    public void onFirstSight() {
        super.onFirstSight();

        var grid = new GridPane(){{
            getColumnConstraints().addAll(
                new ColumnConstraints(){{ setPercentWidth(50);}},
                new ColumnConstraints(){{ setPercentWidth(50);}}
            );
            getRowConstraints().add(new RowConstraints(){{ setPercentHeight(100);}});
            
            add(haView, 0, 0);
            add(hbView, 1, 0);

            setHgap(Constants.CardMargin);
            setPadding(new Insets(Constants.CardMargin));
        }};
        setCenter(grid);
    }
}

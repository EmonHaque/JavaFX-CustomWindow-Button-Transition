package Views;

import abstracts.View;
import controls.texts.TextBox;
import helpers.Icons;
import javafx.scene.effect.BlendMode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.scene.web.WebView;

public class BView extends View {
    @Override
    protected String getIcon() {
        return Icons.BCircle;
    }

    @Override
    protected String getHeader() {
        return "B View";
    }

    @Override
    protected String getTip() {
        return "B View";
    }

    @Override
    public void onFirstSight()  {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight BView");
        var box = new BorderPane();
        var textBox = new TextBox("Surah:Ayah", Icons.Add);
        var web = new WebView();
        web.setBlendMode(BlendMode.DARKEN);
        
        var t1 = new Text("بِ");
        var t2 = new Text("سمِ ");
        var t3 = new Text("ال");
        var t4 = new Text("لَّهِ ");
        var t5 = new Text("ال");
        var t6 = new Text("رَّحمَنِ ");
        var t7 = new Text("ال");
        var t8 = new Text("رَّحيم");

        var flow = new TextFlow(t1, t2, t3, t4, t5, t6, t7, t8);
        ///flow.setNodeOrientation(NodeOrientation.RIGHT_TO_LEFT);

        var arabic = Font.loadFont(getClass().getClassLoader()
                .getResourceAsStream("fonts/Scheherazade-Regular.ttf"), 40);
        for(var text: flow.getChildren()){
            var element = (Text)text;
            //element.setTextAlignment(TextAlignment.RIGHT);
            //element.setNodeOrientation(NodeOrientation.RIGHT_TO_LEFT);
            element.setFont(arabic);
            if(element.getText() == "ال") element.setFill(Color.CORNFLOWERBLUE);
            if(element.getText() == "بِ") element.setFill(Color.CORAL);
        }
        var plainText = new Text("بِسمِ اللَّهِ الرَّحمَنِ الرَّحيم");
        plainText.setFont(arabic);
        var bottomBox = new VBox(flow, plainText);
       // bottomBox.setAlignment(Pos.BASELINE_RIGHT);
        box.setTop(textBox);
        box.setCenter(web);
        box.setBottom(bottomBox);

        // var engine = web.getEngine();
        // textBox.setOnKeyPressed(e -> {
        //     if(e.getCode() != KeyCode.ENTER) return;
        //     var splits = textBox.textProperty.get().split(":");
        //     var surah = splits[0];
        //     var ayah = splits[1];
        //     var url = "https://corpus.quran.com/wordbyword.jsp?chapter=" + surah +"&verse=" + ayah;

        //    Document doc = null;
        //    try { doc = Jsoup.connect(url).get();}
        //    catch (IOException ex) { ex.printStackTrace();}
        //    var table = doc.select("table[class='morphologyTable']").first();
        //    var rows = table.select("tr");
        //    table.children().removeAll(rows);
        //    var header = rows.select("[class='head']").first();
        //    table.append(header.html());
        //    rows.remove(0);
        //    var pattern = surah + ":" ;
        //    for(var row : rows){
        //        var column = row.select("span[class='location']").text().substring(1);
        //        if(column.startsWith(pattern)){
        //            var image = row.select("td[class='ic']>a>img").first();
        //            var id = image.attr("src");
        //            image.attr("src", "https://corpus.quran.com/" + id);
        //            table.append(row.html());
        //        }
        //    }
        //    engine.loadContent(table.outerHtml());
        // });

        setCenter(box);
    }
}

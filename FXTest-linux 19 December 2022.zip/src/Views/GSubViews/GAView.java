package Views.GSubViews;

public class GAView extends GAbstractView {

    @Override
    protected String getName() {
        return "GA";
    }
}

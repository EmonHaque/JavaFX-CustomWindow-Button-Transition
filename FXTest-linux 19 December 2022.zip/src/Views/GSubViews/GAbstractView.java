package Views.GSubViews;

import java.util.concurrent.ExecutionException;

import abstracts.View;
import controls.SpinningArc;
import controls.buttons.ActionButton;
import helpers.Icons;
import javafx.application.Platform;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import viewModels.GViewModels.GService;

public abstract class GAbstractView extends View {
    private SpinningArc arc;
    private Label label;
    private int count;

    protected abstract String getName();

    @Override
    protected String getHeader() {
        return getName() + " View";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight " + getName() + " View");

        arc = new SpinningArc();
        addAction(arc);

        var button = new ActionButton(Icons.Reload, 16, "request");
        button.setAction(this::request);
        addAction(button);

        label = new Label();
        label.setTextFill(Color.WHITE);
        setCenter(label);
        request();
    }

    private void request() {
        count++;
        label.setText("waiting ... " + count);
        var future = GService.execute("From " + getName() + " " + count);
        arc.setVisible(true);
        new Thread(() -> {
            try {
                var str = future.get();
                Platform.runLater(() -> {
                    label.setText(str);
                });
            }
            catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
            finally{
                arc.setVisible(false);
            }
        }).start();
    }
}

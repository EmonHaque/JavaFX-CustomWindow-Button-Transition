package Views.ASubViews;

import abstracts.View;
import controls.Lines;
import viewModels.AViewModels.LineViewVM;

public class LineView extends View {
    LineViewVM vm;
    @Override
    protected String getHeader() {
        return "Line View";
    }
    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight LineView");

        vm = new LineViewVM();
        var pinLine = new Lines("Pin Value", "Line Value");
        pinLine.seriesProperty.bind(vm.seriesProperty);
        setCenter(pinLine);
    }
}

package Views.FSubViews;

import abstracts.View;
import controls.ImageZoomer;
import controls.buttons.ActionButton;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.binding.StringBinding;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.SplitPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import model.ImageFile;
import skinned.ExtendedListView;
import skins.ExtendedSplitPaneSkin;
import templates.ImageFileTemplate;
import viewModels.FViewModels.FAAViewVM;

public class FAAView extends View {
    private ActionButton openDirectory, zoomIn, zoomOut, restore;
    private ExtendedListView<ImageFile> list;
    private ImageZoomer zoomer;
    private Text zoomLevel;
    private FAAViewVM vm;

    @Override
    protected String getHeader() {
        return "FAA View";
    }

    @Override
    protected String getIcon() {
        return Icons.ACircle;
    }

    @Override
    protected String getTip() {
        return "FAA View";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight FAA View");

        vm = new FAAViewVM();
        initializeUI();
        bind();
    }

    private void initializeUI() {
        openDirectory = new ActionButton(Icons.DirectoryOpen, 16, "choose image(s)");
        list = new ExtendedListView<>(vm.imageList);
        list.setCellFactory(v -> new ImageFileTemplate(vm::removeFile));
        var leftBox = new VBox(openDirectory, list);
        leftBox.setAlignment(Pos.TOP_RIGHT);
        VBox.setMargin(openDirectory, new Insets(0, Constants.ScrollBarSize, 0, 0));
        VBox.setVgrow(list, Priority.ALWAYS);

        zoomLevel = new Text();
        zoomLevel.setFill(Color.WHITE);
        zoomIn = new ActionButton(Icons.ZoomIn, 16, "zoom in");
        zoomOut = new ActionButton(Icons.ZoomOut, 16, "zoom out");
        restore = new ActionButton(Icons.Restore, 16, "restore");
        zoomer = new ImageZoomer();

        var iconBox = new HBox(zoomLevel, zoomIn, zoomOut, restore);
        iconBox.setAlignment(Pos.TOP_RIGHT);
        HBox.setMargin(zoomLevel, new Insets(0,5,0,0));
        var rightBox = new VBox(iconBox, zoomer);
        rightBox.setAlignment(Pos.TOP_RIGHT);
        VBox.setMargin(zoomer, new Insets(0, 0, 0, 5));
        VBox.setVgrow(zoomer, Priority.ALWAYS);

        var splits = new SplitPane(leftBox, rightBox);
        splits.setSkin(new ExtendedSplitPaneSkin(splits));
        BorderPane.setMargin(splits, new Insets(5, 0, 0, 0));
        setCenter(splits);
    }

    private void bind() {
        openDirectory.setAction(vm::openFolder);
        zoomIn.setAction(zoomer::zoomIn);
        zoomOut.setAction(zoomer::zoomOut);
        restore.setAction(zoomer::restore);
        zoomer.imageProperty.bind(vm.selectedImage);
        zoomLevel.textProperty().bind(new StringBinding() {
            { bind(zoomer.zoomLevelProperty); }
            @Override
            protected String computeValue() {
                return "Zoom level: " + String.format("%.2f", zoomer.zoomLevelProperty.get());
            }
        });
        // vm.selectedFile.bindBidirectional(list.getSelectionModel().selectedItemProperty());
        vm.selectedFile.addListener((o, ov, nv) ->{
            list.getSelectionModel().select(nv);;
        });
        list.getSelectionModel().selectedItemProperty().addListener((o, ov, nv) ->{
            vm.selectedFile.set(nv);
        });
    }
}

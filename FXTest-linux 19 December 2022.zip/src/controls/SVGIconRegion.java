package controls;

import javafx.animation.Animation;
import javafx.animation.FillTransition;
import javafx.animation.Interpolator;
import javafx.scene.layout.Background;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.shape.SVGPath;
import javafx.util.Duration;

public class SVGIconRegion extends Region {
    private SVGPath svg;
    private FillTransition anim;

    public SVGIconRegion(String path) {
        svg = new SVGPath();
        svg.setContent(path);
        svg.setFill(Color.WHITE);

        fixSize(12);
        setShape(svg);
        setBackground(Background.fill(svg.getFill()));

        anim = new FillTransition(Duration.millis(250), svg);
        anim.setInterpolator(new Interpolator() {

            @Override
            protected double curve(double arg) {
                setBackground(Background.fill(svg.getFill()));
                return arg;
            }
        });
    }

    public SVGIconRegion(String path, double size) {
        this(path);
        fixSize(size);
    }

    public void setContent(String path){
        svg.setContent(path);
    }

    public void animate(Color color){
        if(anim.getStatus() == Animation.Status.RUNNING){
            anim.stop();
        }
        anim.setFromValue((Color)svg.getFill());
        anim.setToValue(color);
        anim.play();
    }
    public void setColor(Color color){
        if(anim.getStatus() == Animation.Status.RUNNING){
            anim.stop();
        }
        svg.setFill(Color.WHITE);
        setBackground(Background.fill(svg.getFill()));
    }

    private void fixSize(double size){
        setPrefSize(size, size);
        setMaxSize(size, size);
        setMinSize(size, size);
    }
}

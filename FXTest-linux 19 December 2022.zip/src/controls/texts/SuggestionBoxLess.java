package controls.texts;

import java.lang.reflect.InvocationTargetException;

import helpers.Constants;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.Point2D;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;
import javafx.scene.shape.Path;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.control.SelectionMode;
import javafx.stage.Popup;
import skinned.ExtendedResizableListView;
import skins.ExtendedTextFieldSkin;

public class SuggestionBoxLess<T> extends TextField {
    private FilteredList<T> filteredList;
    private ExtendedResizableListView<T> listView;
    private Popup popup;
    private String property;
    private boolean isTabOrEnter, isPressed;

    public SuggestionBoxLess(ObservableList<T> list, String property, String template) {
        this.property = property;
        filteredList = new FilteredList<>(list, this::filter);
        setSkin(new ExtendedTextFieldSkin(this));

        listView = new ExtendedResizableListView<T>(filteredList);
        listView.setBorder(Constants.BottomLine);
        listView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        listView.setMaxHeight(200);
        listView.setBackground(Background.fill(Constants.BackgroundColor));
        listView.setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.25))));

        if (template != null) {
            setCells(template);
        }
        else {
            listView.setCellFactory(v -> new ListCell<T>() {
                {
                    setBackground(null);
                    setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
                }
                @Override
                protected void updateItem(T item, boolean empty) {
                    super.updateItem(item, empty);
                    if (item == null || empty) {
                        setGraphic(null);
                    }
                    else {
                        var hiText = new HiText(item.toString());
                        hiText.query.set(SuggestionBoxLess.this.getText());
                        setGraphic(hiText);
                        setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
                    }
                }
            });
        }

        popup = new Popup();
        popup.getContent().add(listView);
        // popup.setHideOnEscape(true);

        // listView.setOnKeyPressed(this::onKeyPressed);
        addEventFilter(KeyEvent.KEY_PRESSED, this::onKeyPressed);
        listView.addEventHandler(KeyEvent.KEY_PRESSED, this::onKeyPressedList);
        textProperty().addListener(this::onTextChanged);
    }

    @SuppressWarnings("unchecked")
    private void setCells(String template) {
        try {
            var tor = Class.forName(template).getConstructor(StringProperty.class);
            listView.setCellFactory(v -> {
                try {
                    return (ListCell<T>) tor.newInstance(textProperty());
                }
                catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
                    e.printStackTrace();
                }
                return null;
            });
        }
        catch (ClassNotFoundException | NoSuchMethodException | SecurityException e) {
            e.printStackTrace();
        }
    }

    private void onKeyPressed(KeyEvent e) {
        if (e.isControlDown())
            return;

        if (e.getCode() == KeyCode.TAB || e.getCode() == KeyCode.ENTER)
            return;
            
        isPressed = true;
    }

    private void onKeyPressedList(KeyEvent e) {
        var key = e.getCode();
        if (key == KeyCode.ENTER || key == KeyCode.TAB) {
            if (!popup.isShowing()) {
                return;
            }
            isTabOrEnter = true;
            popup.hide();
            requestFocus();
            var item = listView.getSelectionModel().getSelectedItem();
            if (item == null) {
                item = listView.getItems().get(0);
            }
            if (item instanceof String) {
                setText(item.toString());
                end();
            }
            else {
                try {
                    var getter = item.getClass().getMethod("get" + property);
                    var name = getter.invoke(item).toString();
                    setText(name);
                    end();
                }
                catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e1) {
                    e1.printStackTrace();
                }
            }
        }
    }

    protected void onTextChanged(ObservableValue<?> observable, String oldValue, String newValue) {
        if (isTabOrEnter) {
            isTabOrEnter = false;
            return;
        }

        if (!isPressed) {
            return;
        }

        listView.getSelectionModel().clearSelection();
        if (newValue != null && !newValue.isEmpty() && !newValue.isBlank()) {
            Path caret = findCaret(this);
            Point2D screenLoc = findScreenLocation(caret);

            filteredList.setPredicate(this::filter);
            if (filteredList.size() > 0) {
                if (!popup.isShowing()) {
                    popup.show(this, screenLoc.getX(), screenLoc.getY() + 20);
                }
                else {
                    popup.setX(screenLoc.getX());
                    popup.setY(screenLoc.getY() + 20);
                }
            }
            else {
                popup.hide();
            }
        }
        else{
            filteredList.setPredicate(p -> true);
        }
        isPressed = false;
    }

    protected void onFocusChanged(ObservableValue<?> observable, Boolean oldValue, Boolean newValue) {
        // super.onFocusChanged(observable, oldValue, newValue);
        if (popup.isShowing()) {
            popup.hide();
        }
    }

    private boolean filter(T item) {
        boolean result = false;
        if (item instanceof String) {
            result = ((String) item).toLowerCase().contains(getText().toLowerCase());
        }
        else {
            try {
                var getter = item.getClass().getMethod("get" + property);
                var name = getter.invoke(item).toString();
                result = name.toLowerCase().contains(getText().toLowerCase());
            }
            catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
                e.printStackTrace();
                result = true;
            }
        }
        return result;
    }

    // https://community.oracle.com/tech/developers/discussion/2534556/how-to-get-caret-screen-coordinates-in-textarea

    private Point2D findScreenLocation(Node node) {
        // double x = 0;
        // double y = 0;
        // for (Node n = node; n != null; n = n.getParent()) {
        // var parentBounds = n.getBoundsInParent();
        // x += parentBounds.getMinX();
        // y += parentBounds.getMinY();
        // }
        // var scene = node.getScene();
        // x += scene.getX();
        // y += scene.getY();
        // var window = scene.getWindow();
        // x += window.getX();
        // y += window.getY();
        // Point2D screenLoc = new Point2D(x, y);
        // return screenLoc;

        return node.localToScreen(new Point2D(0, 0));
    }

    private Path findCaret(final Parent parent) {
        // Warning: this is an ENORMOUS HACK
        for (Node n : parent.getChildrenUnmodifiable()) {
            if (n instanceof Path) {
                return (Path) n;
            }
            else if (n instanceof Parent) {
                Path p = findCaret((Parent) n);
                if (p != null) {
                    return p;
                }
            }
        }
        return null;
    }
}

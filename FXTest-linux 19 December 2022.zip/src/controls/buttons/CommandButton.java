package controls.buttons;

import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;

public class CommandButton extends ActionButton {

    public CommandButton(String icon, double size, String tip) {
        super(icon, size, tip);
        setFocusTraversable(true);
        setOnKeyReleased(this::onKeyPressed);
        focusedProperty().addListener((o, ov, nv) -> {
            animate(nv ? Color.CORNFLOWERBLUE : Color.WHITE);
        });

    }

    private void onKeyPressed(KeyEvent e){
        var key = e.getCode();
        if(key == KeyCode.SPACE || key == KeyCode.ENTER){
            if(executor != null) {
                executor.execute();
            }
        }
    }
}

package model;

public class ATreeModel {
    private String title, name;
    private int age;
    public ATreeModel(String title, String name, int age) {
        this.title = title;
        this.name = name;
        this.age = age;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }

}

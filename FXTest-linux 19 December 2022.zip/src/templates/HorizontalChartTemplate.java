package templates;

import javafx.beans.property.DoubleProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.layout.Background;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import model.HorizontalSeries;

public class HorizontalChartTemplate extends ListCell<HorizontalSeries> {
    private HorizontalChartCell test;
    private double percentOfChartArea, topBottomPadding;
    private DoubleProperty topMax, bottomMax;

    public HorizontalChartTemplate(double rightMargin, double percentOfChartArea, DoubleProperty topMax, DoubleProperty bottomMax) {
        this.percentOfChartArea = percentOfChartArea;
        this.topMax = topMax;
        this.bottomMax = bottomMax;
        topBottomPadding = 2.5;

        setBackground(null);
        setPadding(new Insets(0, rightMargin, 0, 0));
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);

        initializeUI();
        hoverProperty().addListener(this::onHover);
        itemProperty().addListener(this::onItemChanged);
    }

    private void initializeUI() {
        test = new HorizontalChartCell();
    }

    private void onHover(ObservableValue<?> o, boolean ov, boolean nv) {
        if (nv && !isEmpty()) {
            setBackground(Background.fill(Color.rgb(100, 100, 100, 0.3)));
        }
        else {
            setBackground(null);
        }
    }

    private void onItemChanged(ObservableValue<?> o, HorizontalSeries ov, HorizontalSeries nv) {
        if (ov != null) {
            test.resetValue();
            // trackItem("onItemChanged old", ov);
        }
        if (nv != null) {
            int index = getIndex();
            var previous = index > 0 ? getListView().getItems().get(index - 1) : null;
            test.setValue(nv, previous, percentOfChartArea, topBottomPadding, topMax.get(), bottomMax.get());
            // trackItem("onItemChanged new", ov);
        }
    }

    @SuppressWarnings("unused")
    private void trackItem(String methodName, HorizontalSeries item) {
        System.out.println(methodName + ": " + item);
    }

    @Override
    protected void updateItem(HorizontalSeries item, boolean empty) {
        super.updateItem(item, empty);
        if (empty) {
            setGraphic(null);
        }
        else {
            // trackItem("updateItem", item);
            setGraphic(test);
        }
    }

    @Override
    protected void layoutChildren() {
        if (isEmpty()){
            super.layoutChildren();
            return;
        }
        // trackItem("layoutChildren", getItem());
        layoutInArea(test, 0, 0, getWidth() - getPadding().getRight(), getHeight(), 0, HPos.LEFT, VPos.TOP);
    }

    @Override
    protected double computePrefHeight(double width) {
        var item = getItem();
        if (item == null)
            return super.computePrefHeight(width);

        var text = new Text();
        text.setText(item.getTitle());
        text.setWrappingWidth(width * (1 - percentOfChartArea));
        return text.prefHeight(-1) + topBottomPadding * 2;
    }

    // @Override
    // protected Skin<?> createDefaultSkin() {
    //     var skin = (ListCellSkin<?>) super.createDefaultSkin();
    //     return skin;
    // }

}

package templates;

import controls.SVGIconRegion;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.value.ObservableValue;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.TreeCell;
import javafx.scene.layout.Background;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import model.ATreeModel;

public class CellTextFlow extends TreeCell<ATreeModel>{
    private GridPane root;
    private TextFlow nameFlow;
    private Text name, age1, age2, age3, age4, age5;
    private SVGIconRegion disclosureIcon;
    private StackPane disclosurePane;
    private Font normal, bold;

    public CellTextFlow() {
        setPrefWidth(0);
        setBackground(null);
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        setPadding(new Insets(2.5, 0, 0, 2.5));

        initializeUI();
        itemProperty().addListener(this::onItemChanged);
    }

    private void initializeUI(){
        normal = Font.font(null, FontWeight.NORMAL, -1);
        bold = Font.font(null, FontWeight.BOLD, -1);

        disclosureIcon = new SVGIconRegion(Icons.PlusCircle);
        disclosurePane = new StackPane(disclosureIcon);
        disclosurePane.setPadding(new Insets(1.5, 5, 0, 0));
        setDisclosureNode(disclosurePane);

        name = new Text(){{ setFill(Color.WHITE);}};
        age1 = new Text(){{ setFill(Color.WHITE);}};
        age2 = new Text(){{ setFill(Color.WHITE);}};
        age3 = new Text(){{ setFill(Color.WHITE);}};
        age4 = new Text(){{ setFill(Color.WHITE);}};
        age5 = new Text(){{ setFill(Color.WHITE);}};
        nameFlow = new TextFlow(name);

        root = new GridPane(){{
            getColumnConstraints().addAll(
                new ColumnConstraints(){{ setHgrow(Priority.ALWAYS);}},
                new ColumnConstraints(75) {{ setHalignment(HPos.RIGHT);}},
                new ColumnConstraints(75) {{ setHalignment(HPos.RIGHT);}},
                new ColumnConstraints(75) {{ setHalignment(HPos.RIGHT);}},
                new ColumnConstraints(75) {{ setHalignment(HPos.RIGHT);}},
                new ColumnConstraints(75) {{ setHalignment(HPos.RIGHT);}}
            );
            add(nameFlow, 0, 0);
            add(age1, 1, 0);
            add(age2, 2, 0);
            add(age3, 3, 0);
            add(age4, 4, 0);
            add(age5, 5, 0);

            setValignment(nameFlow, VPos.TOP);
        }};
        name.wrappingWidthProperty().bind(root.widthProperty().subtract(150 - Constants.ScrollBarSize));
    }

    private void onItemChanged(ObservableValue<?> o, ATreeModel ov, ATreeModel nv){
        if(ov != null){
            name.setText(null);
            age1.setText(null);
            age2.setText(null);
            age3.setText(null);
            age4.setText(null);
            age5.setText(null);

            disclosureIcon.setColor(Color.WHITE); // why do I've to set the Color?
            disclosureIcon.setOnMouseEntered(null);
            disclosureIcon.setOnMouseExited(null);
        }
        if(nv != null){
            var treeItem = getTreeView().getTreeItem(getIndex());
            int level = getTreeView().getTreeItemLevel(treeItem);

            disclosureIcon.setContent(treeItem.isExpanded() ? Icons.PlusCircle : Icons.MinusCircle);
            disclosureIcon.setOnMouseEntered(e -> disclosureIcon.animate(Color.CORNFLOWERBLUE));
            disclosureIcon.setOnMouseExited(e -> disclosureIcon.animate(Color.WHITE));
            
            if(level == 1){
                name.setText(nv.getTitle());
                name.setFont(bold);    
            }
            else{
                name.setText(nv.getName());
                name.setFont(normal);   
            }
            age1.setText(String.valueOf(nv.getAge()));
            age2.setText(String.valueOf(nv.getAge()));
            age3.setText(String.valueOf(nv.getAge()));
            age4.setText(String.valueOf(nv.getAge()));
            age5.setText(String.valueOf(nv.getAge()));
        }
    }

    @Override
    protected void updateItem(ATreeModel item, boolean empty) {
        super.updateItem(item, empty);
        if(isEmpty()){
            setGraphic(null);
            setBackground(null);
        }
        else{
            setGraphic(root);
            setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
        }
    }
}
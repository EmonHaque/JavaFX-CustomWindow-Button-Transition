package dialogs;

import abstracts.DialogBase;
import controls.buttons.ActionButton;
import controls.texts.TextBoxMultiLine;
import helpers.Icons;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;

public class ErrorDialog extends DialogBase {
    ActionButton closeButton;

    public ErrorDialog(String title, String message) {
        super();
        titlelabel.setText(title);
        var messageText = new TextBoxMultiLine("Stack trace", Icons.ACircle);
        messageText.setBorder(null);
        messageText.setText(message);
        messageText.setReadOnly(true);
        root.setCenter(messageText);

        closeButton = new ActionButton(Icons.CloseCircle, 16, "close");
        closeButton.setAction(this::closeDialog);
        buttonsPane.getChildren().add(closeButton);
        GridPane.setHgrow(closeButton, Priority.ALWAYS);
        GridPane.setHalignment(closeButton, HPos.RIGHT);
        GridPane.setMargin(closeButton, new Insets(5, 5, 5, 0));
        BorderPane.setMargin(messageText, new Insets(0, 5, 0, 0));
    }

    @Override
    public void showDialog(double width, double height) {
        super.showDialog(width, height);
        show();
    }
}

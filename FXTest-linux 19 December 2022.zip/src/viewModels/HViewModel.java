package viewModels;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.ATreeModel;

public class HViewModel {
    public ObservableList<ATreeModel> list;
    public StringProperty query;

    public HViewModel() {
        query = new SimpleStringProperty();
        list = FXCollections.observableArrayList();

        int count = 1;
        for(int i = 1; i < 51; i++){
            if(i % 10 == 0) count++;

            var item = new ATreeModel("Long long long long long long long long long long long long long long long long long long long long name " + count, 100);
            list.add(item);
        }
    }
}

package viewModels;

import java.util.Random;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.ATreeModel;

public class HViewModel {
    public ObservableList<ATreeModel> list;
    public StringProperty query;

    public HViewModel() {
        query = new SimpleStringProperty();
        list = FXCollections.observableArrayList();
        var rand = new Random();
        int count = 0;
        int limit = 30;
        var groupTitle = "Long ";
        int random = rand.nextInt(limit) + 1;
        for(int j = 0; j < random; j++){
            groupTitle += "long ";
        }
        groupTitle += "name " + count;
        
        for(int i = 1; i < 30; i++){
            if(i % 5 == 0) {
                count++;
                random = rand.nextInt(limit) + 1;
                groupTitle = "Long ";
                for(int j = 0; j < random; j++){
                    groupTitle += "long ";
                }
                groupTitle += "name " + count;
            }
            random = rand.nextInt(limit) + 1;
            String name = "Long ";
            for(int j = 0; j < random; j++){
                name += "long ";
            }
            name += "name " + count;

            var item = new ATreeModel(groupTitle, name, 100);
            list.add(item);
        }
    }
}

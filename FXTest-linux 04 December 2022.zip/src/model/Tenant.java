package model;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Tenant {
    public StringProperty houseProperty;
    public StringProperty tenantProperty;
    public StringProperty spaceProperty;
    public IntegerProperty rentProperty;
    public DoubleProperty dueProperty;

    public Tenant(){
        houseProperty = new SimpleStringProperty();
        tenantProperty = new SimpleStringProperty();
        spaceProperty = new SimpleStringProperty();
        rentProperty = new SimpleIntegerProperty();
        dueProperty = new SimpleDoubleProperty();
    }

    public Tenant(String house, String tenant, String space, int rent, double due) {
        houseProperty = new SimpleStringProperty(house);
        tenantProperty = new SimpleStringProperty(tenant);
        spaceProperty = new SimpleStringProperty(space);
        rentProperty = new SimpleIntegerProperty(rent);
        dueProperty = new SimpleDoubleProperty(due);
    }

    public String getHouse(){
        return houseProperty.get();
    }

    public void setHouse(String value){
        houseProperty.set(value);
    }

    public String getTenant(){
        return tenantProperty.get();
    }

    public void setTenant(String value){
        tenantProperty.set(value);
    }

    public String getSpace(){
        return spaceProperty.get();
    }

    public void setSpace(String value){
        spaceProperty.set(value);
    }

    public int getRent(){
        return rentProperty.get();
    }

    public void setRent(int value){
        rentProperty.set(value);
    }

    public double getDue(){
        return dueProperty.get();
    }

    public void setDue(double value){
        dueProperty.set(value);
    }

    @Override
    public String toString() {
        return "House: " + houseProperty.get() +
                " Tenant: " + tenantProperty.get() +
                " Space: " + spaceProperty.get() +
                " Rent: " + rentProperty.get() +
                " Due: " + dueProperty.get();
    }
}

package model;

public class PinColumnSeries {
    private double pin, column;

    public PinColumnSeries(double pin, double column) {
        this.pin = pin;
        this.column = column;
    }

    public double getPin() {
        return pin;
    }

    public double getColumn() {
        return column;
    }
    
}

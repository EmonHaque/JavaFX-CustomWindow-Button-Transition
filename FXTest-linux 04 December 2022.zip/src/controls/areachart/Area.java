package controls.areachart;

import java.util.Comparator;
import java.util.List;

import javafx.animation.FadeTransition;
import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.Group;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Scale;
import javafx.util.Duration;

public class Area extends Region {
    private double minRadius = 3, maxRadius = 5;
    private int size;
    private boolean isLoaded;
    private AreaStroke stroke;
    private AreaFill fill;
    private Group circles;
    private List<Double> values;
    private double yMax, width, height, cursorX;

    private Timeline strokeAnim, fillAnim;
    private KeyFrame widthFrame, heightFrame;
    private FadeTransition circleAnim;
    private Rectangle widthClip, heightClip;
    private Line cursor;

    public ObjectProperty<List<Double>> seriesProperty; // take some sort of series with label

    public Area() {
        cursor = new Line();
        cursor.setStroke(Color.WHITE);
        cursor.getStrokeDashArray().addAll(5d, 2d);
        cursor.setManaged(false);
        cursor.setMouseTransparent(true);

        circles = new Group();
        stroke = new AreaStroke();
        fill = new AreaFill();

        stroke.setManaged(false);
        fill.setManaged(false);
        circles.setManaged(false);

        stroke.setMouseTransparent(true);
        fill.setMouseTransparent(false);

        stroke.getTransforms().add(new Scale(1, -1));
        fill.getTransforms().add(new Scale(1, -1));
        getChildren().addAll(fill, stroke, circles);

        widthClip = new Rectangle(0, 0, 0, 0);
        heightClip = new Rectangle(0, 0, 0, 0);
        stroke.setClip(widthClip);
        fill.setClip(heightClip);

        seriesProperty = new SimpleObjectProperty<>();
        seriesProperty.addListener(this::onSeriesChanged);

        strokeAnim = new Timeline();
        fillAnim = new Timeline();
        circleAnim = new FadeTransition(Duration.millis(1000), circles);
        circleAnim.setDelay(Duration.seconds(1));
        circleAnim.setToValue(1);

        strokeAnim.setOnFinished(e -> stroke.setClip(null));
        fillAnim.setOnFinished(e -> fill.setClip(null));

        setOnMouseEntered(this::onMouseEnter);
        setOnMouseMoved(this::onMouseMove);
        setOnMouseExited(this::onMouseExit);
        getChildren().add(cursor);
    }

    private void onMouseEnter(MouseEvent e) {
        cursor.setVisible(true);
    }

    private void onMouseMove(MouseEvent e) {
        cursorX = e.getX();
        if (cursorX < 0 || cursorX > width)
            return;

        cursor.setStartX(cursorX);
        cursor.setEndX(cursorX);
        cursor.setStartY(0);
        cursor.setEndY(height);

        for (var c : circles.getChildren()) {
            var circle = (Circle) c;
            var bounds = c.getBoundsInLocal();
            if (cursorX >= bounds.getMinX() && cursorX <= bounds.getMaxX()) {
                circle.setFill(Color.WHITE);
                circle.setRadius(maxRadius);
                cursor.setStroke(Color.CORAL);
            }
            else {
                if (circle.getRadius() == maxRadius) {
                    circle.setFill(Color.CORAL);
                    circle.setRadius(minRadius);
                    cursor.setStroke(Color.WHITE);
                }
            }
        }

    }

    private void onMouseExit(MouseEvent e) {
        cursor.setVisible(false);
        int index = e.getX() < 0 ? 0 : circles.getChildren().size() - 1;
        var circle = (Circle) circles.getChildren().get(index);
        if (circle.getRadius() == maxRadius) {
            circle.setRadius(minRadius);
            circle.setFill(Color.CORAL);
        }
    }

    private void onSeriesChanged(ObservableValue<?> obs, List<Double> ov, List<Double> nv) {
        circles.getChildren().clear();
        circles.setOpacity(0);
        if (nv == null) {
            stroke.clear();
            fill.clear();
            return;
        }
        stroke.setData(nv);
        fill.setData(nv);
        values = nv;
        size = values.size();
        yMax = values.stream().max(Comparator.comparingDouble(x -> x)).get();
        for (int i = 0; i < size; i++) {
            var circle = new Circle();
            circle.setRadius(minRadius);
            circle.setFill(Color.CORAL);
            circles.getChildren().add(circle);
            circle.setManaged(false);
        }
        if (isLoaded){
            resetAnim();
            fillAnim.play();
            strokeAnim.play();
            requestLayout();
        }
        circleAnim.play();
    }

    private void resetAnim(){
        widthClip.setWidth(0);
        widthClip.setHeight(height);
        heightClip.setHeight(0);
        heightClip.setWidth(width);
        stroke.setClip(widthClip);
        fill.setClip(heightClip);

        strokeAnim.getKeyFrames().clear();
        fillAnim.getKeyFrames().clear();
        var widthkey = new KeyValue(widthClip.widthProperty(), width, Interpolator.EASE_IN);
        var heightKey = new KeyValue(heightClip.heightProperty(), height, Interpolator.EASE_IN);
        widthFrame = new KeyFrame(Duration.millis(1000), widthkey);
        heightFrame = new KeyFrame(Duration.millis(1000), heightKey);
        strokeAnim.getKeyFrames().add(widthFrame);
        fillAnim.getKeyFrames().add(heightFrame);
    }

    @Override
    protected void layoutChildren() {
        width = getWidth();
        height = getHeight();
        if (!isLoaded){
            isLoaded = true;
            resetAnim();
            fillAnim.play();
            strokeAnim.play();
        }
        fill.setTranslateY(height);
        stroke.setTranslateY(height);

        fill.setValue(width, height, yMax); // same computation thrice
        stroke.setValue(width, height, yMax); // same computation thrice

        double xGap = width / (size - 1);
        double yFactor = height / yMax;
        double x = 0, y;
        for (int i = 0; i < size; i++) {
            // same computation thrice
            y = height - (values.get(i) * yFactor);
            var circle = (Circle) circles.getChildren().get(i);
            circle.setCenterX(x);
            circle.setCenterY(y);
            x += xGap;
        }
    }
}

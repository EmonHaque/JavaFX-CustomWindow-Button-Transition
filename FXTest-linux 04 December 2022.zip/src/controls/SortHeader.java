package controls;

import helpers.Icons;
import interfaces.IExecute;
import javafx.animation.Animation;
import javafx.animation.FillTransition;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class SortHeader extends Group {
    private SVGIcon icon;
    private Text text;
    private IExecute function;
    private FillTransition anim;

    public SortHeader(String name, boolean isIconFirst, IExecute function) {
        this.function = function;
        icon = new SVGIcon(Icons.Sort);
        text = new Text(name);
        text.setFill(Color.WHITE);
        var box = new HBox();
        if (isIconFirst) {
            box.getChildren().addAll(icon, text);
        }
        else {
            box.getChildren().addAll(text, icon);
        }
        box.setSpacing(2);
        box.setAlignment(Pos.CENTER);
        getChildren().add(box);

        anim = new FillTransition(Duration.millis(300));
        anim.setShape(icon);

        setOnMouseEntered(e -> animate(Color.CORAL));
        setOnMouseExited(e -> animate(Color.WHITE));
        setOnMouseClicked(this::execute);
    }

    private void animate(Color color) {
        if (anim.getStatus() == Animation.Status.RUNNING)
            anim.stop();
        anim.setToValue(color);
        anim.play();
    }

    private void execute(MouseEvent e) {
        if (function != null)
            function.execute();
    }
}

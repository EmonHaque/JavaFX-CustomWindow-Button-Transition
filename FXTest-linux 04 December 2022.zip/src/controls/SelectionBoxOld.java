package controls;

import controls.buttons.ActionButton;
import helpers.Constants;
import helpers.Icons;
import interfaces.ISetSelectionBoxContent;
import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.animation.TranslateTransition;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Popup;
import javafx.util.Duration;
import skinned.ExtendedResizableListView;
import skinned.ExtendedTextField;

public class SelectionBoxOld<T> extends GridPane {
    private Popup popup;
    private HBox selectedBox;
    private ExtendedTextField input;
    private ExtendedResizableListView<T> listView;
    private Label hintLabel;
    private ActionButton close, open;
    private SVGIcon leftIcon;
    private RotateTransition rotationAnim;
    private TranslateTransition moveHint;
    private boolean isHintMoved;
    private boolean isOpen = false;

    public StringProperty query;
    public ObjectProperty<T> selectedItem;
    
    public SelectionBoxOld(String hint, String icon, FilteredList<T> list, ISetSelectionBoxContent<T> visual) {
        //this.visual = visual;
        listView = new ExtendedResizableListView<T>(list);
        listView.setBorder(Constants.BottomLine);
        listView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        listView.setMaxHeight(200);
        listView.setBackground(new Background(new BackgroundFill(Constants.BackgroundColor, null, null)));
        listView.setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID,
                new CornerRadii(5, 5, 5, 5, false), new BorderWidths(0.25))));
        
        popup = new Popup();
        popup.getContent().add(listView);
        popup.setAutoHide(true);

        open = new ActionButton(Icons.DownArrow, 16, "show");
        close = new ActionButton(Icons.CloseCircle, 16, "remove");

        selectedBox = new HBox();
        var personVisual = visual.getVisual();
        HBox.setHgrow(personVisual, Priority.ALWAYS);
        selectedBox.setAlignment(Pos.CENTER);
        selectedBox.getChildren().addAll(personVisual, close);

        selectedBox.setPadding(new Insets(0, 0, 0, 5));
        selectedBox.setVisible(false);
        selectedBox.setBackground(new Background(new BackgroundFill(Constants.BackgroundColorLight, new CornerRadii(5), null)));
        setMargin(selectedBox, new Insets(0, 5, 0, 5));

        input = new ExtendedTextField();

        hintLabel = new Label(hint);
        hintLabel.setTextFill(Color.GRAY);
        setBorder(Constants.BottomLine);

        leftIcon = new SVGIcon(icon);
        addRow(0, leftIcon, input, open);
        add(selectedBox, 1, 0);

        setMargin(hintLabel, new Insets(0, 0, 0, 5));
        add(hintLabel, 1, 0);

        setHgrow(input, Priority.ALWAYS);
        query = input.textProperty();
        selectedItem = new SimpleObjectProperty<T>();
        input.textProperty().addListener(this::onTextChanged);

        open.setAction(this::showPopup);

        rotationAnim = new RotateTransition(Duration.millis(500));
        rotationAnim.setNode(open);
        moveHint = new TranslateTransition(Duration.millis(100));
        moveHint.setInterpolator(Interpolator.EASE_IN);
        moveHint.setNode(hintLabel);

        popup.setOnShowing(e -> {
            rotationAnim.setToAngle(180);
            rotationAnim.play();
            open.setTip("close");
            isOpen = true;
        });
        popup.setOnHiding(e -> {
            rotationAnim.setToAngle(0);
            rotationAnim.play();
            open.setTip("show");
            isOpen = false;
        });

        listView.setOnKeyReleased(e -> {
            if (e.getCode() == KeyCode.ENTER) {
                var selected = listView.getSelectionModel().getSelectedItem();
                if (selected != null) {
                    visual.setContent(selected);
                    input.setText("");
                    input.setVisible(false);
                    selectedBox.setVisible(true);
                }
                popup.hide();
                selectedItem.set(selected);
            }
        });
        if (list.size() > 0) {
            listView.getSelectionModel().selectFirst();
            var selected = listView.getSelectionModel().getSelectedItem();
            if (selected != null) {
                visual.setContent(selected);
                input.setText("");
                input.setVisible(false);
                selectedBox.setVisible(true);
                selectedItem.set(selected);
                moveHintUp();
            }
        }
        close.setAction(this::removeSelected);
        selectedBox.setOnMouseClicked(e -> {
            if (isOpen)
                popup.hide();
            else
                showPopup();

        });
        listView.setOnMouseClicked(e -> {
            var selected = listView.getSelectionModel().getSelectedItem();
            if (selected != null) {
                visual.setContent(selected);
                input.setText("");
                input.setVisible(false);
                selectedBox.setVisible(true);
                selectedItem.set(selected);
                if(!isHintMoved){
                    moveHintUp();
                }
            }
            popup.hide();
        });
        setAlignment(Pos.BOTTOM_LEFT);
        setMinHeight(40);
        addEventHandler(MouseEvent.ANY, this::onMouseEvents);
    }

    void removeSelected() {
        selectedBox.setVisible(false);
        input.setVisible(true);
        input.requestFocus();
        showPopup();
        selectedItem.set(null);
    }

    public ListView<T> getView() {
        return listView;
    }

    void onTextChanged(ObservableValue<? extends String> observable, String oldValue, String newValue) {
        if (!isOpen) {
            showPopup();
        }
    }

    void showPopup() {
        var point = input.localToScreen(0, 0);
        listView.setMinWidth(input.getWidth());   
        popup.show(getScene().getWindow(), point.getX(), point.getY() + input.getHeight());
    }

    void onMouseEvents(MouseEvent e) {
        if (moveHint.getStatus() == Animation.Status.RUNNING)
            return;

        if (e.getEventType() == MouseEvent.MOUSE_ENTERED) {
            setFocusColor();
            if (!selectedBox.isVisible() && input.getText().isEmpty()) {
                if (!isHintMoved)
                    moveHintUp();
                input.requestFocus();
            }
        }
        else if (e.getEventType() == MouseEvent.MOUSE_EXITED) {
            resetFocusColor();
            if (!selectedBox.isVisible() && input.getText().isEmpty()) {
                if (isHintMoved)
                    moveHintDown();
                leftIcon.requestFocus();
            }
        }
    }
    
    void setFocusColor() {
        leftIcon.setFill(Color.CORNFLOWERBLUE);
        setBorder(Constants.BottomLineHighlight);
    }

    void resetFocusColor() {
        leftIcon.setFill(Color.LIGHTBLUE);
        setBorder(Constants.BottomLine);
    }

    void moveHintUp() {
        if ( moveHint.getStatus() == Animation.Status.RUNNING) {
            moveHint.stop();
        }
        var x = Constants.hintShiftX + hintLabel.getTranslateX();
        var y = Constants.hintShiftY + hintLabel.getTranslateY();
        moveHint.setByY(-y);
        moveHint.setByX(-x);
        moveHint.play();
        isHintMoved = true;
    }

    void moveHintDown() {
        if (moveHint.getStatus() == Animation.Status.RUNNING) {
            moveHint.stop();
        }
        moveHint.setByY(-hintLabel.getTranslateY());
        moveHint.setByX(-hintLabel.getTranslateX());
        moveHint.play();
        isHintMoved = false;
    }

}

package abstracts;

import controls.SVGIcon;
import helpers.Constants;
import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.TranslateTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.util.Duration;

public class HintedControlBase extends GridPane {
    private Label hintLabel;
    protected TranslateTransition moveHint;

    protected SVGIcon leftIcon;
    protected boolean isHintMoved;

    public HintedControlBase(String hint, String icon) {
        hintLabel = new Label(hint);
        hintLabel.setTextFill(Color.GRAY);
        hintLabel.setMouseTransparent(true);

        leftIcon = new SVGIcon(icon);
        leftIcon.setFill(Color.LIGHTBLUE);
        leftIcon.setMouseTransparent(true);
       
        addRow(0, leftIcon);
        add(hintLabel, 1, 0);
        setAlignment(Pos.BOTTOM_LEFT);
        setMargin(hintLabel, new Insets(0, 0, 0, 5));
        setBorder(Constants.BottomLine);
        setMinHeight(40);

        moveHint = new TranslateTransition(Duration.millis(100));
        moveHint.setInterpolator(Interpolator.EASE_IN);
        moveHint.setNode(hintLabel);
    }

    protected void moveHintUp() {
        if (moveHint.getStatus() == Animation.Status.RUNNING) {
            moveHint.stop();
        }
        var x = Constants.hintShiftX + hintLabel.getTranslateX();
        var y = Constants.hintShiftY + hintLabel.getTranslateY();
        moveHint.setByY(-y);
        moveHint.setByX(-x);
        moveHint.play();
        isHintMoved = true;
    }

    protected void moveHintDown() {
        if (moveHint.getStatus() == Animation.Status.RUNNING) {
            moveHint.stop();
        }
        moveHint.setByY(-hintLabel.getTranslateY());
        moveHint.setByX(-hintLabel.getTranslateX());
        moveHint.play();
        isHintMoved = false;
    }

    protected void setFocusColor() {
        leftIcon.setFill(Color.CORNFLOWERBLUE);
        setBorder(Constants.BottomLineHighlight);
    }

    protected void resetFocusColor() {
        leftIcon.setFill(Color.LIGHTBLUE);
        setBorder(Constants.BottomLine);
    }
}

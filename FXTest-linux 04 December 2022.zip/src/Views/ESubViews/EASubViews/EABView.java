package Views.ESubViews.EASubViews;

import abstracts.View;
import controls.SumBox;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import model.Person3;
import templates.Person3Template;
import viewModels.EViewModels.EAAViewModels.EABViewVM;

public class EABView extends View {
    EABViewVM vm;

    @Override
    protected String getHeader() {
        return "EAB View";
    }

    @Override
    protected String getIcon() {
        return Icons.BCircle;
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight EAB View");

        vm = new EABViewVM();

        var box1 = new SumBox<String>(vm.stringSuggest, null, null);
        var box2 = new SumBox<Person3>(vm.templateSuggest, "Name", Person3Template.class.getName());

        var grid = new GridPane();
        grid.setHgap(20);
        grid.add(box1, 0, 0);
        grid.add(box2, 1, 0);

        var colCon = new ColumnConstraints();
        colCon.setPercentWidth(50);
        grid.getColumnConstraints().addAll(colCon, colCon);
        
        BorderPane.setMargin(grid, new Insets(5,0,0,0));
        setCenter(grid);
    }
}

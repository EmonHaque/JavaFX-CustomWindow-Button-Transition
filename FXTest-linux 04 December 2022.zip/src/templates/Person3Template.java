package templates;

import controls.texts.HiText;
import helpers.Constants;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.layout.Background;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import model.Person3;

public class Person3Template extends ListCell<Person3> {
    private StringProperty query;
    private HBox box;
    private HiText hiName;
    private Text name, phone;
    private Region spacer;

    public Person3Template(StringProperty query) {
        this.query = query;
        setBackground(null);
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        
        initializeUI();
        itemProperty().addListener(this::onItemChanged);
    }

    private void initializeUI() {
        hiName = new HiText();
        name = new Text();
        phone = new Text();

        name.setFill(Color.WHITE);
        phone.setFill(Color.WHITE);

        spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        box = new HBox(hiName, spacer, phone);
    }

    private void onItemChanged(ObservableValue<?> o, Person3 ov, Person3 nv) {
        if(ov != null){
            hiName.clear();
            hiName.query.unbind();
            hiName.query.set("");

            name.setText(null);
            phone.setText(null);            
        }
        if (nv != null) {
            hiName.add(name);
            name.setText(nv.getName());
            phone.setText(nv.getPhone());

            hiName.query.set(query.get());
            hiName.query.bind(query);
        }
    }

    @Override
    protected void updateItem(Person3 item, boolean empty) {
        super.updateItem(item, empty);
        if (empty) {
            setGraphic(null);
        }
        else {
            setGraphic(box);
            setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
        }
    }
}

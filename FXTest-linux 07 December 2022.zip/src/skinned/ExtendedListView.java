package skinned;

import javafx.collections.ObservableList;
import javafx.scene.control.ListView;
import javafx.scene.control.Skin;
import skins.ExtendedListViewSkin;

public class ExtendedListView<T> extends ListView<T> {
    public ExtendedListView(ObservableList<T> list) {
        super(list);
        setBackground(null);
    }
    @Override
    protected Skin<?> createDefaultSkin() {
        return new ExtendedListViewSkin<>(this);
    }
}
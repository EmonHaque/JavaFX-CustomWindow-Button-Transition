package abstracts;

import controls.buttons.ActionButton;
import enums.NavOverlap;
import enums.NavPosition;
import helpers.Constants;
import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.TranslateTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

public class ViewContainer extends BorderPane {
    public String icon;
    public String toolTip;
    private GridPane navbar;
    private StackPane containers;
    private int currentIndex;
    private TranslateTransition getIn, getOut;
    private NavPosition navPosition;
    private NavOverlap overlap;
    boolean isLoaded;
    public double iconSize = 16;
    public boolean isMarginLess = false;
    double margin = Constants.CardMargin;;

    public View initialView() {
        /* virtual */ return null;
    }

    protected String getIcon() {
        /* virtual */ return null;
    }

    protected String getTip() {
        /* virtual */ return null;
    }

    public ViewContainer() {
        navPosition = NavPosition.BottomRightVertical;
        overlap = NavOverlap.None;
        initialize();
    }

    public ViewContainer(NavPosition navPosition, NavOverlap overlap) {
        this.navPosition = navPosition;
        this.overlap = overlap;
        initialize();
    }

    private void initialize() {
        icon = getIcon();
        toolTip = getTip();
        containers = new StackPane();
        addNavBar(navPosition);
        setCenter(containers);
        initializeAnimations();
        addClicp();
        setPickOnBounds(false);
        setBackground(null);
    }

    public void addView(View view) {
        var button = new ActionButton(view.icon, iconSize, view.toolTip);
        button.setOnMouseClicked(this::setView);

        switch (navPosition) {
            case TopLeftHorizontal:
            case TopRightHorizontal:
            case TopCenter:
            case BottomRightHorizontal:
            case BottomLeftHorizontal:
            case BottomCenter:
                navbar.add(button, navbar.getColumnCount(), 0);
                break;
            default:
                navbar.add(button, 0, navbar.getRowCount());
                break;
        }
        containers.getChildren().add(view);
        if (!view.isContainer()) {
            StackPane.setMargin(view, new Insets(Constants.CardMargin));
        }
        if (containers.getChildren().size() == 1) {
            button.setActive(true);
        }
        else {
            view.setVisible(false);
        }
    }

    void initializeAnimations() {
        getIn = new TranslateTransition(Duration.seconds(1));
        getOut = new TranslateTransition(Duration.seconds(1));
        getIn.setInterpolator(Interpolator.EASE_BOTH);
        getOut.setInterpolator(Interpolator.EASE_BOTH);
    }

    void setView(MouseEvent e) {
        if (getIn.getStatus() == Animation.Status.RUNNING)
            return;

        var index = navbar.getChildren().indexOf(e.getSource());
        if (index == currentIndex)
            return;

        var in = containers.getChildren().get(index);
        var out = containers.getChildren().get(currentIndex);

        switch (navPosition) {
            case TopRightVertical:
            case BottomRightVertical:
            case RightCenter:
            case TopLeftVertical:
            case BottomLeftVertical:
            case LeftCenter:
                double height = getHeight();
                if (index > currentIndex) {
                    in.translateYProperty().set(height);
                    getIn.setByY(-height);
                    getOut.setByY(-height);
                }
                else {
                    in.translateYProperty().set(-height);
                    getIn.setByY(height);
                    getOut.setByY(height);
                }
                break;

            default:
                double width = getWidth();
                if (index > currentIndex) {
                    in.translateXProperty().set(width);
                    getIn.setByX(-width);
                    getOut.setByX(-width);
                }
                else {
                    in.translateXProperty().set(-width);
                    getIn.setByX(width);
                    getOut.setByX(width);
                }
                break;
        }

        in.setVisible(true);
        getIn.setNode(in);
        getOut.setNode(out);
        getIn.play();
        getOut.play();

        var deactivate = (ActionButton) navbar.getChildren().get(currentIndex);
        var activate = (ActionButton) navbar.getChildren().get(index);

        var view = (View) in;
        if (view.initialViews() != null) {
            if (!view.isSeen) {
                var views = view.initialViews();
                for (View subView : views) {
                    if (!subView.isSeen)
                        subView.onFirstSight();
                }
            }
        }
        if (!view.isSeen)
            view.onFirstSight();

        getIn.setOnFinished(event -> {
            deactivate.setActive(false);
            activate.setActive(true);
            out.setVisible(false);
            currentIndex = index;
            getIn.setOnFinished(null);
        });
    }

    private void addNavBar(NavPosition pos) {
        navbar = new GridPane();
        navbar.setBackground(null);
        navbar.setPickOnBounds(false);

        switch (pos) {
            case TopLeftHorizontal:
            case TopRightHorizontal:
            case TopCenter:
                BorderPane.setMargin(navbar, new Insets(margin, margin, 0, margin));
                setTop(navbar);
                break;
            case BottomLeftHorizontal:
            case BottomRightHorizontal:
            case BottomCenter:
                BorderPane.setMargin(navbar, new Insets(0, margin, margin, margin));
                setBottom(navbar);
                break;
            case TopRightVertical:
            case BottomRightVertical:
            case RightCenter:
                BorderPane.setMargin(navbar, new Insets(margin, margin, margin, 0));
                setRight(navbar);
                break;
            case TopLeftVertical:
            case BottomLeftVertical:
            case LeftCenter:
                BorderPane.setMargin(navbar, new Insets(margin, 0, margin, margin));
                setLeft(navbar);
                break;
        }

        switch (pos) {
            case TopRightHorizontal:
            case BottomRightHorizontal:
                navbar.setAlignment(Pos.CENTER_RIGHT);
                break;
            case TopLeftHorizontal:
            case BottomLeftHorizontal:
                navbar.setAlignment(Pos.CENTER_LEFT);
                break;
            case TopLeftVertical:
            case TopRightVertical:
                navbar.setAlignment(Pos.TOP_CENTER);
                break;
            case BottomLeftVertical:
            case BottomRightVertical:
                navbar.setAlignment(Pos.BOTTOM_CENTER);
                break;
            case TopCenter:
            case BottomCenter:
            case RightCenter:
            case LeftCenter:
                navbar.setAlignment(Pos.CENTER);
                break;
        }
    }

    @Override
    protected void layoutChildren() {
        if (!isLoaded) {
            isLoaded = true;
            if (overlap != NavOverlap.None) {
                switch (overlap) {
                    case Right:
                        BorderPane.setMargin(navbar, new Insets(margin, -navbar.prefWidth(-1) / 2, margin, 0));
                        break;
                    case Left:
                        BorderPane.setMargin(navbar, new Insets(margin, 0, margin, -navbar.prefWidth(-1) / 2));
                        break;
                    case Top:
                        BorderPane.setMargin(navbar, new Insets(-navbar.prefHeight(-1) / 2, margin, 0, margin));
                        break;
                    case Bottom:
                        BorderPane.setMargin(navbar, new Insets(0, margin, -navbar.prefHeight(-1) / 2, margin));
                        break;
                    default:
                        break;
                }
            }
            else {
                if (isMarginLess) {
                    switch (navPosition) {
                        case TopLeftHorizontal:
                        case TopRightHorizontal:
                        case TopCenter:
                        case BottomLeftHorizontal:
                        case BottomRightHorizontal:
                        case BottomCenter:
                            BorderPane.setMargin(navbar, new Insets(0, margin, 0, margin));
                            break;
                        default:
                            BorderPane.setMargin(navbar, new Insets(margin, 0, margin, 0));
                            break;
                    }
                }
            }
        }
        super.layoutChildren();
    }

    private void addClicp() {
        var clip = new Rectangle();
        containers.layoutBoundsProperty().addListener((observable, oldValue, newValue) -> {
            clip.setWidth(newValue.getWidth());
            clip.setHeight(newValue.getHeight());
        });
        containers.setClip(clip);
    }
}

package viewModels.CViewModels;

import java.util.Comparator;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Person2;

public class CAViewModel {
    private boolean isNameSorted, isAgeSorted, isGenderSorted;
    public ObservableList<Person2> people;
    public static ObjectProperty<Person2> selected;

    public CAViewModel() {
        selected = new SimpleObjectProperty<>();
        people = FXCollections.observableArrayList();
        for (int i = 0; i < 30; i++) {
            var p = new Person2("Person " + i, i, i % 2 == 0);
            people.add(p);
        }
    }

    public void sortName() {
        if(!isNameSorted){
            isNameSorted = true;
            people.sort(Comparator.comparing(Person2::getName, Comparator.reverseOrder()));
        }
        else{
            isNameSorted = false;
            people.sort(Comparator.comparing(Person2::getName));
        }
    }

    public void sortAge() {
        if(!isAgeSorted){
            isAgeSorted = true;
            people.sort(Comparator.comparing(Person2::getAge, Comparator.reverseOrder()));
        }
        else{
            isAgeSorted = false;
            people.sort(Comparator.comparing(Person2::getAge));
        }
    }

    public void sortGender() {
        if(!isGenderSorted){
            isGenderSorted = true;
            people.sort(Comparator.comparing(Person2::getGender, Comparator.reverseOrder()));
        }
        else{
            isGenderSorted = false;
            people.sort(Comparator.comparing(Person2::getGender));
        }
    }
}

package Views.FSubViews;

import abstracts.View;
import controls.TextInfo;
import controls.buttons.ActionButton;
import controls.texts.TextBoxMultiLine;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import viewModels.FViewModels.FABViewVM;

public class FABView extends View {
    private ActionButton save;
    private TextBoxMultiLine textBox;
    private TextInfo info;
    private FABViewVM vm;

    @Override
    protected String getHeader() {
        return "FAB View";
    }

    @Override
    protected String getIcon() {
        return Icons.BCircle;
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight FAB View");

        vm = new FABViewVM();
        initializeUI();
        bind();
    }

    private void initializeUI() {
        save = new ActionButton(Icons.Save, 16, "save");
        textBox = new TextBoxMultiLine("Content", Icons.Text);
        info = new TextInfo();
        // info.setFill(Color.WHITE);
        addAction(save);

        var box = new VBox(textBox, info);
        VBox.setVgrow(textBox, Priority.ALWAYS);
        BorderPane.setMargin(box, new Insets(5,0,0,0));
        setCenter(box);
    }

    private void bind(){
        save.setAction(vm::save);
        vm.contentProperty.bind(textBox.textProperty);
        info.textProperty().bindBidirectional(vm.messageProperty);
    }
}

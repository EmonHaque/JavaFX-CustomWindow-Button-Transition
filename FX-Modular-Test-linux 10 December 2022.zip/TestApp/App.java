import Views.*;
import controls.MainPanel;
import controls.Window;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import viewModels.GViewModels.GService;

public class App extends ClientApp {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    protected Image getIcon() {
        return new Image("resources/images/icon.png");
    }

    @Override
    protected String getTitle() {
        return "Java FX";
    }

    @Override
    protected Window getWindow(Stage stage) {
        var panel = new MainPanel(stage);
        panel.addView(new AView());
        panel.addView(new BView());
        panel.addView(new CView());
        panel.addView(new DView());
        panel.addView(new EView());
        panel.addView(new FView());
        panel.addView(new GView());
        panel.setTitle(getTitle());

        var window = new Window(stage, getTitle());
        window.setContent(panel);
        return window;
    }

    @Override
    public void stop() throws Exception {
        GService.shutDown();
        super.stop();
    }
}

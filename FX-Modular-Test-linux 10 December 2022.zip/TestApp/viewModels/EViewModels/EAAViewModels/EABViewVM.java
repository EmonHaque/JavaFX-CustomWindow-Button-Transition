package viewModels.EViewModels.EAAViewModels;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Person3;

public class EABViewVM {
    public ObservableList<String> stringSuggest;
    public ObservableList<Person3> templateSuggest;

    public EABViewVM() {
        stringSuggest = FXCollections.observableArrayList(
            "Hello",
            "What",
            "How",
            "When",
            "Who"
        );
        templateSuggest = FXCollections.observableArrayList(
            new Person3("First Name", "5345345"),
            new Person3("Last Name", "78678678"),
            new Person3("Middle Name", "5645645"),
            new Person3("Test Name", "089098"),
            new Person3("Best Name", "1312312")
        );
    }
}

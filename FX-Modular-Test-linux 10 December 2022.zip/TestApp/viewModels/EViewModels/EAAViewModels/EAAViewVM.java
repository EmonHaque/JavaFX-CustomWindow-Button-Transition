package viewModels.EViewModels.EAAViewModels;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Person3;
import model.Tenant;

public class EAAViewVM {
    public Tenant tenant;
    public ObservableList<String> houseSuggest, spaceSuggest;
    public ObservableList<Person3> tenantSuggest;

    public EAAViewVM() {
        tenant = new Tenant();
        houseSuggest = FXCollections.observableArrayList();
        spaceSuggest = FXCollections.observableArrayList();
        tenantSuggest = FXCollections.observableArrayList();
        for (int i = 0; i < 50; i++) {
            houseSuggest.addAll("House " + i);
            spaceSuggest.add("Space " + i);
            tenantSuggest.add(new Person3("Test Name " + i, "1234"));
        }
    }

    public void addTenant() {
        System.out.println("added: " + tenant);
        tenant.houseProperty.set(null);
        tenant.tenantProperty.set(null);
        tenant.spaceProperty.set(null);
        tenant.rentProperty.set(0);
        tenant.dueProperty.set(0);
    }
}

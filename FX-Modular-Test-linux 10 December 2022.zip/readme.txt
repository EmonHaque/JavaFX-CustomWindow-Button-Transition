Distro: Void Linux x64/glibc 
Kernel: 6.0.11_1
DE: X11/GNOME 42.6
Resolution: 3840 x 2160
Scaling: 200%
Refresh rate: 29.97 Hz
CPU: Intel Core i3 10100F x 8
GPU: NVIDIA GeForce GT 730 (kepler)
IDE: IntelliJ IDEA 2022.3 (Community Edition)
openjdk 17
JavaFX 19
==========================================================


=============== noobs ====================================
1) add global FX19 library (javafx19).

2) Create an empty Java project, add App and Launcher classes in root. In both Launcher.java and App.java add psvm and call App.main(args) in Launcher's main. Edit the configuaration. Put Launcher as the MainClass and add vm args (module-path and add-modules). Test run to see whether works, add some sout in App.java's psvm.

3) in module settings of the project add Controls module (Controls folder)

4) let App.java extend ClientApp (of Controls module) and implements those abstract methods.

5) for resources add a folder/package named resources. No need for src.

6) see TestApp project structure.

7) also change all controls names eg, Buttons as Joker, ListView as NPC, checkbox as Queen, ... King, Prince, Princess as those default names, given by fx team, doesn't fit in a Scene on a Stage! 

8) rename Window class to Drama or Episode..., to have a Drama in the Scene on the Stage.  
==========================================================

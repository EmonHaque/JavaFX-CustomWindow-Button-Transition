import controls.LoadingWindow;
import controls.Window;
import javafx.application.Application;
import javafx.concurrent.Task;
import javafx.concurrent.Worker;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public abstract class ClientApp extends Application {
    protected abstract Image getIcon();

    protected abstract String getTitle();

    protected abstract Window getWindow(Stage stage);

    @Override
    public void start(Stage stage) throws Exception {
        var loading = new LoadingWindow(getTitle(), getIcon());
        loading.show();
        var task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                for (int i = 0; i < 3; i++) {
                    updateMessage("Loading ... " + (i + 1));
                    Thread.sleep(3333);
                }
                return null;
            }
        };
        loading.messageProperty.bind(task.messageProperty());
        task.stateProperty().addListener((o, ov, nv) -> {
            if (nv == Worker.State.SUCCEEDED) {
                launchMain(stage);
                loading.close();
            }
        });
        new Thread(task).start();
    }

    private void launchMain(Stage stage) {
        stage.getIcons().add(getIcon());
        var window = getWindow(stage);
        window.show();
    }
}

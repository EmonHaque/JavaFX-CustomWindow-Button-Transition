package controls;

import abstracts.SelectionControlBase;
import helpers.Constants;
import helpers.Icons;
import interfaces.ISetSelectionBoxContent;
import javafx.animation.RotateTransition;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.transformation.FilteredList;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;
import javafx.stage.WindowEvent;
import javafx.util.Duration;
import skinned.ExtendedResizableListView;

public class SelectionBox<T> extends SelectionControlBase {
    private ExtendedResizableListView<T> listView;
    private ISetSelectionBoxContent<T> visual;
    private RotateTransition rotationAnim;
   
    public StringProperty query;
    public ObjectProperty<T> selectedItem;

    public SelectionBox(String hint, String leftIcon, FilteredList<T> list, ISetSelectionBoxContent<T> visual) {
        super(hint, leftIcon);
        super.setSelectedContent(visual.getVisual());
        this.visual = visual;

        listView = new ExtendedResizableListView<T>(list);
        listView.setBorder(Constants.BottomLine);
        listView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        listView.setMaxHeight(200);
        listView.setBackground(new Background(new BackgroundFill(Constants.BackgroundColor, null, null)));
        listView.setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.25))));

        popup.getContent().remove(0); // remove popupGrid
        popup.getContent().add(listView);

        query = input.textProperty();
        selectedItem = new SimpleObjectProperty<T>();
        rotationAnim = new RotateTransition(Duration.millis(500));
        rotationAnim.setNode(open);

        listView.setOnKeyReleased(this::onKeyReleasedOnListView);
        listView.setOnMouseClicked(this::onMouseClickedOnListView);
        if (list.size() > 0) {
            listView.getSelectionModel().selectFirst();
            var selected = listView.getSelectionModel().getSelectedItem();
            if (selected != null) {
                visual.setContent(selected);
                selectedItem.set(selected);
                super.onSelected();
            }
        }
    }

    @Override
    protected String getRightIcon() {
        return Icons.DownArrow;
    }

    @Override
    protected void removeSelected() {
        super.removeSelected();
        showPopup();
        selectedItem.set(null);
    }

    @Override
    protected void onPopupShowing(WindowEvent e) {
        super.onPopupShowing(e);
        rotationAnim.setToAngle(180);
        rotationAnim.play();
        open.setTip("close");
    }

    @Override
    protected void onPopupHiding(WindowEvent e) {
        super.onPopupHiding(e);
        rotationAnim.setToAngle(0);
        rotationAnim.play();
        open.setTip("show");
    }

    private void onKeyReleasedOnListView(KeyEvent e) {
        if (e.getCode() == KeyCode.ENTER) {
            var selected = listView.getSelectionModel().getSelectedItem();
            if (selected != null) {
                visual.setContent(selected);
            }
            super.onSelected();
            selectedItem.set(selected);
        }
    }

    private void onMouseClickedOnListView(MouseEvent e) {
        var selected = listView.getSelectionModel().getSelectedItem();
        if (selected != null) {
            visual.setContent(selected);
            selectedItem.set(selected);
        }
        super.onSelected();
    }

    private void showPopup() {
        var point = input.localToScreen(0, 0);
        listView.setMinWidth(input.getWidth());
        popup.show(getScene().getWindow(), point.getX(), point.getY() + input.getHeight());
    }

    public ListView<T> getView() {
        return listView;
    }
}

package model;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class SumBoxModel {
    public StringProperty key;
    public DoubleProperty value;

    public SumBoxModel(String key, double value) {
        this.key = new SimpleStringProperty(key);
        this.value = new SimpleDoubleProperty();
    }

    public String getKey() {
        return key.get();
    }

    public double getValue() {
        return value.get();
    }
}

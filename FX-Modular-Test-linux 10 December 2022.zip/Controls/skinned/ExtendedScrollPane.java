package skinned;

import javafx.scene.AccessibleAttribute;
import javafx.scene.Node;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import skins.ExtendedScrollBarSkin;

public class ExtendedScrollPane extends ScrollPane {
    boolean isLoaded;
    public ExtendedScrollPane() {
        super();
    }
    public ExtendedScrollPane(Node n) {
        super(n);
    }
    @Override
    protected void layoutChildren() {
        if(!isLoaded){
            isLoaded = true;
            applySkin();
        }
        super.layoutChildren();
    }
    private void applySkin() {
        setBackground(null);
        var port = (Region) lookup(".viewport");
        var corner = (StackPane) lookup(".corner");
        port.setBackground(null);
        corner.setBackground(null);
        
        // content.setBackground(null);
        // var content = (Region) getContent();
       
        var vBar = (ScrollBar) queryAccessibleAttribute(AccessibleAttribute.VERTICAL_SCROLLBAR);
        var hBar = (ScrollBar) queryAccessibleAttribute(AccessibleAttribute.HORIZONTAL_SCROLLBAR);
        vBar.setSkin(new ExtendedScrollBarSkin(vBar));
        hBar.setSkin(new ExtendedScrollBarSkin(hBar));
     }
}

package interfaces;

import javafx.scene.Node;

public interface ISetSelectionBoxContent<T> {
    void setContent(T item);
    Node getVisual();
}

package templates;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import model.Person;

public class PersonTemplate extends ListCell<Person> {
    @Override
    protected void updateItem(Person item, boolean empty) {
        super.updateItem(item, empty);
        if(empty) {
            setGraphic(null);
            setText(null);
        }
        else{
            setPrefWidth(0);
            var spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);
            var box = new HBox();
            box.setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, null, null)));
            box.getChildren().addAll(new Text(item.name), spacer, new Text(item.phone));
            setGraphic(box);
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        }
    }
}

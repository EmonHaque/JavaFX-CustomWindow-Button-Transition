package viewModels;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Person;

public class AViewModel {
    int count;
    public StringProperty labelTextProperty; // bound OneWay
    public StringProperty box1TextProperty; // bound OneWayToSource
    public StringProperty box2TextProperty; // bound TwoWay
    public ObservableList<Person> people;

    public AViewModel(){
        people = FXCollections.observableArrayList();
        for (int i = 0; i < 100; i++){
            var p = new Person();
            p.name = "Person " + i;
            p.phone = "0123456789";
            people.add(p);
        }
        labelTextProperty = new SimpleStringProperty();
        box1TextProperty = new SimpleStringProperty();
        box2TextProperty = new SimpleStringProperty();
    }
    public void setText(){
        var text = "Clicked " + ++count;
        labelTextProperty.set(text);
        System.out.println("Box 1: " + box1TextProperty.get());
        System.out.println("Box 2: " + box2TextProperty.get());
        box2TextProperty.set("");
    }
}

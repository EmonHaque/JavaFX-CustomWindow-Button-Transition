package controls;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import helpers.Icons;
import javafx.animation.Interpolator;
import javafx.animation.TranslateTransition;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.SVGPath;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import javafx.util.Duration;

public class MonthPicker extends GridPane {
    final String[] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    int year;
    Text yearText;
    Popup popup;
    GridPane popupGrid;
    ActionButton forward, backward;
    TextField input;
    Separator line;
    SVGPath leftIcon;
    ActionButton open, close;
    boolean isOpen = true;
    Label hintLabel;
    TranslateTransition moveHint;
    boolean isHintMoved;
    HBox selectedMonth;
    Text selectedText;
    DateTimeFormatter formatter;

    public MonthPicker(String hint) {
        popupGrid = new GridPane();
        popupGrid.setVgap(10);
        popupGrid.setHgap(10);
        popupGrid.setBackground(new Background(new BackgroundFill(Color.WHITESMOKE, new CornerRadii(5, false), null)));
        popupGrid.setEffect(new DropShadow());
        popupGrid.setPadding(new Insets(10));
        addTopSection();
        addMonths();
        popup = new Popup();
        popup.setAutoHide(true);
        popup.getContent().add(popupGrid);

        leftIcon = new SVGPath();
        leftIcon.setContent(Icons.Month);
        leftIcon.setFill(Color.LIGHTBLUE);
        input = new TextField();
        input.setBackground(null);
        input.setDisable(true);
        setHgrow(input, Priority.ALWAYS);
        open = new ActionButton(Icons.MonthPicker, 24, "show");
        addRow(0, leftIcon, input, open);
        hintLabel = new Label(hint);
        hintLabel.setTextFill(Color.GRAY);
        setMargin(hintLabel, new Insets(0,0,0,5));
        add(hintLabel,1,0);

        line = new Separator();
        line.setBorder(new Border(new BorderStroke(Color.LIGHTBLUE, Color.TRANSPARENT, Color.TRANSPARENT,Color.TRANSPARENT, BorderStrokeStyle.SOLID, BorderStrokeStyle.NONE,BorderStrokeStyle.NONE,BorderStrokeStyle.NONE, null, null, null)));
        setColumnSpan(line, 3);
        addRow(1, line);

        moveHint = new TranslateTransition(Duration.millis(100));
        moveHint.setInterpolator(Interpolator.EASE_IN);
        moveHint.setNode(hintLabel);
        setMinHeight(40);
        setAlignment(Pos.BOTTOM_LEFT);

        open.setAction(this::togglePopup);
        addEventHandler(MouseEvent.ANY, this::onMouseEvents);

        formatter = DateTimeFormatter.ofPattern("MMMM, yyyy");
        selectedText = new Text(formatter.format(LocalDate.now()));
        var spacer = new Region();
        close = new ActionButton(Icons.CloseCircle, 18, "remove");
        selectedMonth = new HBox(selectedText, spacer, close);
        HBox.setHgrow(spacer, Priority.ALWAYS);
        HBox.setMargin(selectedText, new Insets(0,0,0,5));
        selectedMonth.setAlignment(Pos.CENTER_LEFT);
        selectedMonth.setBackground(new Background(new BackgroundFill(Color.SNOW, new CornerRadii(5), null)));
        setMargin(selectedMonth, new Insets(0,5,0,5));
        add(selectedMonth, 1,0);
        close.setAction(this::removeSelected);
        moveHintUp();
        input.setOnKeyPressed(this::onInputKey);
    }
    void onInputKey(KeyEvent e){
        if(e.getCode() != KeyCode.ENTER) return;
        var splits = input.getText().split("/");
        int year = Integer.parseInt(splits[1]);
        int month = Integer.parseInt(splits[0]);
        var date =  LocalDate.of(year, month, 1);

        this.year = year;
        yearText.setText(splits[1]);
        selectedText.setText(formatter.format(date));
        input.setDisable(true);
        selectedMonth.setVisible(true);
    }
    void removeSelected(){
        input.setText("");
        selectedMonth.setVisible(false);
        input.setDisable(false);
        input.requestFocus();
    }
    void togglePopup(){
        isOpen = !isOpen;
        if(!isOpen) {
            var point = input.localToScreen(0,0);
            popup.show(input, point.getX(), point.getY() + input.getHeight());
        }
        else popup.hide();
    }
    void onMouseEvents(MouseEvent e){
        if(e.getEventType() == MouseEvent.MOUSE_ENTERED) {
            setFocusColor();
            if(!selectedMonth.isVisible() && input.getText().isEmpty()){
                moveHintUp();
                input.requestFocus();
            }
        }
        else if(e.getEventType() == MouseEvent.MOUSE_EXITED) {
            resetFocusColor();
            if(!selectedMonth.isVisible() && input.getText().isEmpty()){
                moveHintDown();
                leftIcon.requestFocus();
            }
        }
    }
    void addTopSection() {
        year = LocalDate.now().getYear();
        backward = new ActionButton(Icons.ScrollLeft, 24, "back");
        forward = new ActionButton(Icons.ScrollRight, 24, "forward");
        yearText = new Text(String.valueOf(year));
        yearText.setFont(Font.font(null, FontWeight.BOLD, 14));
        popupGrid.addRow(0, backward, yearText, forward);
        setColumnSpan(yearText, 2);
        setColumnIndex(forward, 3);

        var separator = new Separator();
        setColumnSpan(separator, 4);
        popupGrid.addRow(1, separator);
        GridPane.setHalignment(backward, HPos.LEFT);
        GridPane.setHalignment(yearText, HPos.CENTER);
        GridPane.setHalignment(forward, HPos.RIGHT);

        forward.setAction(this::increment);
        backward.setAction(this::decrement);
    }
    void addMonths() {
        int count = 0;
        for (int row = 2; row < 5; row++){
            for (int col = 0; col < 4; col++){
                var label = new MonthLabel(months[count]);
                label.setOnMouseClicked(this::onMonthClicked);
                popupGrid.add(label, col, row);
                count++;
            }
        }
    }
    void increment(){
        year++;
        yearText.setText(String.valueOf(year));
    }
    void decrement(){
        year--;
        yearText.setText(String.valueOf(year));
    }
    void setFocusColor(){
        leftIcon.setFill(Color.CORNFLOWERBLUE);
        line.setBorder(new Border(new BorderStroke(Color.CORNFLOWERBLUE, Color.TRANSPARENT, Color.TRANSPARENT,Color.TRANSPARENT, BorderStrokeStyle.SOLID, BorderStrokeStyle.NONE,BorderStrokeStyle.NONE,BorderStrokeStyle.NONE, null, null, null)));
    }
    void resetFocusColor(){
        leftIcon.setFill(Color.LIGHTBLUE);
        line.setBorder(new Border(new BorderStroke(Color.LIGHTBLUE, Color.TRANSPARENT, Color.TRANSPARENT,Color.TRANSPARENT, BorderStrokeStyle.SOLID, BorderStrokeStyle.NONE,BorderStrokeStyle.NONE,BorderStrokeStyle.NONE, null, null, null)));
    }
    void moveHintUp(){
        moveHint.setByY(-20);
        moveHint.setByX(-5);
        moveHint.play();
        isHintMoved = true;
    }
    void moveHintDown(){
        moveHint.setByY(20);
        moveHint.setByX(5);
        moveHint.play();
        isHintMoved = false;
    }
    void onMonthClicked(MouseEvent e){
        var month = (MonthLabel)e.getSource();
        var date =  LocalDate.of(year, month.monthNo, 1);
        selectedText.setText(formatter.format(date));
        if(!selectedMonth.isVisible()){
            moveHintUp();
            moveHint.setOnFinished(ev -> {
                selectedMonth.setVisible(true);
                moveHint.setOnFinished(null);
            });
        }
        popup.hide();
    }
}
package abstracts;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Separator;
import javafx.scene.effect.BlurType;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public abstract class View {
    String header;
    public String icon;
    public String toolTip;
    public VBox visual;
    public View(){
        icon = getIcon();
        header = getHeader();
        toolTip = getTip();
        visual = new VBox();
        visual.setBackground(new Background(new BackgroundFill(Color.WHITESMOKE, new CornerRadii(5, false), null)));
        visual.setPadding(new Insets(10));
        var effect = new DropShadow();
        effect.setOffsetX(0);
        effect.setOffsetY(0);
        effect.setRadius(5);
        effect.setBlurType(BlurType.GAUSSIAN);
        visual.setEffect(effect);

        var text = new Text(header);
        text.setFont(Font.font(Font.getDefault().getFamily(), FontWeight.BOLD, 14));
        text.setFill(Color.DARKGRAY);
        var line = new Separator();
        var content = getContent();
        VBox.setVgrow(content, Priority.ALWAYS);
        visual.getChildren().addAll(text, line, content);
    }
    protected abstract String getIcon();
    protected abstract String getHeader();
    protected abstract String getTip();
    protected abstract Node getContent();
}

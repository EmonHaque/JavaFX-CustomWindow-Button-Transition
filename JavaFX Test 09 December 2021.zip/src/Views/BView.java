package Views;

import abstracts.View;
import helpers.Icons;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

public class BView extends View {
    @Override
    protected String getIcon() {
        return Icons.Add;
    }

    @Override
    protected String getHeader() {
        return "B View";
    }

    @Override
    protected String getTip() {
        return "B View";
    }

    @Override
    protected Node getContent() {
        var box = new HBox();
        box.setAlignment(Pos.CENTER);
        var label = new Label("Content of B View");
        box.getChildren().add(label);
        return box;
    }
}

package Views;
import abstracts.View;
import controls.ActionButton;
import controls.MonthPicker;
import controls.SelectionBox;
import controls.TextBox;
import helpers.Icons;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import model.Person;
import templates.PersonTemplate;
import viewModels.AViewModel;

public class AView extends View {
    AViewModel vm;
    PersonTemplate temp;
    @Override
    protected String getIcon() {
        return Icons.Home;
    }
    @Override
    protected String getHeader() {
        return "A View";
    }
    @Override
    protected String getTip() { return "A View";}
    @Override
    protected Node getContent() {
        vm = new AViewModel();;
        var box = new VBox();
        box.setAlignment(Pos.CENTER);
        box.setSpacing(5);
        var label = new Label("Content of A View");
        label.setFont(Font.font(24));
        var button = new ActionButton(Icons.Add, 24, "Execute");
        button.setAction(vm::setText);
        var boundLabel = new Label("Test");
        var boundTextBox1 = new TextBox("Name", Icons.User);
        var boundTextBox2 = new TextBox("Password", Icons.Password);

        boundLabel.textProperty().bind(vm.labelTextProperty);
        // Binding Mode OneWayToSource
        vm.box1TextProperty.bind(boundTextBox1.textProperty);
        // Binding Mode TwoWay
        //vm.box2TextProperty.bindBidirectional(boundTextBox2.textProperty());
        boundTextBox2.textProperty.bindBidirectional(vm.box2TextProperty);

        temp = new PersonTemplate();
        var combo = new SelectionBox<Person>("Person", Icons.Tenant, vm.people, temp);
//        var listView = new ListView<>(vm.people);
//        listView.setBackground(null);
//        listView.setCellFactory(v -> new PersonTemplate());
        var monthPicker = new MonthPicker("Pick a month");
        box.getChildren().addAll(label, button, boundLabel, boundTextBox1, boundTextBox2, combo, monthPicker);
        return box;
    }
}

package Views;

import abstracts.View;
import controls.ActionButton;
import helpers.Icons;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import viewModels.AViewModel;

public class AView extends View {
    AViewModel vm;
    @Override
    protected String getIcon() {
        return Icons.Home;
    }
    @Override
    protected String getHeader() {
        return "A View";
    }
    @Override
    protected String getTip() { return "A View";}
    @Override
    protected Node getContent() {
        vm = new AViewModel();;
        var box = new VBox();
        box.setAlignment(Pos.CENTER);
        box.setSpacing(5);
        var label = new Label("Content of A View");
        label.setFont(Font.font(24));
        var button = new ActionButton(Icons.Add, 24, "Execute");
        button.setAction(vm::setText);
        var boundLabel = new Label("Test");
        var boundTextBox1 = new TextField();
        var boundTextBox2 = new TextField();
        // Binding Mode OneWay
        boundLabel.textProperty().bind(vm.labelTextProperty);
        // Binding Mode OneWayToSource
        vm.box1TextProperty.bind(boundTextBox1.textProperty());
        // Binding Mode TwoWay
        //vm.box2TextProperty.bindBidirectional(boundTextBox2.textProperty());
        boundTextBox2.textProperty().bindBidirectional(vm.box2TextProperty);
        box.getChildren().addAll(label, button, boundLabel, boundTextBox1, boundTextBox2);
        return box;
    }
}

import Views.*;
import controls.MainPanel;
import javafx.application.Application;
import javafx.stage.Stage;

public class App extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        var window = new Window(stage);
        var panel = new MainPanel();
        panel.addView(new AView());
        panel.addView(new BView());
        panel.addView(new CView());
        panel.setTitle("JavaFX");
        window.setContent(panel);
        window.show();
    }
    static void main(String[] a) { launch(a); }
}

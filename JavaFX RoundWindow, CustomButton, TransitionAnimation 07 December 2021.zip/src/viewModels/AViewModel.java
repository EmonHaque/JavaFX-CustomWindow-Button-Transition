package viewModels;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class AViewModel {
    public StringProperty labelTextProperty; // bound OneWay
    public StringProperty box1TextProperty; // bound OneWayToSource
    public StringProperty box2TextProperty; // bound TwoWay
    int count;
    public AViewModel(){
        labelTextProperty = new SimpleStringProperty();
        box1TextProperty = new SimpleStringProperty();
        box2TextProperty = new SimpleStringProperty();
    }
    public void setText(){
        var text = "Clicked " + ++count;
        labelTextProperty.set(text);
        System.out.println("Box 1: " + box1TextProperty.get());
        System.out.println("Box 2: " + box2TextProperty.get());
        box2TextProperty.set("");
    }
}

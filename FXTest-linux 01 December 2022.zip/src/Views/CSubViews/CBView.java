package Views.CSubViews;

import abstracts.DialogBase;
import abstracts.View;
import controls.buttons.ActionButton;
import controls.states.BiState;
import controls.texts.TextBox;
import dialogs.ConfirmDialog;
import dialogs.ErrorDialog;
import dialogs.InfoDialog;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.util.StringConverter;
import skinned.ExtendedTextArea;
import viewModels.CViewModels.CBViewModel;

public class CBView extends View {
    private Label status;
    private TextBox nameText, ageText;
    private BiState isMaleCheck;
    private ActionButton editButton, throwButton;
    CBViewModel vm;

    @Override
    protected String getHeader() {
        return "CB View";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight CBView");

        initialize();
        bind();
    }

    void initialize() {
        nameText = new TextBox("Name", Icons.ACircle);
        ageText = new TextBox("Age", Icons.ASquare);
        isMaleCheck = new BiState(true, "is male");
        editButton = new ActionButton(Icons.Edit, 16, "save");
        status = new Label();
        status.setTextFill(Color.WHITE);

        var bottomBox = new HBox(isMaleCheck, editButton);
        HBox.setHgrow(isMaleCheck, Priority.ALWAYS);

        var box = new VBox(nameText, ageText, bottomBox, status);
        var area = new ExtendedTextArea("toolTip", Icons.ACircle);
        throwButton = new ActionButton(Icons.DCircle, 16, "throw");

        box.getChildren().add(area);
        box.getChildren().add(throwButton);
        box.setSpacing(10);
        box.setPadding(new Insets(5,0,0,0));
        setCenter(box);
    }

    void bind() {
        vm = new CBViewModel();
        nameText.textProperty.bindBidirectional(vm.edited.name);
        //Bindings.bindBidirectional(ageText.textProperty, vm.edited.age, new NumberStringConverter());
        Bindings.bindBidirectional(ageText.textProperty, vm.edited.age, new StringConverter<Number>() {
            @Override
            public Number fromString(String s) {
                if (s == null) {
                    return 0;
                } else {
                    try {
                        return Integer.parseInt(s);
                    } catch (NumberFormatException ex) {
                        return 0;
                    }
                }
            }

            @Override
            public String toString(Number s) {
                return s == null || s.intValue() == 0 ? "" : s.toString();
            }
        });
        isMaleCheck.isCheckedProperty().bindBidirectional(vm.edited.isMale);
        editButton.setAction(vm::update);
        throwButton.setAction(vm::throwException);
        editButton.disableProperty().bind(nameText.textProperty.isEmpty().or(ageText.textProperty.isEmpty()));
        status.textProperty().bind(Bindings.select(vm, "status")); // looks like it's one time?

        vm.dialogTrigger.addListener(this::onTriggered);
    }

    void onTriggered(ObservableValue<?> o, boolean ov, boolean nv) {
        if (nv) {
            var bound = localToScreen(getBoundsInLocal());
            DialogBase dialog = null;
            boolean isConfirm = false;
            if (vm.dialogHeader.equals("Error")) {
                dialog = new ErrorDialog(vm.dialogHeader, vm.dialogMessage);
            }
            else if (vm.dialogHeader.equals("Confirm")) {
                dialog = new ConfirmDialog(vm.dialogHeader, vm.dialogMessage);
                isConfirm = true;
            }
            else {
                dialog = new InfoDialog(vm.dialogHeader, vm.dialogMessage);
            }
            dialog.setX(bound.getMinX());
            dialog.setY(bound.getMinY());
            dialog.showDialog(bound.getWidth(), bound.getHeight());
            vm.dialogTrigger.set(false);
            if (isConfirm) {
                vm.isConfirmed = ((ConfirmDialog) dialog).dialogResult;
            }
        }
    }

}

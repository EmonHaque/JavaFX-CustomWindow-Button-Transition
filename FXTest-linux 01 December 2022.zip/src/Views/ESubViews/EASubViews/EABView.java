package Views.ESubViews.EASubViews;

import abstracts.View;
import helpers.Icons;
import viewModels.EViewModels.EAAViewModels.EABViewVM;

public class EABView extends View {
    EABViewVM vm;

    @Override
    protected String getHeader() {
        return "EAB View";
    }

    @Override
    protected String getIcon() {
        return Icons.BCircle;
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight EAB View");

        vm = new EABViewVM();
    }
}

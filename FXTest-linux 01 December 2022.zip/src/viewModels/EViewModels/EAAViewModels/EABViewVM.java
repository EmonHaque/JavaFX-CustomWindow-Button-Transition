package viewModels.EViewModels.EAAViewModels;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class EABViewVM {
    public ObservableList<String> suggestions;

    public EABViewVM() {
        suggestions = FXCollections.observableArrayList(
            "Hello",
            "What",
            "How",
            "When",
            "Who"
        );
    }
}

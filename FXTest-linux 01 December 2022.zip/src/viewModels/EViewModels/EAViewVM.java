package viewModels.EViewModels;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Tenant;

public class EAViewVM {
    public static ObservableList<Tenant> tenants;

    public EAViewVM() {
        tenants = FXCollections.observableArrayList();
        
        tenants.add(new Tenant("House 1", "Tenant 1", "Space 1", 1000, 2000));
        tenants.add(new Tenant("House 1", "Tenant 1", "Space 2", 1000, 2000));
        tenants.add(new Tenant("House 2", "Tenant 2", "Space 1", 1000, 2000));
        tenants.add(new Tenant("House 2", "Tenant 2", "Space 2", 1000, 2000));
        tenants.add(new Tenant("House 3", "Tenant 3", "Space 1", 1000, 2000));
        tenants.add(new Tenant("House 3", "Tenant 3", "Space 2", 1000, 2000));
    }
}

package viewModels.EViewModels.EBAViewModels;

import helpers.Icons;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.util.Pair;
import model.Tenant;

public class EBAViewVM {
    public IntegerProperty primaryStateProperty, secondaryStateProperty;
    public ObjectProperty<Pair<String[], String[]>> secondaryStatesProperty;
    public static ObjectProperty<Tenant> selectedProperty;

    public EBAViewVM() {

        selectedProperty = new SimpleObjectProperty<>();
        primaryStateProperty = new SimpleIntegerProperty();
        secondaryStateProperty = new SimpleIntegerProperty();
        secondaryStatesProperty = new SimpleObjectProperty<>();

        primaryStateProperty.addListener(this::onPrimaryStateChanged);
        onPrimaryStateChanged(null, null, 0);
        secondaryStateProperty.addListener(this::onSecondaryStateChanged);
    }

    private void onPrimaryStateChanged(ObservableValue<?> o, Number ov, Number nv) {
        String[] icons = null;
        String[] texts = null;
        switch (nv.intValue()) {
            case 1:
                icons = new String[] { Icons.Building, Icons.Home };
                texts = new String[] { "House", "Space" };
                break;
            case 2:
                icons = new String[] { Icons.Building, Icons.User };
                texts = new String[] { "House", "Tenant" };
                break;
            default:
                icons = new String[] { Icons.User, Icons.Home };
                texts = new String[] { "Tenant", "Space" };
                break;
        }
        secondaryStatesProperty.set(new Pair<>(icons, texts));
        System.out.println("Primary state: " + nv.intValue());
    }

    private void onSecondaryStateChanged(ObservableValue<?> o, Number ov, Number nv){
        System.out.println("Secondary State: " + nv.intValue());
    }

    public void sortParticulars(){

    }

    public void sortRent(){

    }

    public void sortDue(){

    }
}

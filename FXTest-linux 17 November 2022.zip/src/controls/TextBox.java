package controls;

import helpers.Constants;
import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.TranslateTransition;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.SVGPath;
import javafx.util.Duration;
import skinned.ExtendedTextField;

public class TextBox extends GridPane {
    SVGPath svgIcon;
    // SVGPath ok, notOk;
    // Text error;
    // boolean isRequired
    Label hintLabel;
    ExtendedTextField input;
    TranslateTransition moveHint;
    boolean isHintMoved;
    public StringProperty textProperty;

    public TextBox(String hint, String icon) {
        hintLabel = new Label(hint);
        hintLabel.setTextFill(Color.GRAY);
        svgIcon = new SVGPath();
        svgIcon.setContent(icon);
        svgIcon.setFill(Color.LIGHTBLUE);
        svgIcon.setScaleX(12 / svgIcon.prefWidth(-1));
        svgIcon.setScaleY(12 / svgIcon.prefHeight(-1));

        input = new ExtendedTextField();

        addRow(0, svgIcon, input);
        add(hintLabel, 1, 0);
        setAlignment(Pos.BOTTOM_LEFT);
        setHgrow(input, Priority.ALWAYS);
        setMargin(hintLabel, new Insets(0, 0, 0, 5));
        setBorder(Constants.BottomLine);

        moveHint = new TranslateTransition(Duration.millis(100));
        moveHint.setInterpolator(Interpolator.EASE_IN);
        moveHint.setNode(hintLabel);
        setMinHeight(40);
        textProperty = input.textProperty();
        input.addEventHandler(MouseEvent.ANY, this::onMouseEvents);
        input.focusedProperty().addListener(this::onFocusChanged);
        input.textProperty().addListener(this::onTextChanged);
        // hintLabel.addEventFilter(MouseEvent.ANY, this::onMouseEvents);

    }

    void onMouseEvents(MouseEvent e) {
        if (e.getEventType() == MouseEvent.MOUSE_RELEASED)
            input.requestFocus();
        else if (e.getEventType() == MouseEvent.MOUSE_EXITED) {
            if (!input.isFocused()) {
                svgIcon.requestFocus();
            }
        }
    }

    void onTextChanged(ObservableValue<? extends String> observable, String oldValue, String newValue) {
        if (newValue == null || newValue.isEmpty()) {
            if (isHintMoved && !input.isFocused()) {
                moveHintDown();
            }
        }
        else {
            if (!isHintMoved){
                moveHintUp();
            }
               
        }
    }

    void onFocusChanged(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
        if (moveHint.getStatus() == Animation.Status.RUNNING)
            moveHint.stop();
        if (!newValue && textIsNullOrEmpty()) {
            resetFocusColor();
            if (isHintMoved)
                moveHintDown();
        }
        else if (!newValue && !textIsNullOrEmpty()) {
            resetFocusColor();
        }
        else if (newValue) {
            setFocusColor();
            if (!isHintMoved)
                moveHintUp();
        }
    }

    boolean textIsNullOrEmpty() {
        return input.getText() == null || input.getText().isEmpty();
    }

    void moveHintUp() {
        if(moveHint.getStatus() == Animation.Status.RUNNING){
            hintLabel.setTranslateX(0);
            hintLabel.setTranslateY(0);
            moveHint.stop();
        }
        moveHint.setByY(-15);
        moveHint.setByX(-5);
        moveHint.play();
        isHintMoved = true;
    }

    void moveHintDown() {
        if(moveHint.getStatus() == Animation.Status.RUNNING){
            hintLabel.setTranslateX(0);
            hintLabel.setTranslateY(0);
            moveHint.stop();
        }
        moveHint.setByY(15);
        moveHint.setByX(5);
        moveHint.play();
        isHintMoved = false;
    }

    void setFocusColor() {
        svgIcon.setFill(Color.CORNFLOWERBLUE);
        // line.setBorder(new Border(new BorderStroke(Color.CORNFLOWERBLUE,
        // Color.TRANSPARENT, Color.TRANSPARENT,Color.TRANSPARENT,
        // BorderStrokeStyle.SOLID,
        // BorderStrokeStyle.NONE,BorderStrokeStyle.NONE,BorderStrokeStyle.NONE, null,
        // null, null)));
    }

    void resetFocusColor() {
        svgIcon.setFill(Color.LIGHTBLUE);
        // line.setBorder(new Border(new BorderStroke(Color.LIGHTBLUE,
        // Color.TRANSPARENT, Color.TRANSPARENT,Color.TRANSPARENT,
        // BorderStrokeStyle.SOLID,
        // BorderStrokeStyle.NONE,BorderStrokeStyle.NONE,BorderStrokeStyle.NONE, null,
        // null, null)));
    }

    public String getText() {
        return input.getText();
    }

    public void setText(String value) {
        input.setText(value);
    }
}

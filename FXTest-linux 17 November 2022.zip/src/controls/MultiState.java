package controls;

import javafx.animation.Animation;
import javafx.animation.FillTransition;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class MultiState extends GridPane {
    private String[] icons;
    private String[] texts;
    private SVGIcon icon;
    private Text text;
    private int index;
    private FillTransition anim;
    private IntegerProperty state;

    public MultiState(String[] icons, String[] texts, boolean isIconFirst) {
        this.icons = icons;
        this.texts = texts;
        index = 0;
        icon = new SVGIcon(icons[index]);
        text = new Text(texts[index]);
        text.setFill(Color.WHITE);
        state = new SimpleIntegerProperty(index);
        if(isIconFirst){
            addColumn(0, icon);
            addColumn(1, text);
        }
        else{
            addColumn(0, text);
            addColumn(1, icon);
        }
        anim = new FillTransition(Duration.millis(300));
        anim.setShape(icon);
        // bound property cannot be modified!
        setOnMouseEntered(e -> animate(Color.CORAL));
        setOnMouseExited(e -> animate(Color.WHITE));
        setOnMouseClicked(this::onClicked);
    }

    private void animate(Color color){
        if(anim.getStatus() == Animation.Status.RUNNING) anim.stop();
        anim.setToValue(color);
        anim.play();
    }

    private void onClicked(MouseEvent e) {
        index = index < icons.length - 1 ? ++index : 0;
        icon.setContent(icons[index]);
        text.setText(texts[index]);
        state.set(index);
    }

    public IntegerProperty statePrperty(){
        return state;
    }
}

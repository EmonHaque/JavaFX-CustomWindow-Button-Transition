package interfaces;

import controls.Slice;

public interface ISliceExecute {
    void execute(Slice s);
}

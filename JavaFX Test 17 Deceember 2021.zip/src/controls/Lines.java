package controls;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.scene.transform.Scale;
import model.PinSeries;
import java.util.List;

public class Lines extends Region {
    List<PinSeries> series;
    double size = 240;
    double gap = 15;
    double y1LabelHeight, y1LabelWidth, y2LabelHeight, y2LabelWidth, xLabelWidth, xLabelHeight, y1Min, y1Max, y2Min, y2Max;
    Label leftTitle, rightTitle;
    Path line;
    String y1Title, y2Title;

    public Lines(List<PinSeries> series, String y1Title, String y2Title) {
        this.series = series;
        this.y1Title = y1Title;
        this.y2Title = y2Title;
        line = new Path();

        //line.setStrokeWidth(2);
        line.setStroke(Color.RED);
        setBackground(new Background(new BackgroundFill(Color.LIGHTCYAN, null,null)));
        setMinSize(size,size);
        y1Min = y2Min = 0;
        for (int i = 0; i < series.size(); i++) {
            var y1Total = series.get(i).getPinValues().stream().mapToDouble(x -> x).sum();
            if (y1Max < y1Total) y1Max = y1Total;
            var y2value = series.get(i).getLineValue();
            if(y2Max < y2value) y2Max = y2value;

            if(i == 0) line.getElements().add(new MoveTo());
            else line.getElements().add(new LineTo());

            var xLabel = new Text(series.get(i).getName());
            xLabel.setUserData("x");
            xLabel.setRotate(-90);
            getChildren().add(xLabel);
            xLabelHeight = xLabel.prefHeight(-1);
            xLabelWidth = xLabel.prefWidth(-1);
        }
        double y1Step = y1Max / 5;
        double y2Step = y2Max / 5;
        double y1Current = y1Min;
        double y2Current = y2Min;
        for (int i = 0; i < 6; i++) {
            var line = new Line();
            line.setStroke(Color.GRAY);

            line.getStrokeDashArray().addAll(5d, 2d);
            getChildren().add(line);

            var y1Label = new Text(String.format("%.1f", y1Current));
            y1Label.setUserData("y1");
            y1Current += y1Step;
            getChildren().add(y1Label);
            y1LabelWidth = y1Label.prefWidth(-1);
            y1LabelHeight = y1Label.prefHeight(-1);

            var y2Label = new Text(String.format("%.1f", y2Current));
            y2Label.setUserData("y2");
            y2Current += y2Step;
            getChildren().add(y2Label);
            y2LabelWidth = y2Label.prefWidth(-1);
            y2LabelHeight = y2Label.prefHeight(-1);
        }
        line.getTransforms().add(new Scale(1,-1));
        getChildren().add(line);
        for (var s : series) {
            var pin = new Pin(s);
            pin.getTransforms().add(new Scale(1,-1));
            getChildren().add(pin);
        }
        leftTitle = new Label(y1Title);
        leftTitle.setUserData("left");
        leftTitle.setFont(Font.font(null, FontWeight.BOLD, 14));
        leftTitle.setPadding(new Insets(0,0,5,0));
        leftTitle.setRotate(-90);
        leftTitle.setAlignment(Pos.CENTER);
        getChildren().add(leftTitle);

        rightTitle = new Label(y2Title);
        rightTitle.setUserData("right");
        rightTitle.setFont(Font.font(null, FontWeight.BOLD,14));
        rightTitle.setPadding(new Insets(0,0,5,0));
        rightTitle.setRotate(90);
        rightTitle.setAlignment(Pos.CENTER);
        getChildren().add(rightTitle);
    }

    protected void layoutChildren() {
        var height = getHeight();
        var width = getWidth();
        var leftTitleWidth = leftTitle.prefHeight(-1);
        var rightTitleWidth = rightTitle.prefHeight(-1);
        var availableHeight = height - xLabelWidth;
        var colWidth = (width - leftTitleWidth - rightTitleWidth - y1LabelWidth - y2LabelWidth - series.size() * gap) / series.size();
        var vSpace = availableHeight / 6;
        double lineY = availableHeight;
        double y1LabelY = lineY - 5;
        double y2LabelY = lineY - 5;
        double pinX = leftTitleWidth + y1LabelWidth + gap;
        double lineX = pinX;
        double xLabelX = leftTitleWidth + y1LabelWidth + gap - xLabelWidth / 2;

        var children = getChildren();
        for (var child : children) {
            if(child instanceof Line line){
                line.setStartX(leftTitleWidth);
                line.setEndX(width - rightTitleWidth);
                line.setStartY(lineY);
                line.setEndY(lineY);
                lineY -= vSpace;
            }
            else if(child instanceof Text text){
                if(text.getUserData().equals("y1")){
                    text.setX(leftTitleWidth);
                    text.setY(y1LabelY);
                    y1LabelY -= vSpace;
                }
                else if(text.getUserData().equals("y2")){
                    text.setX(width - rightTitleWidth - text.prefWidth(-1));
                    text.setY(y2LabelY);
                    y2LabelY -= vSpace;
                }
                else if(text.getUserData().equals("x")){
                    text.setY(height - xLabelHeight / 2);
                    text.setX(xLabelX + colWidth / 2);
                    xLabelX += colWidth + gap;
                }
            }
            else if(child instanceof Path path){
                path.setTranslateY(availableHeight);
                var elements = path.getElements();
                for (int i = 0; i < elements.size(); i++) {
                    var y = series.get(i).getLineValue() * (availableHeight - vSpace) / y2Max;
                    if(i == 0){
                        var move = (MoveTo)elements.get(i);
                        move.setX(lineX + colWidth / 2);
                        move.setY(y);
                    }else{
                        var line = (LineTo)elements.get(i);
                        line.setX(lineX + colWidth / 2);
                        line.setY(y);
                    }
                    lineX += colWidth + gap;
                }
            }
            else if(child instanceof Pin pin){
                var h = pin.getTotal() * (availableHeight - vSpace) / y1Max;
                pin.makePin(colWidth, h);
                pin.setTranslateX(pinX);
                pin.setTranslateY(availableHeight);
                pinX += colWidth + gap;
            }
            else if(child instanceof Label label){
                if(label.getUserData().equals("left")){
                    leftTitle.setTranslateX(-leftTitle.prefWidth(-1) / 2 + leftTitleWidth / 2);
                    leftTitle.setTranslateY(availableHeight / 2 - leftTitleWidth / 2);
                }
                else if(label.getUserData().equals("right")){
                    rightTitle.setTranslateX(width - rightTitle.prefWidth(-1) / 2 - leftTitleWidth / 2);
                    rightTitle.setTranslateY(availableHeight / 2 - rightTitleWidth / 2);
                }
                super.layoutChildren();
            }
        }
    }
}

package controls;
import abstracts.View;
import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.TranslateTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.effect.BlurType;
import javafx.scene.effect.DropShadow;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.util.Duration;

public class MainPanel extends BorderPane {
    double radius = 5.0;
    StackPane stack;
    VBox navBar, sideBar;
    int currentIndex;
    TranslateTransition getIn, getOut;

    public MainPanel(){
        stack = new StackPane();
        navBar = new VBox();
        sideBar = new VBox(navBar);
        sideBar.setAlignment(Pos.BOTTOM_CENTER);
        var effect = new DropShadow();
        effect.setOffsetX(3);
        effect.setOffsetY(3);
        effect.setRadius(5);
        effect.setColor(Color.DARKGRAY);
        effect.setBlurType(BlurType.GAUSSIAN);
        sideBar.setEffect(effect);
        sideBar.setPadding(new Insets(0,0,10,0));
        sideBar.setBackground(new Background(new BackgroundFill(Color.SLATEGRAY, new CornerRadii(0,0,0,radius,false), null)));
        setMargin(stack, new Insets(5));
        setCenter(stack);
        setLeft(sideBar);
        currentIndex = 0;
        getIn = new TranslateTransition(Duration.seconds(1));
        getOut = new TranslateTransition(Duration.seconds(1));
        getIn.setInterpolator(Interpolator.EASE_BOTH);
        getOut.setInterpolator(Interpolator.EASE_BOTH);
    }
    public void addView(View view){
        var button = new ActionButton(view.icon, 24, view.toolTip);
        button.setAction(null);
        button.setOnMouseClicked(this::setView);
        navBar.getChildren().add(button);
        stack.getChildren().add(view.visual);
        if(stack.getChildren().size() == 1){
            button.setActive(true);
        }
        else view.visual.setVisible(false);
    }
    public void setTitle(String title){
        var text = new Label(title);
        text.setFont(Font.font(Font.getDefault().getFamily(), FontWeight.BOLD,16));
        text.setTextFill(Color.LIGHTGRAY);
        text.setRotate(-90);
        var group = new Group(text);
        group.setTranslateX(-text.getHeight() / 2);
        sideBar.getChildren().add(0, group);
        VBox.setMargin(sideBar.getChildren().get(0), new Insets(0,0,10,0));
    }
    void setView(MouseEvent e){
        if(getIn.getStatus() == Animation.Status.RUNNING) return;
        var index = navBar.getChildren().indexOf(e.getSource());
        if(index == currentIndex) return;
        var in = stack.getChildren().get(index);
        var out = stack.getChildren().get(currentIndex);
        double width = getWidth();
        if(index > currentIndex){
            in.translateXProperty().set(width);
            getIn.setByX(-width);
            getOut.setByX(-width);
        }else{
            in.translateXProperty().set(-width);
            getIn.setByX(width);
            getOut.setByX(width);
        }
        in.setVisible(true);
        getIn.setNode(in);
        getOut.setNode(out);
        getIn.play();
        getOut.play();

        var deactivate = (ActionButton) navBar.getChildren().get(currentIndex);
        var activate = (ActionButton) navBar.getChildren().get(index);
        getIn.setOnFinished(event -> {
            deactivate.setActive(false);
            activate.setActive(true);
            out.setVisible(false);
            currentIndex = index;
        });
    }
}

package controls;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.paint.Color;
import javafx.scene.text.*;

public class HiText extends TextFlow {
    public StringProperty query;
    String content;
    public HiText(){
        // doesn't align Text vertically center
        setTextAlignment(TextAlignment.CENTER);
        query = new SimpleStringProperty();
        query.addListener(this::changed);
    }
    public HiText(String content) {
        this();
        this.content = content;
        getChildren().add(new Text(content));
    }
    public void setContent(String content){
        getChildren().clear();
        this.content = content;
        getChildren().add(new Text(content));
    }
    void changed(ObservableValue<? extends String> observable, String oldValue, String newValue){
        getChildren().clear();
        if (newValue.isEmpty()) {
            getChildren().add(new Text(content));
        } else {
            int index = 0;
            var filter = query.get();
            int filterLength = filter.length();
            var text = content.toLowerCase();
            for (int i = text.indexOf(filter); i > -1; i = text.indexOf(filter, i + 1)) {
                getChildren().add(new Text(content.substring(index, i)));
                var match = new Text(content.substring(i, i + filterLength));
                match.setFill(Color.BLUE);
                match.setFont(Font.font(null, FontWeight.BOLD, 12));
                match.setUnderline(true);
                getChildren().add(match);
                index = i + filterLength;
            }
            if (index < text.length()) getChildren().add(new Text(content.substring(index)));
        }
    }
}

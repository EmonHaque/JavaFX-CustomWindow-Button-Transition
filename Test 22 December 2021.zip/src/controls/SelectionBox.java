package controls;
import helpers.Icons;
import interfaces.ISetContent;
import javafx.animation.RotateTransition;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.SVGPath;
import javafx.stage.Popup;
import javafx.util.Duration;

public class SelectionBox<T> extends GridPane {
    Popup popup;
    HBox selectedBox;

    TextField input;
    ListView<T> listView;
    ISetContent<T> visual;
    Label hintLabel;
    Separator line;
    ActionButton close, open;
    SVGPath svgIcon;
    RotateTransition rotationAnim;
    boolean isOpen = false;
    public StringProperty query;
    public ObjectProperty<T> selectedItem;

    public SelectionBox(String hint, String icon, FilteredList<T> list, ISetContent<T> visual) {
        this.visual = visual;
        listView = new ListView<T>(list);
        listView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        listView.setMaxHeight(200);
        popup = new Popup();
        popup.getContent().add(listView);
        popup.setAutoHide(true);

        open = new ActionButton(Icons.DownArrow, 24, "show");
        close = new ActionButton(Icons.CloseCircle, 18, "remove");

        selectedBox = new HBox();
        HBox.setHgrow(visual.getVisual(), Priority.ALWAYS);
        selectedBox.getChildren().addAll(visual.getVisual(), close);
        selectedBox.setAlignment(Pos.CENTER);
        selectedBox.setPadding(new Insets(0,0,0,5));
        selectedBox.setVisible(false);
        selectedBox.setBackground(new Background(new BackgroundFill(Color.SNOW, new CornerRadii(5), null)));
        setMargin(selectedBox, new Insets(0,5,0,5));

        input = new TextField();
        input.setBackground(null);
        hintLabel = new Label(hint);
        line = new Separator();
        line.setBorder(new Border(new BorderStroke(Color.LIGHTBLUE, Color.TRANSPARENT, Color.TRANSPARENT,Color.TRANSPARENT, BorderStrokeStyle.SOLID, BorderStrokeStyle.NONE,BorderStrokeStyle.NONE,BorderStrokeStyle.NONE, null, null, null)));

        svgIcon = new SVGPath();
        svgIcon.setContent(icon);
        addRow(0, svgIcon, input, open);
        add(selectedBox,1,0);
        addRow(1,line);
        setColumnSpan(line, 3);
        setHgrow(input, Priority.ALWAYS);
        query = input.textProperty();
        selectedItem = new SimpleObjectProperty<T>();
        //selectedItem.bind(listView.getSelectionModel().selectedItemProperty());
        input.textProperty().addListener(this::onTextChanged);

        open.setAction(this::showPopup);
        rotationAnim = new RotateTransition(Duration.millis(500));
        rotationAnim.setNode(open);

        popup.setOnShowing(e -> {
            rotationAnim.setToAngle(180);
            rotationAnim.play();
            open.setTip("close");
            isOpen = true;
        });
        popup.setOnHiding(e -> {
            rotationAnim.setToAngle(0);
            rotationAnim.play();
            open.setTip("show");
            isOpen = false;
        });

        listView.setOnKeyReleased(e -> {
            if(e.getCode() == KeyCode.ENTER){
                var selected = listView.getSelectionModel().getSelectedItem();
                if(selected != null){
                    visual.setContent(selected);
                    input.setText("");
                    input.setVisible(false);
                    selectedBox.setVisible(true);
                }
                popup.hide();
                selectedItem.set(selected);
            }
        });
        if(list.size() > 0){
            listView.getSelectionModel().selectFirst();
            var selected = listView.getSelectionModel().getSelectedItem();
            if(selected != null){
                visual.setContent(selected);
                input.setText("");
                input.setVisible(false);
                selectedBox.setVisible(true);
                selectedItem.set(selected);
            }
        }
        close.setAction(this::removeSelected);
        selectedBox.setOnMouseClicked(e ->{
            if(isOpen) popup.hide();
            else showPopup();

        });
        listView.setOnMouseClicked(e ->{
            var selected = listView.getSelectionModel().getSelectedItem();
            if(selected != null){
                visual.setContent(selected);
                input.setText("");
                input.setVisible(false);
                selectedBox.setVisible(true);
                selectedItem.set(selected);
            }
            popup.hide();
        });
    }
    void removeSelected(){
        selectedBox.setVisible(false);
        input.setVisible(true);
        input.requestFocus();
        showPopup();
        selectedItem.set(null);
    }
    public ListView getView(){
        return listView;
    }
    void onTextChanged(ObservableValue<? extends String> observable, String oldValue, String newValue){
        if(!isOpen){
            showPopup();
        }
    }

    void showPopup() {
        var point = input.localToScreen(0.0, 0.0);
        listView.setMinWidth(input.getWidth());
        popup.show(getScene().getWindow(), point.getX(), point.getY() + getHeight());
    }
}

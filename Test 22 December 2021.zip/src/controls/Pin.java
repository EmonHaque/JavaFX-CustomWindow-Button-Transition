package controls;

import javafx.event.Event;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.control.Separator;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import model.PinSeries;
import java.util.List;

public class Pin extends Group {
    double total, width, height, radius;
    PinSeries series;
    List<Double> values;
    Circle circle;
    Popup pop;
    VBox content;

    public Pin(PinSeries series) {
        this.series = series;
        radius = 3;
        values = series.getPinValues();
        total = values.stream().mapToDouble(s -> s).sum();
        content = new VBox(new Text(series.getName()), new Separator());
        for (int i = 0; i < values.size(); i++) {
            var line = new Line();
            line.setEndY(height / total * values.get(i));
            if(i > 0) line.setStroke(Color.GREEN);
            else line.setStroke(Color.CORNFLOWERBLUE);
            getChildren().add(line);
            content.getChildren().add(new Text("Pin " + (i+1) + " Value is " + values.get(i)));
        }
        content.getChildren().add(new Text("Line Value is " + series.getLineValue()));
        circle = new Circle();
        circle.setFill(Color.CORAL);
        circle.setRadius(radius);
        getChildren().add(circle);

        content.setPadding(new Insets(10));
        content.setAlignment(Pos.CENTER);
        content.setBackground(new Background(new BackgroundFill(Color.CORAL, new CornerRadii(10), null)));
        //content.setEffect(new DropShadow());
        pop = new Popup();
        pop.getContent().add(content);

        addEventHandler(MouseEvent.ANY, this::onMouse);
    }
    void onMouse(MouseEvent e) {
        if(e.getEventType() == MouseEvent.MOUSE_ENTERED){
            var point = localToScreen(0.0, 0.0);
            var x = point.getX() - content.getWidth() / 2;
            var y = point.getY() - height - content.getHeight() - 10;
            pop.show(this, x, y);
        }
        else if(e.getEventType() == MouseEvent.MOUSE_EXITED){
            pop.hide();
        }
    }
    public void makePin(double width, double height){
        this.width = width;
        this.height = height - radius / 2;
        requestLayout();
    }
    public double getTotal() {
        return total;
    }
    @Override
    protected void layoutChildren() {
        var lines = getChildren().stream().filter(x -> x instanceof Line).map(x -> (Line)x).toList();
        double y = 0;
        for (int i = 0; i < values.size(); i++) {
            var line = lines.get(i);
            line.setStartY(y);
            line.setEndY(y + height / total * values.get(i));
            line.setStartX(width / 2);
            line.setEndX(width / 2);
            y += line.getEndY();
        }
        circle.setCenterY(height + radius / 2);
        circle.setCenterX(width / 2);
    }
}

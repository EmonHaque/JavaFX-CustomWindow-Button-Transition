package Views.FSubViews;

import abstracts.View;
import controls.ActionButton;
import controls.HorizontalListChart;
import controls.TextBox;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import viewModels.FViewModels.FBAViewVM;

public class FBAView extends View {
    FBAViewVM vm;

    @Override
    protected String getHeader() {
        return "FBA View";
    }
    @Override
    protected String getIcon() {
        return Icons.ACircle;
    }
    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight FBA View");

        vm = new FBAViewVM();

        var reload = new ActionButton(Icons.Reload, 16, "reload");
        reload.setAction(vm::generateSeries);
        addAction(reload);

        var chart = new HorizontalListChart();
        chart.seriesProperty.bind(vm.seriesProperty);
        
        var queryBox = new TextBox("Query", Icons.Magnify);
        vm.queryProperty.bind(queryBox.textProperty);

        var sort = new ActionButton(Icons.Sort, 16, "sort value3");
        sort.setAction(vm::sort);

        chart.queryProperty.bind(vm.queryProperty);
        
        var hBox = new HBox(queryBox, sort);
        hBox.setSpacing(10);
        hBox.setAlignment(Pos.BOTTOM_CENTER);
        HBox.setHgrow(queryBox, Priority.ALWAYS);
        var box = new VBox(hBox, chart);
        box.setSpacing(10);
        VBox.setVgrow(chart, Priority.ALWAYS);
        
        BorderPane.setMargin(box, new Insets(10,0,0,0));
        setCenter(box);
    }
}

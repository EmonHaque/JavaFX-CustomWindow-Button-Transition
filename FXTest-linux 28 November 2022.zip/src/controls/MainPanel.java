package controls;

import abstracts.View;
import abstracts.ViewContainer;
import helpers.Constants;
import helpers.Icons;
import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.util.Duration;

public class MainPanel extends BorderPane {
    double radius = 5.0;
    StackPane stack;
    GridPane sideBar;
    VBox navBar, actionBar, titleBar;
    int currentIndex;
    TranslateTransition getIn, getOut;
    Stage stage;
    ActionButton maxRestore;

    public MainPanel(Stage stage) {
        this.stage = stage;
        stack = new StackPane();
        navBar = new VBox();
        titleBar = new VBox();
        navBar.setAlignment(Pos.CENTER);

        sideBar = new GridPane();
        addActioneBar();
        sideBar.addRow(0, actionBar);
        sideBar.addRow(1, titleBar);
        sideBar.addRow(2, navBar);
        GridPane.setVgrow(titleBar, Priority.ALWAYS);
        GridPane.setMargin(navBar, new Insets(0, 0, Constants.CardMargin, 0));

        sideBar.setBackground(new Background(
                new BackgroundFill(Constants.BackgroundColor, new CornerRadii(radius, 0, 0, radius, false), null)));
        // setMargin(stack, new Insets(5));
        setCenter(stack);
        setLeft(sideBar);

        currentIndex = 0;
        getIn = new TranslateTransition(Duration.seconds(1));
        getOut = new TranslateTransition(Duration.seconds(1));
        getIn.setInterpolator(Interpolator.EASE_BOTH);
        getOut.setInterpolator(Interpolator.EASE_BOTH);

        var clip = new Rectangle();
        layoutBoundsProperty().addListener((observable, oldValue, newValue) -> {
            clip.setWidth(newValue.getWidth());
            clip.setHeight(newValue.getHeight());
        });
        setClip(clip);
    }

    private void minimize() {
        stage.setIconified(true);
    }

    private void maxRestore() {
        if (stage.isMaximized()) {
            stage.setMaximized(false);
            maxRestore.setIcon(Icons.Maximize);
            maxRestore.setTip("Maximize");
        }
        else {
            stage.setMaximized(true);
            maxRestore.setIcon(Icons.Restore);
            maxRestore.setTip("Restore");
        }
    }

    private void addActioneBar() {
        maxRestore = new ActionButton(Icons.Maximize, 14, "Maximize");
        var minimize = new ActionButton(Icons.Minimize, 14, "Minimize");
        var close = new ActionButton(Icons.Close, 12, "Close");

        actionBar = new VBox();
        VBox.setMargin(minimize, new Insets(5, 0, 0, 0));
        VBox.setMargin(maxRestore, new Insets(Constants.CardMargin, 0, Constants.CardMargin, 0));
        actionBar.setAlignment(Pos.CENTER);
        actionBar.getChildren().addAll(minimize, maxRestore, close);

        minimize.setAction(this::minimize);
        maxRestore.setAction(this::maxRestore);
        close.setAction(Platform::exit);
    }

    public void addView(View view) {
        var button = new ActionButton(view.icon, 16, view.toolTip);
        button.setOnMouseClicked(this::setView);
        navBar.getChildren().add(button);
        stack.getChildren().add(view);
        if (!view.isContainer()) {
            StackPane.setMargin(view, new Insets(Constants.CardMargin));
        }
        if (stack.getChildren().size() == 1) {
            button.setActive(true);
            if (view.initialViews() != null) {
                var views = view.initialViews();
                for (View subView : views) {
                    if (!subView.isSeen)
                        subView.onFirstSight();
                }
            }
            view.onFirstSight();

        }
        else {
            VBox.setMargin(button, new Insets(Constants.CardMargin, 0, 0, 0));
            view.setVisible(false);
        }
    }

    public void addView(ViewContainer view) {
        var button = new ActionButton(view.icon, 16, view.toolTip);
        button.setOnMouseClicked(this::setView);
        navBar.getChildren().add(button);
        stack.getChildren().add(view);

        if (stack.getChildren().size() == 1) {
            button.setActive(true);
        }
        else {
            VBox.setMargin(button, new Insets(Constants.CardMargin, 0, 0, 0));
            view.setVisible(false);
        }
    }

    public void setTitle(String title) {
        var text = new Label(title);
        text.setFont(Font.font(Font.getDefault().getFamily(), FontWeight.BOLD, 16));
        text.setTextFill(Color.LIGHTGRAY);
        text.setRotate(-90);
        var group = new Group(text);
        group.setTranslateX(-text.getHeight() / 2 + text.getWidth() / 2);
        titleBar.getChildren().add(0, group);
        titleBar.setAlignment(Pos.BOTTOM_CENTER);
        VBox.setMargin(titleBar.getChildren().get(0), new Insets(0, 3, 10, 0));
    }

    void setView(MouseEvent e) {
        if (getIn.getStatus() == Animation.Status.RUNNING)
            return;
        var index = navBar.getChildren().indexOf(e.getSource());
        if (index == currentIndex)
            return;
        var in = stack.getChildren().get(index);
        var out = stack.getChildren().get(currentIndex);
        double width = getWidth();
        if (index > currentIndex) {
            in.translateXProperty().set(width);
            getIn.setByX(-width);
            getOut.setByX(-width);
        }
        else {
            in.translateXProperty().set(-width);
            getIn.setByX(width);
            getOut.setByX(width);
        }
        in.setVisible(true);
        getIn.setNode(in);
        getOut.setNode(out);
        getIn.play();
        getOut.play();

        var deactivate = (ActionButton) navBar.getChildren().get(currentIndex);
        var activate = (ActionButton) navBar.getChildren().get(index);

        if (in instanceof View view) {
            if (view.initialViews() != null) {
                if (!view.isSeen) {
                    var views = view.initialViews();
                    for (View subView : views) {
                        if (!subView.isSeen)
                            subView.onFirstSight();
                    }
                }
            }
            if (!view.isSeen)
                view.onFirstSight();
        }
        else if (in instanceof ViewContainer viewContainer) {

            if (viewContainer.initialView().initialViews() != null) {
                if (!viewContainer.initialView().isSeen) {
                    var views = viewContainer.initialView().initialViews();
                    for (View subView : views) {
                        if (!subView.isSeen)
                            subView.onFirstSight();
                    }
                }
            }
            if (!viewContainer.initialView().isSeen)
                viewContainer.initialView().onFirstSight();
        }

        getIn.setOnFinished(event -> {
            deactivate.setActive(false);
            activate.setActive(true);
            out.setVisible(false);
            currentIndex = index;
            getIn.setOnFinished(null);
        });
    }
}

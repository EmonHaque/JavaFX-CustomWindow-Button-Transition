package controls;

import java.util.ArrayList;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.paint.Color;
import javafx.scene.text.*;

public class HiText extends TextFlow {
    public StringProperty query;
    String content;

    public HiText() {
        // doesn't align Text vertically center
        query = new SimpleStringProperty();
        query.addListener(this::changed);
    }

    public HiText(String content) {
        this();
        this.content = content;
        getChildren().add(new Text(content));
    }

    public void setContent(String content) {
        getChildren().clear();
        this.content = content;
        var text = new Text(content);
        text.setFill(Color.WHITE);
        getChildren().add(text);
    }
 
    void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
        if (newValue.isEmpty())
            return;
        if (content != null) {
            getChildren().clear();
            int index = 0;
            var filter = query.get().toLowerCase();
            int filterLength = filter.length();
            var text = content.toLowerCase();
            for (int i = text.indexOf(filter); i > -1; i = text.indexOf(filter, i + 1)) {
                var unmatchedContent = content.substring(index, i);
                if(unmatchedContent.length() > 0){
                    var unmatched = new Text(unmatchedContent);
                    unmatched.setFill(Color.WHITE);
                    getChildren().add(unmatched);
                }
                var match = new Text(content.substring(i, i + filterLength));
                match.setFill(Color.CORNFLOWERBLUE);
                match.setFont(Font.font(null, FontWeight.BOLD, 12));
                match.setUnderline(true);
                getChildren().add(match);
                index = i + filterLength;
            }
            if (index < text.length()) {
                var unmatched = new Text(content.substring(index));
                unmatched.setFill(Color.WHITE);
                getChildren().add(unmatched);
            }
        }
        else {
            var segments = new ArrayList<Text>();
            for (int i = 0; i < getChildren().size(); i++) {
                var segment = (Text) getChildren().get(i);
                segments.add(segment);
            }
            getChildren().clear();
            for (var segment : segments) {
                int index = 0;
                var filter = query.get().toLowerCase();
                int filterLength = filter.length();
                var text = segment.getText().toLowerCase();
                for (int i = text.indexOf(filter); i > -1; i = text.indexOf(filter, i + 1)) {
                    var unmatchedContent = segment.getText().substring(index, i);
                    if (unmatchedContent.length() > 0) {
                        var unmatched = new Text(unmatchedContent);
                        unmatched.setFill(Color.WHITE);
                        unmatched.setFont(segment.getFont());
                        getChildren().add(unmatched);
                    }

                    var match = new Text(segment.getText().substring(i, i + filterLength));
                    match.setFill(Color.CORNFLOWERBLUE);
                    match.setFont(Font.font(null, FontWeight.BOLD, 12));
                    match.setUnderline(true);
                    getChildren().add(match);
                    index = i + filterLength;
                }
                if (index < text.length()) {
                    var unmatched = new Text(segment.getText().substring(index));
                    unmatched.setFill(Color.WHITE);
                    unmatched.setFont(segment.getFont());
                    getChildren().add(unmatched);
                }
            }
        }
    }
}

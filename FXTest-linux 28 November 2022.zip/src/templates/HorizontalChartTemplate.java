package templates;

import javafx.beans.property.DoubleProperty;
import javafx.geometry.Insets;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.text.Text;
import model.HorizontalSeries;

public class HorizontalChartTemplate extends ListCell<HorizontalSeries> {
    private HorizontalChartCell test;
    private double percentOfChartArea, topBottomPadding;
    private DoubleProperty topMax, bottomMax;

    public HorizontalChartTemplate(double rightMargin, double percentOfChartArea, DoubleProperty topMax, DoubleProperty bottomMax) {
        this.percentOfChartArea = percentOfChartArea;
        this.topMax = topMax;
        this.bottomMax = bottomMax;
        topBottomPadding = 2.5;
        setText(null);
        setBackground(null);
        setPadding(new Insets(0, rightMargin, 0, 0));
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
    }

    @Override
    protected void updateItem(HorizontalSeries item, boolean empty) {
        super.updateItem(item, empty);
        if (item == null || empty) {
            setGraphic(null);
        }
        else {
            var previous = getIndex() > 0 ? getListView().getItems().get(getIndex() - 1) : null;
            test = new HorizontalChartCell(item, previous, percentOfChartArea, topBottomPadding, topMax.get(), bottomMax.get());
            setGraphic(test);
        }
    }

    @Override
    protected double computePrefHeight(double width) {
        var item = getItem();
        if (item == null)
            return super.computePrefHeight(width);

        var text = new Text();
        text.setText(item.getTitle());
        text.setWrappingWidth(width * (1 - percentOfChartArea));
        return text.prefHeight(-1) + topBottomPadding * 2;
    }
}

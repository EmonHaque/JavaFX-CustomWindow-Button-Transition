package Views;

import abstracts.View;
import controls.TextBox;
import helpers.Icons;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebView;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.IOException;

public class BView extends View {
    @Override
    protected String getIcon() {
        return Icons.Add;
    }

    @Override
    protected String getHeader() {
        return "B View";
    }

    @Override
    protected String getTip() {
        return "B View";
    }

    @Override
    protected Node getContent() {
        var box = new BorderPane();
        var textBox = new TextBox("Surah:Ayah", Icons.Add);
        var web = new WebView();
        box.setTop(textBox);
        box.setCenter(web);

        var engine = web.getEngine();
        textBox.setOnKeyPressed(e -> {
            if(e.getCode() != KeyCode.ENTER) return;
            var splits = textBox.textProperty.get().split(":");
            var surah = splits[0];
            var ayah = splits[1];
            var url = "https://corpus.quran.com/wordbyword.jsp?chapter=" + surah +"&verse=" + ayah;

            Document doc = null;
            try { doc = Jsoup.connect(url).get();}
            catch (IOException ex) { ex.printStackTrace();}
            var table = doc.select("table[class='morphologyTable']").first();
            var rows = table.select("tr");
            table.children().removeAll(rows);
            var header = rows.select("[class='head']").first();
            table.append(header.html());
            rows.remove(0);
            var pattern = surah + ":" ;
            for(var row : rows){
                var column = row.select("span[class='location']").text().substring(1);
                if(column.startsWith(pattern)){
                    var image = row.select("td[class='ic']>a>img").first();
                    var id = image.attr("src");
                    image.attr("src", "https://corpus.quran.com/" + id);
                    table.append(row.html());
                }
            }
            engine.loadContent(table.outerHtml());
        });

        return box;
    }
}

package Views.ESubViews;

import abstracts.View;
import helpers.Icons;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

public class ECView extends View {

    @Override
    protected String getIcon() {
        return Icons.CSqure;
    }

    @Override
    protected String getHeader() {
        return "EC View";
    }

    @Override
    protected String getTip() {
        return "EC View";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight EC View");
        var label = new Label("Test EC");
        label.setTextFill(Color.WHITE);
        var box = new VBox(label);
        setCenter(box);
    }
    
}

package Views.ASubViews;

import java.util.List;

import abstracts.View;
import controls.Lines;
import model.PinSeries;

public class LineView extends View {
    @Override
    protected String getHeader() {
        return "Line View";
    }
    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight LineView");
        List<PinSeries> pinSeries = List.of(
                new PinSeries("A Title", List.of(100d, 200d), 100),
                new PinSeries("B Title", List.of(50d, 100d), 280),
                new PinSeries("C Title", List.of(200d, 30d), 200),
                new PinSeries("D Title", List.of(300d, 0d), 150),
                new PinSeries("E Title", List.of(70d, 30d), 50));

        var pinLine = new Lines(pinSeries, "Pin Value", "Line Value");
        setCenter(pinLine);
    }
}

package Views.ASubViews;

import abstracts.View;

public class PinColumnView extends View {
    @Override
    protected String getHeader() {
        return "PinColumn View";
    }
    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight PinColumnView");
    }
}

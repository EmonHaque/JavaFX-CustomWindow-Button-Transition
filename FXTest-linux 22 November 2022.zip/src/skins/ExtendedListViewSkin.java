package skins;

import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.skin.ListViewSkin;
import javafx.scene.control.skin.VirtualFlow;
import skinned.ExtendedVirtualFlow;

public class ExtendedListViewSkin<T> extends ListViewSkin<T> {

    public ExtendedListViewSkin(ListView<T> control) {
        super(control);
    }

    @Override
    protected VirtualFlow<ListCell<T>> createVirtualFlow() {
        return new ExtendedVirtualFlow<>();
    }
}

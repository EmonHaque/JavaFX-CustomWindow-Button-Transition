package controls;

import java.util.HashMap;

import helpers.Constants;
import javafx.event.EventHandler;
import javafx.scene.Cursor;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Window extends BorderPane {
    
    Stage stage;
    HBox titleBar;
    Scene scene;
    private final HashMap<Cursor, EventHandler<MouseEvent>> LISTENER = new HashMap<>();
    private final int TR = 5;
    private final int TM = 10;

    private double mPresSceneX, mPresSceneY;
    private double mPresScreeX, mPresScreeY;
    private double mPresstageW, mPresstageH;

    public Window(Stage stage) {
        this.stage = stage;
        setBackground(new Background(new BackgroundFill(Color.rgb(90, 90, 90), new CornerRadii(Constants.CardRadius, false), null)));
        setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(Constants.CardRadius, false),
                new BorderWidths(0.5))));

        scene = new Scene(this, 1200, 675);
        scene.setFill(Color.TRANSPARENT);
        stage.setScene(scene);
        stage.initStyle(StageStyle.TRANSPARENT);
        stage.getIcons().add(new Image("images/icon.jpg"));
        stage.setTitle("JavaFX");
        // stage.getIcons().add(new Image(getClass().getResourceAsStream("images/icon.jpg")));

        createListener();
        launch();
    }

    public void setContent(Parent node) {
        setCenter(node);
    }

    public void show() {
        stage.show();
    }

    private void createListener() {
        LISTENER.put(Cursor.NW_RESIZE, event -> {

            double newWidth = mPresstageW - (event.getScreenX() - mPresScreeX);
            double newHeight = mPresstageH - (event.getScreenY() - mPresScreeY);
            if (newHeight > stage.getMinHeight()) {
                stage.setY(event.getScreenY() - mPresSceneY);
                stage.setHeight(newHeight);
            }
            if (newWidth > stage.getMinWidth()) {
                stage.setX(event.getScreenX() - mPresSceneX);
                stage.setWidth(newWidth);
            }
        });

        LISTENER.put(Cursor.SW_RESIZE, event -> { // NE

            double newWidth = mPresstageW - (event.getScreenX() - mPresScreeX);
            double newHeight = mPresstageH + (event.getScreenY() - mPresScreeY);
            if (newHeight > stage.getMinHeight())
                stage.setHeight(newHeight);
            if (newWidth > stage.getMinWidth()) {
                stage.setX(event.getScreenX() - mPresSceneX);
                stage.setWidth(newWidth);
            }
        });

        LISTENER.put(Cursor.NE_RESIZE, event -> { //SW

            double newWidth = mPresstageW + (event.getScreenX() - mPresScreeX);
            double newHeight = mPresstageH - (event.getScreenY() - mPresScreeY);
            if (newHeight > stage.getMinHeight()) {
                stage.setHeight(newHeight);
                stage.setY(event.getScreenY() - mPresSceneY);
            }
            if (newWidth > stage.getMinWidth())
                stage.setWidth(newWidth);
        });

        LISTENER.put(Cursor.SE_RESIZE, event -> {
            double newWidth = mPresstageW + (event.getScreenX() - mPresScreeX);
            double newHeight = mPresstageH + (event.getScreenY() - mPresScreeY);
            if (newHeight > stage.getMinHeight())
                stage.setHeight(newHeight);
            if (newWidth > stage.getMinWidth())
                stage.setWidth(newWidth);
        });

        LISTENER.put(Cursor.E_RESIZE, event -> {
            double newWidth = mPresstageW - (event.getScreenX() - mPresScreeX);
            if (newWidth > stage.getMinWidth()) {
                stage.setX(event.getScreenX() - mPresSceneX);
                stage.setWidth(newWidth);
            }
        });

        LISTENER.put(Cursor.W_RESIZE, event -> {
            double newWidth = mPresstageW + (event.getScreenX() - mPresScreeX);
            if (newWidth > stage.getMinWidth())
                stage.setWidth(newWidth);
        });

        LISTENER.put(Cursor.N_RESIZE, event -> {
            double newHeight = mPresstageH - (event.getScreenY() - mPresScreeY);
            if (newHeight > stage.getMinHeight()) {
                stage.setY(event.getScreenY() - mPresSceneY);
                stage.setHeight(newHeight);
            }
        });

        LISTENER.put(Cursor.S_RESIZE, event -> {
            double newHeight = mPresstageH + (event.getScreenY() - mPresScreeY);
            if (newHeight > stage.getMinHeight())
                stage.setHeight(newHeight);
        });

        LISTENER.put(Cursor.OPEN_HAND, event -> {
            stage.setX(event.getScreenX() - mPresSceneX);
            stage.setY(event.getScreenY() - mPresSceneY);
        });
    }

    private void launch() {
        scene.setOnMousePressed(event -> {
            mPresSceneX = event.getSceneX();
            mPresSceneY = event.getSceneY();

            mPresScreeX = event.getScreenX();
            mPresScreeY = event.getScreenY();

            mPresstageW = stage.getWidth();
            mPresstageH = stage.getHeight();
        });

        scene.setOnMouseMoved(event -> {
            double sx = event.getSceneX();
            double sy = event.getSceneY();

            boolean l_trigger = sx > 0 && sx < TR;
            boolean r_trigger = sx < scene.getWidth() && sx > scene.getWidth() - TR;
            boolean u_trigger = sy < scene.getHeight() && sy > scene.getHeight() - TR;
            boolean d_trigger = sy > 0 && sy < TR;

            if (l_trigger && d_trigger)
                fireAction(Cursor.NW_RESIZE); 
            else if (l_trigger && u_trigger)
                fireAction(Cursor.SW_RESIZE);
            else if (r_trigger && d_trigger)
                fireAction(Cursor.NE_RESIZE);
            else if (r_trigger && u_trigger)
                fireAction(Cursor.SE_RESIZE);
            else if (l_trigger)
                fireAction(Cursor.E_RESIZE);
            else if (r_trigger)
                fireAction(Cursor.W_RESIZE);
            else if (d_trigger)
                fireAction(Cursor.N_RESIZE);
            else if (sy < TM && !u_trigger)
                fireAction(Cursor.OPEN_HAND);
            else if (u_trigger)
                fireAction(Cursor.S_RESIZE);
            else
                fireAction(Cursor.DEFAULT);
        });
    }

    private void fireAction(Cursor c) {
        scene.setCursor(c);
        if (c != Cursor.DEFAULT)
            scene.setOnMouseDragged(LISTENER.get(c));
        else
            scene.setOnMouseDragged(null);
    }
}

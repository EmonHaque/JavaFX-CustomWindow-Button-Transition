package controls.areachart;

import java.util.List;

import javafx.scene.paint.Color;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;

public class AreaStroke extends Path {
    public void setValue(List<Double> points, double width, double height, double yMax) {
        getElements().clear();
        setStroke(Color.WHITE);
        double xGap = width / (points.size() - 1);
        double yFactor = height / yMax;

        double x = 0;
        double y = points.get(0) * yFactor;
        var start = new MoveTo(x, y);
        getElements().add(start);

        for (int i = 1; i < points.size(); i++) {
            x += xGap;
            y = points.get(i) * yFactor;
            var line = new LineTo(x, y);
            getElements().add(line);
        }
    }
}

package controls.areachart;

import java.util.List;

import javafx.scene.paint.Color;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;

public class AreaFill extends Path {

    public void setValue(List<Double> points, double width, double height, double yMax) {
        getElements().clear();
        setFill(Color.GREEN);
        setOpacity(0.4);

        double xGap = width / (points.size() - 1);
        double yFactor = height / yMax;

        getElements().add(new MoveTo(0, 0));
        double x = 0;

        for (int i = 0; i < points.size(); i++) {
            double y = points.get(i) * yFactor;
            var line = new LineTo(x, y);
            getElements().add(line);
            x += xGap;
        }

        x -= xGap;
        getElements().add(new LineTo(x, 0));
    }
}

package controls;
import javafx.animation.*;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.util.Duration;
import model.PieSeries;
import java.util.List;

public class Pie extends Region {
    Point2D center;
    Circle circle;
    Timeline show, hide;
    double total, size = 240;
    double circleRadius;
    VBox info;
    Text label, value, percent;

    public Pie(List<PieSeries> values) {
        setMinSize(size, size);
        setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, null,null)));
        center = new Point2D(getMinWidth() / 2, getMinHeight() / 2);
        double startAngle = 0;
        total = values.stream().mapToDouble(x -> x.value).sum();
        for (PieSeries s : values) {
            var degree = s.value / total * 360.0;
            var endAngle = degree * Math.PI / 180;
            boolean isLarge = s.value / total > 0.5;
            var slice = new Slice(startAngle, endAngle, isLarge, s);
            startAngle += endAngle;
            getChildren().add(slice);
            slice.addEventHandler(MouseEvent.ANY, this::onMouse);
        }
        circle = new Circle();
        circleRadius = size / 2 - 50;
        circle.setFill(Color.WHITESMOKE);
        getChildren().add(circle);

        show = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(circle.radiusProperty(), 0d)),
                new KeyFrame(Duration.millis(500), new KeyValue(circle.radiusProperty(), circleRadius))
        );
        hide = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(circle.radiusProperty(), circleRadius)),
                new KeyFrame(Duration.millis(500), new KeyValue(circle.radiusProperty(), 0d))
        );
        label = new Text();
        label.setFont(Font.font(null, FontWeight.BOLD, 14));
        label.setFill(Color.CORNFLOWERBLUE);
        value = new Text();
        value.setFont(Font.font(null, FontWeight.BOLD, 12));
        value.setFill(Color.GREEN);
        percent = new Text();
        percent.setFont(Font.font(null, FontPosture.ITALIC, 12));
        percent.setFill(Color.GRAY);
        info = new VBox(label, value, percent);
        info.setAlignment(Pos.CENTER);
        getChildren().add(info);
    }

    @Override
    protected void layoutChildren() {
        //super.layoutChildren();
        var width = getLayoutBounds().getWidth();
        var height = getLayoutBounds().getHeight();
        var cx = getLayoutBounds().getCenterX();
        var cy = getLayoutBounds().getCenterY();
        var children = getChildren();
        double radius = width > height ? height / 2 - 10 : width / 2 - 10;
        circleRadius = width > height ? height / 2 - 50 : width /2 - 50;
        for (var c : children) {
            if (c instanceof Slice slice) {
                slice.setValue(new Point2D(cx, cy), radius);
            } else if(c instanceof Circle circle) {
                circle.setCenterX(cx);
                circle.setCenterY(cy);
            }else {
                info.setLayoutX(cx);
                info.setLayoutY(cy);
            }
        }
        //super.layoutChildren();
    }

    void onMouse(MouseEvent e) {
        if (e.getEventType() == MouseEvent.MOUSE_ENTERED) {
            show.play();
            var slice = (Slice)e.getSource();
            label.setText(slice.getSeries().title);
            value.setText((int)slice.getSeries().value + "");
            percent.setText(String.format("%.2f", slice.getSeries().value/total * 100) + "%");
            info.setVisible(true);
        } else if (e.getEventType() == MouseEvent.MOUSE_EXITED) {
            hide.play();
            info.setVisible(false);
        }
    }
}

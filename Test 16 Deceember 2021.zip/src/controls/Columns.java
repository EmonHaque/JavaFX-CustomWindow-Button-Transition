package controls;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;
import javafx.scene.transform.Scale;
import model.ColumnSeries;
import java.util.List;

public class Columns extends Region {
    double labelHeight, labelWidth, min, max;
    double size = 240;
    double gap = 15;
    List<ColumnSeries> series;

    public Columns(List<ColumnSeries> series) {
        this.series = series;
        setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, null,null)));
        setMinSize(size,size);
        min = 0;
        for (int i = 0; i < series.size(); i++) {
            var total = series.get(i).getValues().stream().mapToDouble(x -> x).sum();
            if (max < total) max = total;
        }
        double step = max / 5;
        double current = min;
        for (int i = 0; i < 6; i++) {
            var line = new Line();
            line.setStroke(Color.GRAY);

            line.getStrokeDashArray().addAll(5d, 2d);
            getChildren().add(line);
            var label = new Text(String.format("%.1f", current));
            current += step;
            getChildren().add(label);
            labelWidth = label.prefWidth(-1);
            labelHeight = label.prefHeight(-1);
        }
        for (var s : series) {
            var column = new ColumnStack(s);
            column.getTransforms().add(new Scale(1,-1));
            getChildren().add(column);
        }
    }

    int count = 0;
    @Override
    protected void layoutChildren() {
        //super.layoutChildren();
        var children = getChildren();
        var height = getLayoutBounds().getHeight();
        var width = getLayoutBounds().getWidth();
        var vSpace = height / 6;
        var colWidth = (size - labelWidth - series.size() * gap) / series.size();
        System.out.println("Here " + ++count);
        double lineY = height;
        double labelY = lineY - 5;
        double x = labelWidth + gap;

        for (var child : children) {
            if(child instanceof Line line){
                line.setStartY(lineY);
                line.setEndY(lineY);
                line.setEndX(width);
                lineY -= vSpace;
            }
            else if(child instanceof Text text){
                text.setY(labelY);
                labelY -= vSpace;
            }
            else if(child instanceof ColumnStack column){
                var h = column.getTotal() * (height - vSpace) / max;
                column.makeColumn(colWidth, h);
                column.setLayoutX(x);
                column.setLayoutY(height);
                x += colWidth + gap;
            }
        }
        //super.layoutChildren();
    }
}

package viewModels;
import controls.Slice;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.print.PrinterJob;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.text.Text;
import model.Person;

import java.util.Random;

public class AViewModel {
    int count;
    public StringProperty labelTextProperty; // bound OneWay
    public StringProperty box1TextProperty; // bound OneWayToSource
    public StringProperty box2TextProperty; // bound TwoWay
    public StringProperty query;
    public ObjectProperty<Person> selectedPerson;
    ObservableList<Person> privatePeople;
    public FilteredList<Person> people;
    public AViewModel(){
        privatePeople = FXCollections.observableArrayList();
        var rand = new Random();
        for (int i = 0; i < 100; i++){
            var p = new Person();
            p.name = "Person " + i;
            p.phone = String.valueOf(rand.nextInt(10000) + 100000);
            privatePeople.add(p);
        }
        people = new FilteredList<>(privatePeople);
        labelTextProperty = new SimpleStringProperty();
        box1TextProperty = new SimpleStringProperty();
        box2TextProperty = new SimpleStringProperty();
        selectedPerson = new SimpleObjectProperty<>();
        selectedPerson.addListener((observable, oldValue, newValue) -> {
            if(newValue != null)
                System.out.println(newValue.name + " | " + newValue.phone);
            else System.out.println("Null");
        });
        query = new SimpleStringProperty();
        query.addListener((observable, oldValue, newValue) -> {
            people.setPredicate(p -> p.name.toLowerCase().contains(newValue));
        });
        Slice.setExecutor(AViewModel::sliceExecute);
    }
    public void setText(){
        var printer = PrinterJob.createPrinterJob();
        var result = printer.showPrintDialog(null);
        var layout = printer.getJobSettings().getPageLayout();
        System.out.println("H " + layout.getPrintableHeight() + " W " + layout.getPrintableWidth());

//        var left = new Text("Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text Left Text ");
//        left.setWrappingWidth(layout.getPrintableWidth() - 100);
//        var right = new Text("Right Text");
//        var spacer = new Region();
//        HBox.setHgrow(spacer, Priority.ALWAYS);
//        var hBox = new HBox(left, spacer, right);
//        hBox.setMinWidth(layout.getPrintableWidth());
//        System.out.println(hBox.prefHeight(-1));
//        printer.printPage(hBox);
//        printer.endJob();

        var text = "Clicked " + ++count;
        labelTextProperty.set(text);
        System.out.println("Box 1: " + box1TextProperty.get());
        System.out.println("Box 2: " + box2TextProperty.get());
        box2TextProperty.set("");
    }
    public static void sliceExecute(Slice s){
        System.out.println("Executed " + s.getSeries().title);
    }
}

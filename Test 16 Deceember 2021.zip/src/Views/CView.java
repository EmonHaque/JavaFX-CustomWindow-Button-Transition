package Views;
import abstracts.View;
import helpers.Icons;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class CView extends View {
    @Override
    protected String getIcon() {
        return Icons.Edit;
    }

    @Override
    protected String getHeader() {
        return "C View";
    }

    @Override
    protected String getTip() {
        return "C View";
    }

    @Override
    protected Node getContent() {
        var box = new VBox();
        box.setAlignment(Pos.CENTER);
        var label = new Label("Content of C View");
        box.getChildren().add(label);
        return box;
    }
}

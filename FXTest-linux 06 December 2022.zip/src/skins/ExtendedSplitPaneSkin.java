package skins;

import controls.SVGIcon;
import helpers.Constants;
import helpers.Icons;
import javafx.geometry.Orientation;
import javafx.scene.control.SplitPane;
import javafx.scene.control.skin.SplitPaneSkin;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;

public class ExtendedSplitPaneSkin extends SplitPaneSkin {
    private boolean isLoaded;
    private StackPane divider, grabber;
    private Orientation orientation;

    public ExtendedSplitPaneSkin(SplitPane control) {
        super(control);
        control.setBackground(null);
    }

    private void onMouse(MouseEvent e){
        if(e.getEventType() == MouseEvent.MOUSE_ENTERED){
            if(orientation == Orientation.HORIZONTAL){
                grabber.setPrefSize(12, 20);
            }
            else{
                grabber.setPrefSize(20, 12);
            }
            divider.setBackground(Background.fill(Color.WHITE));
            grabber.setBackground(Background.fill(Color.CORNFLOWERBLUE));
        }
        else if(e.getEventType() == MouseEvent.MOUSE_EXITED){
            if(orientation == Orientation.HORIZONTAL){
                grabber.setPrefSize(12, 12);
            }
            else{
                grabber.setPrefSize(12, 12);
            }
            divider.setBackground(Background.fill(Constants.BackgroundColorLight));
            grabber.setBackground(Background.fill(Constants.BackgroundColorLight));
        }
    }

    @Override
    protected void layoutChildren(double x, double y, double w, double h) {
        if (!isLoaded) {
            isLoaded = true;
            orientation = getSkinnable().getOrientation();
            divider = (StackPane) getSkinnable().lookup(".split-pane-divider");
            divider.setBackground(Background.fill(Constants.BackgroundColorLight));

            if (orientation == Orientation.HORIZONTAL) {
                divider.setPrefWidth(0.25);
                grabber = (StackPane) divider.lookup(".horizontal-grabber");
                grabber.setShape(new SVGIcon(Icons.SpllierHorizontal));
                grabber.setPrefSize(12, 12);
            }
            else {
                divider.setPrefHeight(0.25);
                grabber = (StackPane) divider.lookup(".vertical-grabber");
                grabber.setShape(new SVGIcon(Icons.SplitterVertical));
                grabber.setPrefSize(12, 12);
            }
            grabber.setBackground(Background.fill(Constants.BackgroundColorLight));
            divider.addEventHandler(MouseEvent.ANY, this::onMouse);
        }
        super.layoutChildren(x, y, w, h);
    }
}

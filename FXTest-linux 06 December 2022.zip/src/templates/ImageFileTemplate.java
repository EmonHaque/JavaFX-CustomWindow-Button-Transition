package templates;

import controls.buttons.ActionButtonArg;
import helpers.Constants;
import helpers.Icons;
import interfaces.IExecuteArg;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.layout.Background;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import model.ImageFile;

public class ImageFileTemplate extends ListCell<ImageFile> {
    private HBox box;
    private Text name, size;
    private Region spacer;
    private IExecuteArg<ImageFile> executor;
    private ActionButtonArg<ImageFile> button;

    public ImageFileTemplate(IExecuteArg<ImageFile> executor) {
        this.executor = executor;
       setBackground(null);
       setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
       setPadding(new Insets(1,0,1,0));

       initializeUI();
       itemProperty().addListener(this::onItemChanged);
    }

    private void initializeUI(){
        name = new Text();
        size = new Text();
        button = new ActionButtonArg<>(Icons.MinusCircle, 16, "remove");
        spacer = new Region();
        name.setFill(Color.WHITE);
        size.setFill(Color.WHITE);
        HBox.setHgrow(spacer, Priority.ALWAYS);
        HBox.setMargin(button, new Insets(0,0,0,5));
        box = new HBox(name, spacer, size, button);
        box.setAlignment(Pos.CENTER);
    }

    private void onItemChanged(ObservableValue<?> o, ImageFile ov, ImageFile nv){
        if(ov != null){
            name.setText(null);
            size.setText(null);
            button.setAction(null, null);
        }
        if(nv != null){
            name.setText(nv.getName());
            size.setText(String.format("%,d", nv.getSize()));
            button.setAction(executor, nv);
        }
    }

    @Override
    protected void updateItem(ImageFile item, boolean empty) {
        super.updateItem(item, empty);
        if(empty){
            setGraphic(null);
            setBackground(null); // when you remove an item background doesn't change
        }
        else{
            setGraphic(box);
            setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
        }
    }
}

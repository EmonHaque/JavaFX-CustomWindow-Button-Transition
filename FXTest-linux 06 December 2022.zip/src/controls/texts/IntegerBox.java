package controls.texts;

import java.text.NumberFormat;
import java.text.ParsePosition;

import javafx.scene.control.TextFormatter;

public class IntegerBox extends TextBox {
    NumberFormat numberFormat;

    public IntegerBox(String hint, String icon) {
        super(hint, icon);
        numberFormat = NumberFormat.getIntegerInstance();
        
        input.setTextFormatter(new TextFormatter<>(change -> {
            if (change.getControlNewText().isEmpty()) {
                return change;
            }
            var position = new ParsePosition(0);
            var obj = numberFormat.parseObject(change.getControlNewText(), position);
            if (obj != null && position.getIndex() == change.getControlNewText().length()) {
                return change;
            }
            return null;
        }));
    }

}

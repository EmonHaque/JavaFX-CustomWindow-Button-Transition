package controls.buttons;

import interfaces.IExecuteArg;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

public class ActionButtonArg<T> extends ActionButtonBase {
    protected IExecuteArg<T> executor;
    protected T arg;

    public ActionButtonArg(String icon, double size, String tip) {
        super(icon, size, tip);
        setOnMouseClicked(this::onClicked);
    }

    protected void onClicked(MouseEvent e) {
        animate(Color.CORAL);
        if (executor != null && arg != null)
            executor.execute(arg);
    }

    public void setAction(IExecuteArg<T> executor) {
        this.executor = executor;
    }

    public void setAction(IExecuteArg<T> executor, T arg) {
        this.executor = executor;
        this.arg = arg;
    }

    public void setArg(T arg) {
        this.arg = arg;
    }
}

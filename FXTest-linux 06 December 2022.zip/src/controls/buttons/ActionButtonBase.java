package controls.buttons;

import javafx.animation.Animation;
import javafx.animation.FillTransition;
import javafx.beans.property.BooleanProperty;
import javafx.scene.control.Button;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.paint.Color;
import javafx.scene.shape.SVGPath;
import javafx.util.Duration;

public class ActionButtonBase extends Button {
    private SVGPath path;
    private FillTransition anim;
    private Tooltip toolTip;
    private boolean isActive;

    public BooleanProperty isdisabledProperty;

    public ActionButtonBase(String icon, double size, String tip) {
        setBackground(Background.fill(Color.TRANSPARENT));
        setMinSize(size,size);
        setMaxSize(size,size);
        setPrefSize(size,size);
        addEventHandler(MouseEvent.ANY, this::handleState);

        path = new SVGPath();
        path.setContent(icon);
        path.setFill(Color.WHITE);
        double newSize = size - 4;
        path.setScaleX(newSize / path.prefWidth(-1));
        path.setScaleY(newSize / path.prefHeight(-1));
        anim = new FillTransition(Duration.millis(300));
        anim.setShape(path);
        toolTip = new Tooltip(tip);
        setGraphic(path);
        setTooltip(toolTip);

        disabledProperty().addListener((o, ov, nv) -> path.setFill( nv ? Color.GRAY : Color.WHITE));
    }

    protected void animate(Color color){
        if(anim.getStatus() == Animation.Status.RUNNING) anim.stop();
        anim.setToValue(color);
        anim.play();
    }
    private void handleState(MouseEvent e){
        if(isActive) return;
        if(disabledProperty().get()) return;

        if(e.getEventType() == MouseEvent.MOUSE_ENTERED){
            animate(Color.CORAL);
        }
        else if(e.getEventType() == MouseEvent.MOUSE_PRESSED){
            animate(Color.RED);
        }
        else if (e.getEventType() == MouseEvent.MOUSE_EXITED){
            animate(Color.WHITE);
        }
    }
   
    public void setIcon(String icon){
        path.setContent(icon);
    }
    public void setTip(String tip){
        toolTip.setText(tip);
    }
    public void setActive(boolean value){
        isActive = value;
        if(isActive) animate(Color.CORNFLOWERBLUE);
        else animate(Color.WHITE);
    }
}

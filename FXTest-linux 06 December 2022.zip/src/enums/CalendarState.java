package enums;

public enum CalendarState {
    Day,
    Month,
    Year
}

package enums;

public enum NavPosition {
    TopLeftHorizontal,
    TopRightHorizontal,
    TopCenter,
    BottomLeftHorizontal,
    BottomRightHorizontal,
    BottomCenter,
    TopRightVertical,
    BottomRightVertical,
    RightCenter,
    TopLeftVertical,
    BottomLeftVertical,
    LeftCenter
}

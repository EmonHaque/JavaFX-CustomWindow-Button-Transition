package Views.GSubViews;

public class GEView extends GAbstractView {

    @Override
    protected String getName() {
        return "GE";
    }
}

package viewModels;
import controls.Slice;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import model.Person;

import java.util.Random;

public class AViewModel {
    int count;
    public StringProperty labelTextProperty; // bound OneWay
    public StringProperty box1TextProperty; // bound OneWayToSource
    public StringProperty box2TextProperty; // bound TwoWay
    public StringProperty query;
    public ObjectProperty<Person> selectedPerson;
    ObservableList<Person> privatePeople;
    public FilteredList<Person> people;
    public AViewModel(){
        privatePeople = FXCollections.observableArrayList();
        var rand = new Random();
        for (int i = 0; i < 100; i++){
            var p = new Person();
            p.name = "Person " + i;
            p.phone = String.valueOf(rand.nextInt(10000) + 100000);
            privatePeople.add(p);
        }
        people = new FilteredList<>(privatePeople);
        labelTextProperty = new SimpleStringProperty();
        box1TextProperty = new SimpleStringProperty();
        box2TextProperty = new SimpleStringProperty();
        selectedPerson = new SimpleObjectProperty<>();
        selectedPerson.addListener((observable, oldValue, newValue) -> {
            if(newValue != null)
                System.out.println(newValue.name + " | " + newValue.phone);
            else System.out.println("Null");
        });
        query = new SimpleStringProperty();
        query.addListener((observable, oldValue, newValue) -> {
            people.setPredicate(p -> p.name.toLowerCase().contains(newValue));
        });
        Slice.setExecutor(AViewModel::sliceExecute);
    }
    public void setText(){
        var text = "Clicked " + ++count;
        labelTextProperty.set(text);
        System.out.println("Box 1: " + box1TextProperty.get());
        System.out.println("Box 2: " + box2TextProperty.get());
        box2TextProperty.set("");
    }
    public static void sliceExecute(Slice s){
        System.out.println("Executed " + s.getSeries().title);
    }
}

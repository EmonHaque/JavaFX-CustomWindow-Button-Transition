package controls;

import controls.ActionButton;
import helpers.Icons;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.effect.BlurType;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Window extends BorderPane {
    double radius = 5.0;
    Stage stage;
    HBox titleBar;
    ActionButton maxRestore;
    double currentX, currentY;

    public Window(Stage stage){
        this.stage = stage;
        setBackground(new Background(new BackgroundFill(Color.WHITESMOKE, new CornerRadii(radius, false), null)));
        setBorder(new Border(new BorderStroke(Color.SLATEGRAY, BorderStrokeStyle.SOLID, new CornerRadii(radius, false), BorderWidths.DEFAULT)));
        addTitleBar();
        var scene = new Scene(this, 800,600);
        scene.setFill(Color.TRANSPARENT);
        stage.setScene(scene);
        stage.initStyle(StageStyle.TRANSPARENT);
        stage.getIcons().add(new Image("images/icon.jpg"));
        stage.setTitle("JavaFX");
        //stage.getIcons().add(new Image(getClass().getResourceAsStream("images/icon.jpg")));
    }
    void addTitleBar() {
        maxRestore = new ActionButton(Icons.Maximize, 16, "Maximize");
        var minimize = new ActionButton(Icons.Minimize, 16, "Minimize");
        var close = new ActionButton(Icons.Close, 16, "Close");
        var effect = new DropShadow();
        effect.setOffsetX(0);
        effect.setOffsetY(3);
        effect.setRadius(5);
        effect.setColor(Color.DARKGRAY);
        effect.setBlurType(BlurType.GAUSSIAN);
        titleBar = new HBox();
        titleBar.setMinHeight(24);
        titleBar.setAlignment(Pos.CENTER_RIGHT);
        HBox.setMargin(close, new Insets(0,5,0,0));
        titleBar.setBackground(new Background(new BackgroundFill(Color.SLATEGRAY, new CornerRadii(radius, radius,0,0, false),null)));
        titleBar.setEffect(effect);
        titleBar.getChildren().addAll(minimize, maxRestore, close);
        setTop(titleBar);

        minimize.setAction(this::minimize);
        maxRestore.setAction(this::maxRestore);
        close.setAction(Platform::exit);

        titleBar.setOnMousePressed(this::setCurrentXY);
        titleBar.setOnMouseDragged(this::move);
    }
    void setCurrentXY(MouseEvent e) {
        currentX = e.getX();
        currentY = e.getY();
    }
    void move(MouseEvent e) {
        stage.setX(e.getScreenX() - currentX);
        stage.setY(e.getScreenY() - currentY);
    }
    void minimize(){
        stage.setIconified(true);
    }
    void maxRestore(){
        if(stage.isMaximized()) {
            stage.setMaximized(false);
            maxRestore.setIcon(Icons.Maximize);
            maxRestore.setTip("Maximize");
        }
        else {
            stage.setMaximized(true);
            maxRestore.setIcon(Icons.Restore);
            maxRestore.setTip("Restore");
        }
    }
    public void setContent(Parent node){
        setCenter(node);
    }
    public void show(){
        stage.show();
    }
}

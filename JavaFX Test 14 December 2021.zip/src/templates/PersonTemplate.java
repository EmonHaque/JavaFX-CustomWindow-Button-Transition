package templates;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import model.Person;

public class PersonTemplate extends ListCell<Person> {
    public StringProperty query;
    PersonVisual visual;
    public PersonTemplate(StringProperty q) {
        query = new SimpleStringProperty();
        query.bind(q);
    }

    @Override
    protected void updateItem(Person item, boolean empty) {
        super.updateItem(item, empty);
        if(empty) {
            setGraphic(null);
            setText(null);
        }
        else{
            setPrefWidth(0);
            visual = new PersonVisual();
            visual.setContent(item);
            visual.getHiText().query.bind(query);
            setGraphic(visual);
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        }
    }
}

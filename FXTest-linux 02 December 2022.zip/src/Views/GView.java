package Views;

import java.util.ArrayList;
import java.util.List;

import Views.GSubViews.GAView;
import Views.GSubViews.GBView;
import Views.GSubViews.GCView;
import Views.GSubViews.GDView;
import Views.GSubViews.GEView;
import Views.GSubViews.GFView;
import abstracts.View;
import helpers.Constants;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import viewModels.GViewModels.GService;

public class GView extends View {
    GService service;
    GAView aView;
    GBView bView;
    GCView cView;
    GDView dView;
    GEView eView;
    GFView fView;

    public GView() {
        service = new GService();
        aView = new GAView();
        bView = new GBView();
        cView = new GCView();
        dView = new GDView();
        eView = new GEView();
        fView = new GFView();
    }

    @Override
    protected String getIcon() {
        return Icons.GCircle;
    }

    @Override
    public boolean isContainer() {
        return true;
    }

    @Override
    protected String getTip() {
        return "G View";
    }

    @Override
    public List<View> initialViews() {
        views = new ArrayList<>();
        views.add(aView);
        views.add(bView);
        views.add(cView);
        views.add(dView);
        views.add(eView);
        views.add(fView);
        return views;
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight GView");

        var grid = new GridPane();
        grid.add(aView, 0, 0);
        grid.add(bView, 1, 0);
        grid.add(cView, 2, 0);

        grid.add(dView, 0, 1);
        grid.add(eView, 1, 1);
        grid.add(fView, 2, 1);

        var colCon = new ColumnConstraints();
        colCon.setPercentWidth(33.33);
        var rowCon = new RowConstraints();
        rowCon.setPercentHeight(50);

        grid.getColumnConstraints().addAll(colCon, colCon, colCon);
        grid.getRowConstraints().addAll(rowCon, rowCon);
        grid.setVgap(Constants.CardMargin);
        grid.setHgap(Constants.CardMargin);
        BorderPane.setMargin(grid, new Insets(Constants.CardMargin));

        setCenter(grid);
    }
}

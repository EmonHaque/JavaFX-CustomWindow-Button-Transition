package Views;

import Views.ESubViews.EAView;
import Views.ESubViews.EBView;
import Views.ESubViews.ECView;
import Views.ESubViews.EDView;
import abstracts.View;
import abstracts.ViewContainer;
import helpers.Icons;

public class EView extends ViewContainer {
    View A;
    public EView() {
        super();
        A = new EAView();
        addView(A);
        addView(new EBView());
        addView(new ECView());
        addView(new EDView());
    }

    @Override
    public View initialView() {
        return A;
    }
    
    @Override
    protected String getIcon() {
        return Icons.ECircle;
    }

    @Override
    protected String getTip() {
        return "E View";
    }
    
}

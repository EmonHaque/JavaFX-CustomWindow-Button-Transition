package Views.ASubViews;

import abstracts.View;
import controls.SelectionBox;
import controls.buttons.ActionButton;
import controls.daymonth.DayPicker;
import controls.daymonth.MonthPicker;
import controls.states.BiState;
import controls.states.MultiState;
import controls.texts.PasswordBox;
import controls.texts.TextBox;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import model.Person;
import skinned.ExtendedScrollPane;
import templates.PersonTemplate;
import templates.PersonVisual;
import viewModels.AViewModels.TestControlVM;

public class TestControls extends View {
    TestControlVM vm;
    PersonTemplate temp;
    
    @Override
    protected String getHeader() {
        return "Test Controls";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight Test Controls");

        vm = new TestControlVM();
        var box = new VBox();
        box.setAlignment(Pos.CENTER);
        box.setSpacing(5);
        var label = new Label("Content of A View");
        label.setFont(Font.font(24));
        label.setTextFill(Color.WHITE);

        var button = new ActionButton(Icons.Add, 16, "Execute");
        button.setAction(vm::setText);
        var checkBox = new BiState(true, "");
        checkBox.isCheckedProperty().bindBidirectional(vm.isChecked);
        checkBox.textProperty().bind(vm.checkText);
        var multiBox = new MultiState(new String[] { Icons.Add, Icons.Edit, Icons.Delete }, new String[] { "add", "edit", "delete" }, true);
        vm.currentState.bind(multiBox.stateProperty);

        var controlBox = new HBox();
        controlBox.setSpacing(5);
        controlBox.setAlignment(Pos.CENTER);
        controlBox.getChildren().addAll(button, checkBox, multiBox);

        var boundLabel = new Label("Test");
        var boundTextBox1 = new TextBox("Name", Icons.User);
        var boundTextBox2 = new PasswordBox("Password", Icons.Password);

        boundLabel.textProperty().bind(vm.labelTextProperty);
        // Binding Mode OneWayToSource
        vm.box1TextProperty.bind(boundTextBox1.textProperty);
        // Binding Mode TwoWay
        // vm.box2TextProperty.bindBidirectional(boundTextBox2.textProperty());
        boundTextBox2.textProperty.bindBidirectional(vm.box2TextProperty);

        // var combo = new SelectionBox2<Person>("Person", Icons.Tenant, vm.people, new PersonVisual());
        var combo = new SelectionBox<Person>("Person", Icons.Tenant, vm.people, new PersonVisual());
        combo.getView().setCellFactory(v -> new PersonTemplate(combo.query));
        vm.query.bind(combo.query);
        vm.selectedPerson.bind(combo.selectedItem);

        //var monthPicker = new MonthPickerOld("Pick a month");
        var monthPicker = new MonthPicker("Pick a month", Icons.Month);
        //var dayPicker = new DayPickerOld();
        var dayPicker = new DayPicker("Select a day", Icons.Month);

        dayPicker.startDate.bind(Bindings.select(vm, "startDate"));
        dayPicker.endDate.bind(Bindings.select(vm, "endDate"));
        dayPicker.selectedDate.bindBidirectional(vm.selectedDate);

        box.getChildren().addAll(label, controlBox, boundLabel, boundTextBox1, boundTextBox2, combo, monthPicker, dayPicker);

        //setCenter(box);
        var scroll = new ExtendedScrollPane(box);
        scroll.setFitToWidth(true);
        scroll.setHbarPolicy(ScrollBarPolicy.NEVER);
        scroll.setPadding(new Insets(5));
        BorderPane.setMargin(scroll, new Insets(5,0,0,0));
        setCenter(scroll);
    }
}

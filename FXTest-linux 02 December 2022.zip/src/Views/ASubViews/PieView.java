package Views.ASubViews;

import abstracts.View;
import controls.buttons.ActionButton;
import controls.piechart.Pie;
import helpers.Icons;
import viewModels.AViewModels.PieViewVM;

public class PieView extends View {
    Pie pie;
    ActionButton refresh;
    PieViewVM vm;

    @Override
    protected String getHeader() {
        return "Pie View";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight PieView");

        vm = new PieViewVM();
        initializeUI();
        bind();
    }

    private void initializeUI() {
        refresh = new ActionButton(Icons.Reload, 14, "refresh");
        pie = new Pie();
        super.addAction(refresh);
        super.setCenter(pie);
    }

    private void bind() {
        refresh.setAction(vm::generateSeries);
        pie.seriesProperty.bind(vm.seriesProperty);
        PieViewVM.selectedSliceProperty.bind(pie.selectedProperty);
    }
}

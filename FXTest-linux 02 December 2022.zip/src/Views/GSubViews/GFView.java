package Views.GSubViews;

public class GFView extends GAbstractView {

    @Override
    protected String getName() {
        return "GF";
    }
}

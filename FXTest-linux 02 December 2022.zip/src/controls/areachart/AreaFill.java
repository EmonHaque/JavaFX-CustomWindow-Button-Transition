package controls.areachart;

import java.util.List;

import javafx.scene.paint.Color;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;

public class AreaFill extends Path {
    List<Double> points;
    MoveTo start;

    public AreaFill() {
        setFill(Color.GREEN);
        setStroke(null);
        //setStrokeWidth(0);
        setOpacity(0.4);
        start = new MoveTo(0, 0);
    }

    public void setData(List<Double> points) {
        this.points = points;
        getElements().clear();
        getElements().add(start);

        for (int i = 0; i < points.size(); i++) {
            getElements().add(new LineTo());
        }
        getElements().add(new LineTo());
    }

    public void clear(){
        getElements().clear();
    }
    
    public void setValue(double width, double height, double yMax) {
        double xGap = width / (points.size() - 1);
        double yFactor = height / yMax;
        double x = 0;
        LineTo line;
        int index;
        for (index = 1; index < getElements().size() - 1; index++) {
            var y = points.get(index - 1) * yFactor;
            line = (LineTo) getElements().get(index);
            line.setX(x);
            line.setY(y);
            x += xGap;
        }
        x -= xGap;
        line = (LineTo) getElements().get(index);
        line.setX(x);
        line.setY(0);
    }
}

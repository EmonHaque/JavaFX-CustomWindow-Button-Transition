package controls.columnstackchart;

import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Separator;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.scene.transform.Scale;
import javafx.stage.Popup;
import javafx.util.Duration;
import model.ColumnSeries;

import java.util.List;

public class ColumnStack extends StackPane {
    private Popup pop;
    private VBox content;
    private double total, width, height;
    private List<Double> values;

    private Timeline anim;
    private DoubleProperty columnHeight;

    public ColumnStack(ColumnSeries series) {
        getTransforms().add(new Scale(1, -1));
        values = series.getValues();
        total = values.stream().mapToDouble(s -> s).sum();

        content = new VBox(new Text(series.getName()), new Separator());
        for (int i = 0; i < values.size(); i++) {
            content.getChildren().add(new Text("Value " + (i + 1) + " is " + String.format("%.2f", values.get(i))));

            Column rect = null;
            if (i > 0 && values.get(i) != 0) {
                rect = new Column(Color.GREEN, Color.CORAL, true);
            }
            else {
                if (values.get(1) == 0) {
                    rect = new Column(Color.CORNFLOWERBLUE, Color.BLUE, true);
                }
                else if (values.get(i) != 0) {
                    rect = new Column(Color.CORNFLOWERBLUE, Color.BLUE, false);
                }
            }
            getChildren().add(rect);
            rect.setManaged(false);
            rect.setMouseTransparent(true);
        }
        content.setPadding(new Insets(10));
        content.setAlignment(Pos.CENTER);
        content.setBackground(new Background(new BackgroundFill(Color.CORAL, new CornerRadii(10), null)));
        pop = new Popup();
        pop.getContent().add(content);

        setOnMouseEntered(this::onMouseEntered);
        setOnMouseExited(this::onMouseExited);

        var clip = new Rectangle();
        layoutBoundsProperty().addListener((observable, oldValue, newValue) -> {
            clip.setWidth(newValue.getWidth());
            clip.setHeight(newValue.getHeight());
        });
        setClip(clip);
        columnHeight = new SimpleDoubleProperty(0);
    }

    public double getTotal() {
        return total;
    }

    public void makeColumn(double width, double height) {
        this.width = width;
        this.height = height;

        columnHeight.addListener((o, ov, nv) -> {
            setHeight(nv.doubleValue());
        });
        var key = new KeyValue(columnHeight, height, Interpolator.EASE_IN);
        var frame = new KeyFrame(Duration.millis(500), key);
        anim = new Timeline(frame);
        anim.setDelay(Duration.millis(500));
        anim.play();
        anim.setOnFinished(e -> setClip(null));
    }

    @Override
    protected void layoutChildren() {
        if (columnHeight.get() == 0)
            return;
        double y = 0;
        for (int i = 0; i < values.size(); i++) {
            var h = height / total * values.get(i);
            var rect = (Column) getChildren().get(i);
            rect.setValue(0, y, width, h);
            y += h;
        }
    }

    @SuppressWarnings("unchecked")
    void onMouseEntered(MouseEvent e) {
        for (var column : (List<Column>) (List<?>) getChildren()) {
            column.highlightColor();
        }
        var point = localToScreen(width / 2, height);
        var x = point.getX() - content.prefWidth(-1) / 2;
        var y = point.getY() - content.prefHeight(-1) - 5;
        // var y = point.getY() - height - content.prefHeight(-1) - 5; // without Scale
        // Transform
        pop.show(this, x, y);
    }

    @SuppressWarnings("unchecked")
    void onMouseExited(MouseEvent e) {
        for (var column : (List<Column>) (List<?>) getChildren()) {
            column.normalColor();
        }
        pop.hide();
    }
}

package interfaces;

import javafx.scene.Node;

public interface ISetContent<T> {
    void setContent(T item);
    Node getVisual();
}

package skinned;

import javafx.scene.AccessibleAttribute;
import javafx.scene.Node;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.Region;
import skins.ExtendedScrollBarSkin;

public class ExtendedScrollPane extends ScrollPane {
    boolean isLoaded;
    public ExtendedScrollPane() {
        super();
    }
    public ExtendedScrollPane(Node n) {
        super(n);
    }
    @Override
    protected void layoutChildren() {
        if(!isLoaded){
            isLoaded = true;
            applySkin();
        }
        super.layoutChildren();
    }
    private void applySkin() {
        var port = (Region) lookup(".viewport");
        var content = (Region) getContent();
        setBackground(null);
        content.setBackground(null);
        port.setBackground(null);
        var vBar = (ScrollBar) queryAccessibleAttribute(AccessibleAttribute.VERTICAL_SCROLLBAR);
        var hBar = (ScrollBar) queryAccessibleAttribute(AccessibleAttribute.VERTICAL_SCROLLBAR);
        vBar.setSkin(new ExtendedScrollBarSkin(vBar));
        hBar.setSkin(new ExtendedScrollBarSkin(hBar));
     }
}

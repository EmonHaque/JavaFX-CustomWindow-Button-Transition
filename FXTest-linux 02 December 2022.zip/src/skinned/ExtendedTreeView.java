package skinned;

import javafx.scene.control.Skin;
import javafx.scene.control.TreeView;
import skins.ExtendedTreeViewSkin;

public class ExtendedTreeView<T> extends TreeView<T> {

    public ExtendedTreeView() {
        super();
        setBackground(null);
    }

    @Override
    protected Skin<?> createDefaultSkin() {
        return new ExtendedTreeViewSkin<>(this);
    }
}

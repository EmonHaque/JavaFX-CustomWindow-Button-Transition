package skins;

import javafx.scene.AccessibleAttribute;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.skin.TextAreaSkin;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;

public class ExtendedTextAreaSkin extends TextAreaSkin {
    boolean isLoaded;
    public ExtendedTextAreaSkin(TextArea control) {
        super(control);
        control.setBackground(null);
        control.setWrapText(true);
        setTextFill(Color.WHITE);
        setHighlightFill(Color.rgb(0, 0, 0, 0.5));
    }

    @Override
    protected void layoutChildren(double contentX, double contentY, double contentWidth, double contentHeight) {
        super.layoutChildren(contentX, contentY, contentWidth, contentHeight);
        if (!isLoaded) {
            applySkin();
            isLoaded = true;
        }
    }

    private void applySkin() {
        var pane = (ScrollPane) getNode().lookup(".scroll-pane");
        var port = (Region) pane.lookup(".viewport");
        var content = (Region) pane.getContent();
        content.setBackground(null);
        port.setBackground(null);
        pane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        var vBar = (ScrollBar) pane.queryAccessibleAttribute(AccessibleAttribute.VERTICAL_SCROLLBAR);
        vBar.setSkin(new ExtendedScrollBarSkin(vBar));
     }
}

import Views.*;
import controls.MainPanel;
import controls.Window;
import javafx.application.Application;
import javafx.stage.Stage;
import viewModels.GViewModels.GService;

public class App extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        var window = new Window(stage);
        var panel = new MainPanel(stage);
        panel.addView(new AView());
        panel.addView(new BView());
        panel.addView(new CView());
        panel.addView(new DView());
        panel.addView(new EView());
        panel.addView(new FView());
        panel.addView(new GView());
        panel.setTitle("JavaFX");
        window.setContent(panel);
        window.show();
    }
    
    @Override
    public void stop() throws Exception {
        GService.shutDown();
        super.stop();
    }
    public static void main(String[] a) {
        //System.setProperty("quantum.multithreaded", "false");
        launch(a);
    }
}

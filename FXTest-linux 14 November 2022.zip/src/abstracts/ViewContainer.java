package abstracts;

import controls.ActionButton;
import enums.NavOverlap;
import enums.NavPosition;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.TranslateTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

public class ViewContainer extends BorderPane {
    public String icon;
    public String toolTip;
    private GridPane navbar;
    private StackPane containers;
    private int currentIndex;
    private TranslateTransition getIn, getOut;
    private NavPosition navPosition;
    private NavOverlap overlap;
    double margin = 5;
    boolean isLoaded;
    public double IconSize;
    public double IconGap;
    public boolean IsMarginLess;

    protected String getIcon() {
        /* virtual */ return null;
    }

    protected String getTip() {
        /* virtual */ return null;
    }

    public ViewContainer() {
        icon = getIcon();
        toolTip = getTip();
        navPosition = NavPosition.BottomRightVertical;
        overlap = NavOverlap.None;

        // IconSize = 14;
        // IconGap = 10;
        containers = new StackPane();
        addNavBar(navPosition);
        setCenter(containers);
        initializeAnimations();
        addClicp();
    }

    public ViewContainer(NavPosition navPosition, NavOverlap overlap) {
        icon = getIcon();
        toolTip = getTip();
        this.navPosition = navPosition;
        this.overlap = overlap;

        containers = new StackPane();
        addNavBar(navPosition);
        setCenter(containers);
        initializeAnimations();
        addClicp();
        setPickOnBounds(false);
    }

    public void addView(View view) {
        var button = new ActionButton(view.icon, 16, view.toolTip);
        button.setOnMouseClicked(this::setView);

        switch (navPosition) {
            case TopLeftHorizontal:
            case TopRightHorizontal:
            case TopCenter:
            case BottomRightHorizontal:
            case BottomLeftHorizontal:
            case BottomCenter:
                navbar.add(button, navbar.getColumnCount(), 0);
                break;
            default:
                navbar.add(button, 0, navbar.getRowCount());
                break;
        }
        containers.getChildren().add(view);
        if (!view.isContainer())
            StackPane.setMargin(view, new Insets(5));
        if (containers.getChildren().size() == 1) {
            button.setActive(true);
        }
        else {
            view.setVisible(false);
        }
    }

    void initializeAnimations() {
        getIn = new TranslateTransition(Duration.seconds(1));
        getOut = new TranslateTransition(Duration.seconds(1));
        getIn.setInterpolator(Interpolator.EASE_BOTH);
        getOut.setInterpolator(Interpolator.EASE_BOTH);
    }

    void setView(MouseEvent e) {
        if (getIn.getStatus() == Animation.Status.RUNNING)
            return;

        var index = navbar.getChildren().indexOf(e.getSource());
        if (index == currentIndex)
            return;

        var in = containers.getChildren().get(index);
        var out = containers.getChildren().get(currentIndex);

        switch (navPosition) {
            case TopRightVertical:
            case BottomRightVertical:
            case RightCenter:
            case TopLeftVertical:
            case BottomLeftVertical:
            case LeftCenter:
                double height = getHeight();
                if (index > currentIndex) {
                    in.translateYProperty().set(height);
                    getIn.setByY(-height);
                    getOut.setByY(-height);
                }
                else {
                    in.translateYProperty().set(-height);
                    getIn.setByY(height);
                    getOut.setByY(height);
                }
                break;

            default:
                double width = getWidth();
                if (index > currentIndex) {
                    in.translateXProperty().set(width);
                    getIn.setByX(-width);
                    getOut.setByX(-width);
                }
                else {
                    in.translateXProperty().set(-width);
                    getIn.setByX(width);
                    getOut.setByX(width);
                }
                break;
        }

        in.setVisible(true);
        getIn.setNode(in);
        getOut.setNode(out);
        getIn.play();
        getOut.play();

        var deactivate = (ActionButton) navbar.getChildren().get(currentIndex);
        var activate = (ActionButton) navbar.getChildren().get(index);

        getIn.setOnFinished(event -> {
            deactivate.setActive(false);
            activate.setActive(true);
            out.setVisible(false);
            currentIndex = index;
            getIn.setOnFinished(null);
        });
    }

    private void addNavBar(NavPosition pos) {
        navbar = new GridPane();
        navbar.setPickOnBounds(false);
        switch (pos) {
            case TopLeftHorizontal:
            case TopRightHorizontal:
            case TopCenter:
                BorderPane.setMargin(navbar, new Insets(margin, margin, 0, margin));
                setTop(navbar);
                break;
            case BottomLeftHorizontal:
            case BottomRightHorizontal:
            case BottomCenter:
                BorderPane.setMargin(navbar, new Insets(0, margin, margin, margin));
                setBottom(navbar);
                break;
            case TopRightVertical:
            case BottomRightVertical:
            case RightCenter:
                BorderPane.setMargin(navbar, new Insets(margin, margin, margin, 0));
                setRight(navbar);
                break;
            case TopLeftVertical:
            case BottomLeftVertical:
            case LeftCenter:
                BorderPane.setMargin(navbar, new Insets(margin, 0, margin, margin));
                setLeft(navbar);
                break;
        }

        switch (pos) {
            case TopRightHorizontal:
            case BottomRightHorizontal:
                // BorderPane.setAlignment(navbar, Pos.CENTER_RIGHT);
                navbar.setAlignment(Pos.CENTER_RIGHT);
                break;

            case BottomLeftVertical:
            case BottomRightVertical:
                // BorderPane.setAlignment(navbar, Pos.BOTTOM_CENTER);
                navbar.setAlignment(Pos.BOTTOM_CENTER);
                break;
            case TopCenter:
            case BottomCenter:
            case RightCenter:
            case LeftCenter:
                // BorderPane.setAlignment(navbar, Pos.CENTER);
                navbar.setAlignment(Pos.CENTER);
                break;
        }

    }

    @Override
    protected void layoutChildren() {
        super.layoutChildren();
        if (!isLoaded) {
            if (overlap != NavOverlap.None) {
                isLoaded = true;
                double navWidth = navbar.prefWidth(-1);
                double navHeight = navbar.prefHeight(-1);
                // navbar.setMaxWidth(navWidth);
                // navbar.setMaxHeight(navHeight);
                // System.out.println("nav-width: " + navWidth + " navHeight " + navHeight);
                switch (overlap) {
                    case Right:
                        BorderPane.setMargin(navbar, new Insets(margin, -navWidth / 2, margin, 0));
                        break;
                    case Left:
                        BorderPane.setMargin(navbar, new Insets(margin, 0, margin, -navWidth / 2));
                        break;
                    case Top:
                        BorderPane.setMargin(navbar, new Insets(-navHeight / 2, margin, 0, margin));
                        break;
                    case Bottom:
                        BorderPane.setMargin(navbar, new Insets(0, margin, -navHeight / 2, margin));
                        break;
                }
            }
        }
        // TODO Auto-generated method stub

    }

    private void addClicp() {
        var clip = new Rectangle();
        containers.layoutBoundsProperty().addListener((observable, oldValue, newValue) -> {
            clip.setWidth(newValue.getWidth());
            clip.setHeight(newValue.getHeight());
        });
        containers.setClip(clip);
    }
}

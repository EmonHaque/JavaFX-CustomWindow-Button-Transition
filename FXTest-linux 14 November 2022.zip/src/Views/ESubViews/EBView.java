package Views.ESubViews;

import abstracts.View;
import helpers.Icons;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class EBView extends View {

    @Override
    protected String getIcon() {
        return Icons.BSquare;
    }

    @Override
    protected String getHeader() {
        return "EB View";
    }

    @Override
    protected String getTip() {
        return "EB View";
    }

    @Override
    protected Node getContent() {
        var label = new Label("Test");
        var box = new VBox(label);
        return box;
    }
    
}

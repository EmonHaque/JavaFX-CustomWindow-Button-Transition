package Views.ESubViews;

import abstracts.View;
import helpers.Icons;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class EAView extends View {

    @Override
    protected String getIcon() {
        return Icons.ASquare;
    }

    @Override
    protected String getHeader() {
        return "EA View";
    }

    @Override
    protected String getTip() {
        return "EA View";
    }

    @Override
    protected Node getContent() {
        var label = new Label("Test");
        var box = new VBox(label);
        return box;
    }
    
}

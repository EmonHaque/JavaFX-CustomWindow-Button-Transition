package Views;

import abstracts.View;
import abstracts.ViewContainer;
import enums.NavOverlap;
import enums.NavPosition;
import helpers.Icons;
import javafx.scene.Node;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;

public class FView extends View {

    @Override
    protected String getIcon() {
        return Icons.FCircle;
    }
    @Override
    public boolean isContainer() {
        return true;
    }

    @Override
    protected Node getContent() {
        var container1 = new ViewContainer(NavPosition.TopRightVertical, NavOverlap.Right);
        var container2 = new ViewContainer(NavPosition.BottomLeftVertical, NavOverlap.Left);

        // var container1 = new ViewContainer(NavPosition.BottomLeftHorizontal, NavOverlap.Bottom);
        // var container2 = new ViewContainer(NavPosition.TopRightHorizontal, NavOverlap.Top);

        container1.addView(new BView());
        container1.addView(new CView());

        container2.addView(new CView());
        container2.addView(new DView());

        var grid = new GridPane();

        var colCon = new ColumnConstraints();
        colCon.setPercentWidth(50);
        grid.getColumnConstraints().add(colCon);
        grid.getColumnConstraints().add(colCon);
        grid.addColumn(0, container1);
        grid.addColumn(1, container2);
        // grid.addColumn(1, container2);
        // grid.addColumn(0, container1);
        GridPane.setVgrow(container1, Priority.ALWAYS);

        // var rowCon = new RowConstraints();
        // rowCon.setPercentHeight(50);
        // grid.getRowConstraints().add(rowCon);
        // grid.getRowConstraints().add(rowCon);
        // grid.addRow(0, container1);
        // grid.addRow(1, container2);
        
        return grid;
    }
    
}

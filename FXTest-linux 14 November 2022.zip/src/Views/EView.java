package Views;

import Views.ESubViews.EAView;
import Views.ESubViews.EBView;
import Views.ESubViews.ECView;
import abstracts.ViewContainer;
import enums.NavOverlap;
import enums.NavPosition;
import helpers.Icons;

public class EView extends ViewContainer {

    public EView() {
        // /super(NavPosition.LeftCenter, NavOverlap.None);
        addView(new EAView());
        addView(new EBView());
        addView(new ECView());
    }
    @Override
    protected String getIcon() {
        return Icons.ECircle;
    }

    @Override
    protected String getTip() {
        return "E View";
    }
    
}

package Views;

import abstracts.View;
import controls.*;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import model.ColumnSeries;
import model.Person;
import model.PieSeries;
import model.PinSeries;
import templates.PersonTemplate;
import templates.PersonVisual;
import viewModels.AViewModel;

import java.util.ArrayList;
import java.util.List;

public class AView extends View {
    AViewModel vm;
    PersonTemplate temp;

    @Override
    protected String getIcon() {
        return Icons.ACircle;
    }

    @Override
    protected String getHeader() {
        return "A View";
    }

    @Override
    protected String getTip() {
        return "A View";
    }

    @Override
    protected Node getContent() {
        vm = new AViewModel();
        var box = new VBox();
        box.setAlignment(Pos.CENTER);
        box.setSpacing(5);
        var label = new Label("Content of A View");
        label.setFont(Font.font(24));
        var button = new ActionButton(Icons.Add, 16, "Execute");
        button.setAction(vm::setText);
        var boundLabel = new Label("Test");
        var boundTextBox1 = new TextBox("Name", Icons.User);
        var boundTextBox2 = new TextBox("Password", Icons.Password);

        boundLabel.textProperty().bind(vm.labelTextProperty);
        // Binding Mode OneWayToSource
        vm.box1TextProperty.bind(boundTextBox1.textProperty);
        // Binding Mode TwoWay
        // vm.box2TextProperty.bindBidirectional(boundTextBox2.textProperty());
        boundTextBox2.textProperty.bindBidirectional(vm.box2TextProperty);

        var combo = new SelectionBox<Person>("Person", Icons.Tenant, vm.people, new PersonVisual());
        combo.getView().setCellFactory(v -> new PersonTemplate(combo.query));
        vm.query.bind(combo.query);
        vm.selectedPerson.bind(combo.selectedItem);

        var monthPicker = new MonthPicker("Pick a month");
        var dayPicker = new DayPicker();

        dayPicker.startDate.bind(Bindings.select(vm, "startDate"));
        dayPicker.endDate.bind(Bindings.select(vm, "endDate"));
        dayPicker.selectedDate.bindBidirectional(vm.selectedDate);

        List<PieSeries> pieSeries = new ArrayList<>();
        pieSeries.add(new PieSeries("A Title", 100));
        pieSeries.add(new PieSeries("B Title", 70));
        pieSeries.add(new PieSeries("C Title", 50));
        pieSeries.add(new PieSeries("D Title", 120));
        pieSeries.add(new PieSeries("E Title", 20));
        var pie = new Pie(pieSeries);

        List<ColumnSeries> columnSeries = List.of(
                new ColumnSeries("A Title", List.of(100d, 200d)),
                new ColumnSeries("B Title", List.of(50d, 100d)),
                new ColumnSeries("C Title", List.of(200d, 30d)),
                new ColumnSeries("D Title", List.of(300d, 0d)),
                new ColumnSeries("E Title", List.of(70d, 30d)));
        var column = new Columns(columnSeries);

        List<PinSeries> pinSeries = List.of(
                new PinSeries("A Title", List.of(100d, 200d), 100),
                new PinSeries("B Title", List.of(50d, 100d), 280),
                new PinSeries("C Title", List.of(200d, 30d), 200),
                new PinSeries("D Title", List.of(300d, 0d), 150),
                new PinSeries("E Title", List.of(70d, 30d), 50));

        var pinLine = new Lines(pinSeries, "Pin Value", "Line Value");

        var charts = new GridPane();
        var column1 = new ColumnConstraints();
        var column2 = new ColumnConstraints();
        var column3 = new ColumnConstraints();
        column1.setPercentWidth(33);
        column2.setPercentWidth(33);
        column3.setPercentWidth(33);
        charts.getColumnConstraints().addAll(column1, column2, column3);

        GridPane.setConstraints(pie, 0, 0);
        GridPane.setConstraints(column, 1, 0);
        GridPane.setConstraints(pinLine, 2, 0);

        GridPane.setVgrow(pie, Priority.ALWAYS);
        GridPane.setVgrow(column, Priority.ALWAYS);
        GridPane.setVgrow(pinLine, Priority.ALWAYS);

        charts.setHgap(5);
        charts.getChildren().addAll(pie, column, pinLine);

        VBox.setVgrow(charts, Priority.ALWAYS);
        box.getChildren().addAll(label, button, boundLabel, boundTextBox1, boundTextBox2, combo, monthPicker, dayPicker, charts);
        return box;
    }

}

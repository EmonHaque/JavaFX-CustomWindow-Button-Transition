package model;

public class TreeSeries {
    private String house;
    private String tenant;
    private String space;
    private int rent;
    private int due;

    public TreeSeries(String house, String tenant, String space, int rent, int due) {
        this.house = house;
        this.tenant = tenant;
        this.space = space;
        this.rent = rent;
        this.due = due;
    }
    public String getHouse(){
        return house;
    }
    public String getTenant(){
        return tenant;
    }
    public String getSpace(){
        return space;
    }
    public void setSpace(String value){
        this.space = value;
    }
    public int getDue(){
        return due;
    }
    public void setDue(int due){
        this.due = due;
    }
    public int getRent(){
        return rent;
    }
    public void setRent(int rent){
        this.rent = rent;
    }
}

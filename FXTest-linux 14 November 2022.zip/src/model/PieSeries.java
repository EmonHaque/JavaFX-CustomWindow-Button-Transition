package model;

public class PieSeries {
    public String title;
    public double value;

    public PieSeries(String title, double value) {
        this.title = title;
        this.value = value;
    }
}

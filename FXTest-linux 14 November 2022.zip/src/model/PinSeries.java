package model;
import java.util.List;

public class PinSeries {
    List<Double> pinValues;
    String name;
    double lineValue;

    public PinSeries(String name, List<Double> pinValues, double lineValue) {
        this.pinValues = pinValues;
        this.name = name;
        this.lineValue = lineValue;
    }
    public double getLineValue() { return lineValue;}
    public List<Double> getPinValues() {
        return pinValues;
    }
    public String getName() {
        return name;
    }
}

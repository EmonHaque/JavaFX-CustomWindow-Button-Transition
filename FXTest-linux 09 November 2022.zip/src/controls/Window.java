package controls;

import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Window extends BorderPane {
    double radius = 5.0;
    Stage stage;
    HBox titleBar;
    
    public Window(Stage stage){
        this.stage = stage;
        setBackground(new Background(new BackgroundFill(Color.rgb(90, 90, 90), new CornerRadii(radius, false), null)));
        setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(radius, false), new BorderWidths(0.5))));
        //addTitleBar();
        //var bounds = Screen.getPrimary().getBounds();
        //var scene = new Scene(this, bounds.getWidth(),bounds.getHeight());
        var scene = new Scene(this, 800,600);
        scene.setFill(Color.TRANSPARENT);
        stage.setScene(scene);
        stage.initStyle(StageStyle.TRANSPARENT);
        stage.getIcons().add(new Image("images/icon.jpg"));
        stage.setTitle("JavaFX");
        //stage.getIcons().add(new Image(getClass().getResourceAsStream("images/icon.jpg")));
    }
    
    public void setContent(Parent node){
        setCenter(node);
    }
    public void show(){
        stage.show();
    }
}

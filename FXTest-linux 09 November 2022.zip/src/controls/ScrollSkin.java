package controls;

import helpers.Icons;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Point2D;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.skin.ScrollBarSkin;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.SVGPath;

public class ScrollSkin extends ScrollBarSkin {
    SVGPath arrowDec, arrowInc;
    StackPane thumb,track;
    Region incButton,  decButton, incArrow, decArrow;

    public ScrollSkin(ScrollBar control) {
        super(control);
        control.setBackground(null);
        thumb = (StackPane) control.lookup(".thumb");
        track = (StackPane) control.lookup(".track");
        incButton = (Region) control.lookup(".increment-button");
        decButton = (Region) control.lookup(".decrement-button");
        incArrow = (Region) control.lookup(".increment-arrow");
        decArrow = (Region) control.lookup(".decrement-arrow");
        incArrow.setBackground(null);
        decArrow.setBackground(null);

        arrowDec = new SVGPath();
        arrowInc = new SVGPath();
        incButton.setShape(arrowInc);
        decButton.setShape(arrowDec);
    
        if(control.getOrientation() == Orientation.VERTICAL){
            arrowDec.setContent(Icons.ScrollUp);
            arrowInc.setContent(Icons.ScrollDown);
            control.setMinWidth(10);
            control.setMaxWidth(10);
            control.setPrefWidth(10);
        }
        else{
            arrowDec.setContent(Icons.ScrollLeft);
            arrowInc.setContent(Icons.ScrollRight);
            control.setMinHeight(10);
            control.setMaxHeight(10);
            control.setPrefHeight(10);
        }
        incButton.setBackground(new Background(new BackgroundFill(Color.WHITE, null,null)));
        decButton.setBackground(new Background(new BackgroundFill(Color.WHITE, null,null)));
        thumb.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, new CornerRadii(10), new Insets(2.5))));

        thumb.addEventHandler(MouseEvent.ANY, this::thumbHandler);
        incButton.addEventHandler(MouseEvent.ANY, this::buttonHandler);
        decButton.addEventHandler(MouseEvent.ANY, this::buttonHandler);
    }

    void buttonHandler(MouseEvent e){
        var source = (Region)e.getSource();
        if(e.getEventType() == MouseEvent.MOUSE_ENTERED)
            source.setBackground(new Background(new BackgroundFill(Color.CORAL, null, null)));
        else if(e.getEventType() == MouseEvent.MOUSE_PRESSED)
            source.setBackground(new Background(new BackgroundFill(Color.RED, null, null)));
        else if(e.getEventType() == MouseEvent.MOUSE_RELEASED){
            if(source.contains(new Point2D(e.getX(), e.getY())))
                source.setBackground(new Background(new BackgroundFill(Color.CORAL, null, null)));
        }
        else if(e.getEventType() == MouseEvent.MOUSE_EXITED)
            source.setBackground(new Background(new BackgroundFill(Color.WHITE, null, null)));
    }
    void thumbHandler(MouseEvent e){
        if(e.getEventType() == MouseEvent.MOUSE_ENTERED)
            thumb.setBackground(new Background(new BackgroundFill(Color.GRAY, new CornerRadii(10), new Insets(2.5))));
        else if(e.getEventType() == MouseEvent.MOUSE_PRESSED)
            thumb.setBackground(new Background(new BackgroundFill(Color.BLACK, new CornerRadii(10), new Insets(2.5))));
        else if(e.getEventType() == MouseEvent.MOUSE_RELEASED){
            if(thumb.contains(new Point2D(e.getX(), e.getY())))
                thumb.setBackground(new Background(new BackgroundFill(Color.GRAY, new CornerRadii(10), new Insets(2.5))));
        }
        else if(e.getEventType() == MouseEvent.MOUSE_EXITED)
            thumb.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, new CornerRadii(10), new Insets(2.5))));
    }
}

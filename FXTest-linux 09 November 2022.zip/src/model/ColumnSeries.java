package model;
import java.util.List;

public class ColumnSeries {
    List<Double> values;
    String name;

    public ColumnSeries(String name, List<Double> values) {
        this.values = values;
        this.name = name;
    }
    public List<Double> getValues() {
        return values;
    }
    public String getName() {
        return name;
    }
}

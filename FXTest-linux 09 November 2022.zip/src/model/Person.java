package model;

public class Person {
    public String name;
    public String phone;
}

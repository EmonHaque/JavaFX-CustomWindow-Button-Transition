package abstracts;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public abstract class View {
    String header;
    public String icon;
    public String toolTip;
    public StackPane headerPane;
    public BorderPane visual;

    public View(){
        icon = getIcon();
        header = getHeader();
        toolTip = getTip();
        visual = new BorderPane();
        headerPane = new StackPane();
        visual.setPadding(new Insets(10));

        var text = new Text(header);
        text.setFont(Font.font(Font.getDefault().getFamily(), FontWeight.BOLD, 14));
        text.setFill(Color.DARKGRAY);
        StackPane.setAlignment(text, Pos.CENTER_LEFT);
        headerPane.getChildren().add(text);
        headerPane.setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0,0,0.25,0))));
        visual.setTop(headerPane);
        visual.setCenter(getContent());
    
        visual.setBackground(new Background(new BackgroundFill(Color.rgb(50, 50, 50), new CornerRadii(5, false), null)));
    }
    protected abstract String getIcon();
    protected abstract String getHeader();
    protected abstract String getTip();
    protected abstract Node getContent();
}

package Views;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import abstracts.View;
import controls.ExtendedTreeView;
import helpers.Icons;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import model.TreeSeries;
import templates.TenantTemplate;

public class DView extends View {

    @Override
    protected String getIcon() {
        return Icons.Ledger;
    }

    @Override
    protected String getHeader() {
        return "Tree view";
    }

    @Override
    protected String getTip() {
        return "TreeView";
    }

    @Override
    protected Node getContent() {
        var box = new VBox();
        box.setAlignment(Pos.CENTER);
        var label = new Label("Content of D View");
        box.getChildren().add(label);

        List<TreeSeries> series = Arrays.<TreeSeries>asList(
                new TreeSeries("House 1", "Tenant 1", "Space 1", 5000, 5000),
                new TreeSeries("House 1", "Tenant 1", "Space 2", 1000, 2000),
                new TreeSeries("House 1", "Tenant 2", "Space 3", 1000, 2000),
                new TreeSeries("House 1", "Tenant 2", "Space 4", 1000, 2000),
                new TreeSeries("House 1", "Tenant 3", "Space 5", 1000, 2000),
                new TreeSeries("House 2", "Tenant 1", "Space 1", 1000, 2000),
                new TreeSeries("House 2", "Tenant 1", "Space 2", 1000, 2000),
                new TreeSeries("House 2", "Tenant 2", "Space 3", 1000, 2000),
                new TreeSeries("House 2", "Tenant 2", "Space 4", 1000, 2000),
                new TreeSeries("House 2", "Tenant 3", "Space 5", 1000, 2000),
                new TreeSeries("House 3", "Tenant 1", "Space 1", 1000, 2000),
                new TreeSeries("House 3", "Tenant 1", "Space 2", 1000, 2000),
                new TreeSeries("House 3", "Tenant 2", "Space 3", 1000, 2000),
                new TreeSeries("House 3", "Tenant 2", "Space 4", 1000, 2000),
                new TreeSeries("House 3", "Tenant 3", "Space 5", 1000, 2000),
                new TreeSeries("House 4", "Tenant 1", "Space 1", 1000, 2000),
                new TreeSeries("House 4", "Tenant 1", "Space 2", 1000, 2000),
                new TreeSeries("House 4", "Tenant 2", "Space 3", 1000, 2000),
                new TreeSeries("House 4", "Tenant 2", "Space 4", 1000, 2000),
                new TreeSeries("House 4", "Tenant 3", "Space 5", 1000, 2000),
                new TreeSeries("House 5", "Tenant 1", "Space 1", 1000, 2000),
                new TreeSeries("House 5", "Tenant 1", "Space 2", 1000, 2000),
                new TreeSeries("House 5", "Tenant 2", "Space 3", 1000, 2000),
                new TreeSeries("House 5", "Tenant 2", "Space 4", 1000, 2000),
                new TreeSeries("House 5", "Tenant 3", "Space 5", 1000, 2000));

        var maps = new HashMap<String, Map<String, List<TreeSeries>>>();

        for (TreeSeries house : series) {
            if (maps.containsKey(house.getHouse())) {
                var tenants = maps.get(house.getHouse());
                boolean isFound = false;
                for (var tenant : tenants.keySet()) {
                    if (house.getTenant().equals(tenant)) {
                        tenants.get(tenant).add(house);
                        isFound = true;
                        break;
                    }
                }
                if (!isFound) {
                    var list = new ArrayList<TreeSeries>();
                    list.add(house);
                    tenants.put(house.getTenant(), list);
                }
            } else {
                var subMap = new HashMap<String, List<TreeSeries>>();
                var list = new ArrayList<TreeSeries>();
                list.add(house);
                subMap.put(house.getTenant(), list);
                maps.put(house.getHouse(), subMap);
            }
        }

        var tree = new ExtendedTreeView<TreeSeries>();

        tree.setBackground(null);
        var root = new TreeItem<TreeSeries>(new TreeSeries("Root", "", "", 0, 0));
        maps.forEach((x, y) -> {
            var houseSeries = new TreeSeries(x, "", "", 0, 0);
            var house = new TreeItem<>(houseSeries);
            y.forEach((w, v) -> {
                var tenantSeries = new TreeSeries("", w, "", 0, 0);
                var tenant = new TreeItem<>(tenantSeries);
                if(v.size() == 1){
                    var s = v.get(0);
                    tenantSeries.setSpace(s.getSpace());
                    tenantSeries.setDue(s.getDue());
                    tenantSeries.setRent(s.getRent());
                }
                else{
                    v.forEach(u -> {
                        var space = new TreeItem<>(new TreeSeries("", "", u.getSpace(), u.getRent(), u.getDue()));
                        int rent = tenantSeries.getRent() + u.getRent();
                        int due = tenantSeries.getDue() + u.getDue();
                        tenantSeries.setRent(rent);
                        tenantSeries.setDue(due);
                        tenant.getChildren().add(space);
                    });
                }
                int rent = houseSeries.getRent() + tenantSeries.getRent();
                int due = houseSeries.getDue() + tenantSeries.getDue();
                houseSeries.setRent(rent);
                houseSeries.setDue(due);
                house.getChildren().add(tenant);
            });
            root.getChildren().add(house);
        });

        tree.setRoot(root);
        tree.setShowRoot(false);
        tree.setCellFactory(v -> new TenantTemplate());
        
        VBox.setVgrow(tree, Priority.ALWAYS);
        box.getChildren().addAll(tree);
        return box;
    }

}

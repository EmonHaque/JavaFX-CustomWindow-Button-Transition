package templates;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.paint.Color;
import model.Person;

public class PersonTemplate extends ListCell<Person> {
    public StringProperty query;
    PersonVisual visual;

    public PersonTemplate(StringProperty q) {
        query = new SimpleStringProperty();
        query.bind(q);
        hoverProperty().addListener((obs, wasHovered, isNowHovered) -> {
            if (isNowHovered && !isEmpty()) {
                if(!isSelected())
                    setBackground(new Background(new BackgroundFill(Color.rgb(60, 60, 60), null, null)));
            } else {
                if(!isSelected())
                    setBackground(null);
            }
        });
    }

    @Override
    protected void updateItem(Person item, boolean empty) {
        super.updateItem(item, empty);
        setText(null);
        if (item == null || empty) {
            setGraphic(null);
            setBackground(null);
        }
        else {
            setPrefWidth(0);
            visual = new PersonVisual();
            visual.setContent(item);
            visual.getHiText().query.bind(query);
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            setGraphic(visual);
            if (isSelected()) {
                setBackground(new Background(new BackgroundFill(Color.rgb(60, 60, 60), null, null)));
            } 
            else setBackground(null);
        }
    }
    
}

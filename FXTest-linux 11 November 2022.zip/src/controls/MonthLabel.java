package controls;
import helpers.Constants;
import javafx.animation.FillTransition;
import javafx.animation.ParallelTransition;
import javafx.geometry.Pos;
import javafx.scene.effect.DropShadow;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class MonthLabel extends StackPane {
    int monthNo;
    Text monthText;
    Circle circle;
    FillTransition monthAnim, circleAnim;
    ParallelTransition transitAnim;
    DropShadow effect;
    boolean isSelected;
    public MonthLabel(String text) {
        setMonthNo(text);
        monthText = new Text(text);
        monthText.setFill(Color.WHITE);
        circle = new Circle();
        circle.setRadius(30);
        circle.setFill(Constants.BackgroundColorLight);
        effect = new DropShadow();
        monthAnim = new FillTransition(Duration.millis(500));
        circleAnim = new FillTransition(Duration.millis(500));
        monthAnim.setShape(monthText);
        circleAnim.setShape(circle);
        transitAnim = new ParallelTransition(circleAnim, monthAnim);
        getChildren().addAll(circle, monthText);
        setAlignment(Pos.CENTER);
        addEventHandler(MouseEvent.ANY, this::handleMouse);
    }
    void setMonthNo(String text){
        switch (text){
            case "Jan" -> monthNo = 1;
            case "Feb" -> monthNo = 2;
            case "Mar" -> monthNo = 3;
            case "Apr" -> monthNo = 4;
            case "May" -> monthNo = 5;
            case "Jun" -> monthNo = 6;
            case "Jul" -> monthNo = 7;
            case "Aug" -> monthNo = 8;
            case "Sep" -> monthNo = 9;
            case "Oct" -> monthNo = 10;
            case "Nov" -> monthNo = 11;
            case "Dec" -> monthNo = 12;
        }
    }
    void handleMouse(MouseEvent e){
        if(isSelected) return;
        if(e.getEventType() == MouseEvent.MOUSE_ENTERED){
            transitAnim.stop();
            circleAnim.setToValue(Constants.BackgroundColor);
            monthAnim.setToValue(Color.WHEAT);
            transitAnim.play();
            setEffect(effect);
        }
        else if(e.getEventType() == MouseEvent.MOUSE_EXITED){
            transitAnim.stop();
            circleAnim.setToValue(Constants.BackgroundColorLight);
            monthAnim.setToValue(Color.WHITE);
            transitAnim.play();
            setEffect(null);
        }
    }
    void setSelected(boolean value){
        isSelected = value;
        if(isSelected){
            circle.setFill(Color.CORNFLOWERBLUE);
            monthText.setFill(Color.WHITE);
            setEffect(effect);
        }
        else{
            circle.setFill(Color.LIGHTBLUE);
            monthText.setFill(Color.BLACK);
            setEffect(null);
        }
    }
}

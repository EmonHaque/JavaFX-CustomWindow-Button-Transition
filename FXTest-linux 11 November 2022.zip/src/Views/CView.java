package Views;
import abstracts.View;
import controls.ExtendedListView;
import helpers.Icons;
import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import templates.PersonTemplate;
import viewModels.AViewModel;

public class CView extends View {
    @Override
    protected String getIcon() {
        return Icons.Edit;
    }

    @Override
    protected String getHeader() {
        return "C View";
    }

    @Override
    protected String getTip() {
        return "C View";
    }

    @Override
    protected Node getContent() {
        var box = new VBox();
        box.setAlignment(Pos.CENTER);
        var label = new Label("Content of C View");

        var vm = new AViewModel();
        var list = new ExtendedListView<>(vm.people);
        list.setCellFactory(v -> new PersonTemplate(new SimpleStringProperty()) );
        VBox.setVgrow(list, Priority.ALWAYS);
        box.getChildren().addAll(label, list);

        return box;
    }
}

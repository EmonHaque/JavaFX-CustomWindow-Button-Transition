package skins;

import controls.ExtendedVirtualFlow;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeView;
import javafx.scene.control.skin.TreeViewSkin;
import javafx.scene.control.skin.VirtualFlow;

public class ExtendedTreeViewSkin<T> extends TreeViewSkin<T>{

    public ExtendedTreeViewSkin(TreeView<T> control) {
        super(control);
    }

    @Override
    protected VirtualFlow<TreeCell<T>> createVirtualFlow() {
        return new ExtendedVirtualFlow<>();
    }
    
}

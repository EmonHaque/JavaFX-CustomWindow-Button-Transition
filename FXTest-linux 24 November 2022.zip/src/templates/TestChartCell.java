package templates;

import controls.HiText;
import controls.HorizontalListChart;
import helpers.Constants;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Separator;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import model.HorizontalSeries;

public class TestChartCell extends StackPane {
    //private Text text;
    private HiText text;
    private Rectangle value1, value2;
    private HorizontalSeries item;
    private double percentOfChartArea, topBottomPadding, topMax;

    private Popup pop;
    private VBox content;

    private HorizontalListChart chart;

    public TestChartCell(HorizontalSeries item, double percentOfChartArea, double topBottomPadding, double topMax) {
        this.item = item;
        this.percentOfChartArea = percentOfChartArea;
        this.topBottomPadding = topBottomPadding;
        this.topMax = topMax;

        text = new HiText();
        
        value1 = new Rectangle();
        value2 = new Rectangle();

        text.setContent(item.getTitle());
        //text.setFill(Color.WHITE);
        value1.setFill(Color.GRAY);
        value2.setFill(Color.GREEN);

        text.setManaged(false);
        value1.setManaged(false);
        value2.setManaged(false);

        //text.setMouseTransparent(true);
        value1.setMouseTransparent(true);
        value2.setMouseTransparent(true);

        getChildren().addAll(text, value1, value2);

        content = new VBox(new Text(item.getTitle()), new Separator());
        content.setPadding(new Insets(10));
        content.setAlignment(Pos.CENTER);
        content.setBackground(new Background(new BackgroundFill(Color.CORAL, new CornerRadii(10), null)));
        content.getChildren().add(new Text("Value 1 is " + String.format("%.1f", item.getValue1())));
        content.getChildren().add(new Text("Value 2 is " + String.format("%.1f", item.getValue2())));
        pop = new Popup();
        pop.getContent().add(content);

        setOnMouseEntered(this::onMouseEntered);
        setOnMouseExited(this::onMouseExited);
    }

    void onMouseEntered(MouseEvent e) {
        var point = localToScreen(e.getX(), e.getY());
        var x = point.getX() - content.prefWidth(-1) / 2;
        var y = point.getY() - content.prefHeight(-1) - 15;
        pop.show(this, x, y);

        setBackground(new Background(new BackgroundFill(Constants.BackgroundColorLight, null, null)));
    }

    void onMouseExited(MouseEvent e) {
        pop.hide();
        setBackground(null);
    }

    @Override
    protected void layoutChildren() {
        if(chart == null){
            chart = (HorizontalListChart) (getParent().getParent().getParent().getParent().getParent().getParent());
            text.query.bind(chart.queryProperty);
        }
        double width = getWidth();
        double height = getHeight();

        double startX = width * (1 - percentOfChartArea);

        var chartArea = width - startX;
        double total = item.getValue1() + item.getValue2();       
        var totalWidth = chartArea / topMax * total;
        var value1Width = item.getValue1() / total * totalWidth;
        var value2Width = item.getValue2() / total * totalWidth;        
        
        //text.setWrappingWidth(startX);
        //text.setY(15 + topBottomPadding);

        text.setPrefWidth(startX);
        text.setMinWidth(startX);
        text.setMaxWidth(startX);
        
        value1.setY(topBottomPadding);
        value2.setY(topBottomPadding);

        value1.setX(startX);
        value1.setHeight(height - 2 * topBottomPadding);
        value1.setWidth(value1Width);

        value2.setX(startX + value1.getWidth());
        value2.setHeight(height - 2 * topBottomPadding);
        value2.setWidth(value2Width);
    }
}

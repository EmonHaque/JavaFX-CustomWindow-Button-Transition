package controls;

import helpers.Constants;
import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.TranslateTransition;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.util.Duration;
import skinned.ExtendedTextField;

public class TextBox extends GridPane {
    SVGIcon svgIcon;
    Label hintLabel;
    ExtendedTextField input;
    TranslateTransition moveHint;
    boolean isHintMoved;
    public StringProperty textProperty;

    public TextBox(String hint, String icon) {
        hintLabel = new Label(hint);
        svgIcon = new SVGIcon(icon);
        input = new ExtendedTextField();

        hintLabel.setTextFill(Color.GRAY);
        svgIcon.setFill(Color.LIGHTBLUE);

        svgIcon.setMouseTransparent(true);
        hintLabel.setMouseTransparent(true);
        input.setMouseTransparent(true);

        addRow(0, svgIcon, input);
        add(hintLabel, 1, 0);
        setAlignment(Pos.BOTTOM_LEFT);
        setHgrow(input, Priority.ALWAYS);
        setMargin(hintLabel, new Insets(0, 0, 0, 5));
        setBorder(Constants.BottomLine);

        moveHint = new TranslateTransition(Duration.millis(100));
        moveHint.setInterpolator(Interpolator.EASE_IN);
        moveHint.setNode(hintLabel);
        setMinHeight(40);
        textProperty = input.textProperty();

        addEventHandler(MouseEvent.ANY, this::onMouseEvents);
        input.focusedProperty().addListener(this::onFocusChanged);
        input.textProperty().addListener(this::onTextChanged);
    }

    void onMouseEvents(MouseEvent e) {
        if (e.getEventType() == MouseEvent.MOUSE_ENTERED) {
            input.requestFocus();
            input.selectEnd();
        }
        else if (e.getEventType() == MouseEvent.MOUSE_EXITED) {
            svgIcon.requestFocus();
        }
    }

    void onTextChanged(ObservableValue<? extends String> observable, String oldValue, String newValue) {
        if (textIsNullOrEmpty(newValue)) {
            if (isHintMoved && !input.isFocused()) {
                moveHintDown();
            }
        }
        else {
            if (!isHintMoved) {
                moveHintUp();
            }
        }
    }

    void onFocusChanged(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
        if (newValue) {
            setFocusColor();
            if (!isHintMoved)
                moveHintUp();
        }
        else {
            resetFocusColor();
            if (textIsNullOrEmpty(input.getText())) {
                if (isHintMoved)
                    moveHintDown();
            }
        }
    }

    boolean textIsNullOrEmpty(String text) {
        return text == null || text.isEmpty() || text.isBlank();
    }

    void moveHintUp() {
        if (moveHint.getStatus() == Animation.Status.RUNNING) {
            moveHint.stop();
        }
        var x = Constants.hintShiftX + hintLabel.getTranslateX();
        var y = Constants.hintShiftY + hintLabel.getTranslateY();
        moveHint.setByY(-y);
        moveHint.setByX(-x);
        moveHint.play();
        isHintMoved = true;
    }

    void moveHintDown() {
        if (moveHint.getStatus() == Animation.Status.RUNNING) {
            moveHint.stop();
        }
        moveHint.setByY(-hintLabel.getTranslateY());
        moveHint.setByX(-hintLabel.getTranslateX());
        moveHint.play();
        isHintMoved = false;
    }

    void setFocusColor() {
        svgIcon.setFill(Color.CORNFLOWERBLUE);
        setBorder(Constants.BottomLineHighlight);
    }

    void resetFocusColor() {
        svgIcon.setFill(Color.LIGHTBLUE);
        setBorder(Constants.BottomLine);
    }

    public String getText() {
        return input.getText();
    }

    public void setText(String value) {
        input.setText(value);
    }
}

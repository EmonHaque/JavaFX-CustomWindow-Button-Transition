package controls.daymonth;

import helpers.Constants;

import javafx.animation.FillTransition;
import javafx.animation.ParallelTransition;
import javafx.geometry.Pos;
import javafx.scene.effect.DropShadow;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class YearLabel extends StackPane {
    int year;
    Text yearText;
    Circle circle;
    FillTransition yearAnim, circleAnim;
    ParallelTransition transitAnim;
    DropShadow effect;
    boolean isSelected, isThisYear;
    
    public YearLabel(int year) {
       this.year = year;
       yearText = new Text(String.valueOf(year));
       yearText.setFill(Color.WHITE);
        circle = new Circle();
        circle.setRadius(25);
        circle.setFill(Constants.BackgroundColorLight);
        effect = new DropShadow();
        yearAnim = new FillTransition(Duration.millis(500));
        circleAnim = new FillTransition(Duration.millis(500));
        yearAnim.setShape(yearText);
        circleAnim.setShape(circle);
        transitAnim = new ParallelTransition(circleAnim, yearAnim);
        getChildren().addAll(circle, yearText);
        setAlignment(Pos.CENTER);
        addEventHandler(MouseEvent.ANY, this::handleMouse);
    }
    void handleMouse(MouseEvent e){
        if(isSelected || isThisYear) return;
        if(e.getEventType() == MouseEvent.MOUSE_ENTERED){
            transitAnim.stop();
            circleAnim.setToValue(Constants.BackgroundColor);
            yearAnim.setToValue(Color.WHEAT);
            transitAnim.play();
            setEffect(effect);
        }
        else if(e.getEventType() == MouseEvent.MOUSE_EXITED){
            transitAnim.stop();
            circleAnim.setToValue(Constants.BackgroundColorLight);
            yearAnim.setToValue(Color.WHITE);
            transitAnim.play();
            setEffect(null);
        }
    }
    void setSelected(boolean value){
        isSelected = value;
        if(isSelected){
            circle.setFill(Color.CORNFLOWERBLUE);
            yearText.setFill(Color.BLACK);
            setEffect(effect);
        }
        else{
            circle.setFill(Constants.BackgroundColorLight);
            yearText.setFill(Color.WHITE);
            setEffect(null);
        }
    }
    public void setThisYear(boolean value){
        isThisYear = value;
        if(isSelected) return;
        if(isThisYear){
            circle.setFill(Color.CORAL);
            yearText.setFill(Color.BLACK);
            setEffect(effect);
        }
        else{
            circle.setFill(Constants.BackgroundColorLight);
            yearText.setFill(Color.WHITE);
            setEffect(null);
        }
    }
    public int getYearNo(){
        return year;
    }
}

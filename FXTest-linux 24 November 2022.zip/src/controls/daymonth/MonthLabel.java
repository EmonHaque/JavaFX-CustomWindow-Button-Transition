package controls.daymonth;
import helpers.Constants;
import javafx.animation.FillTransition;
import javafx.animation.ParallelTransition;
import javafx.geometry.Pos;
import javafx.scene.effect.DropShadow;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class MonthLabel extends StackPane {
    int month;
    Text monthText;
    Circle circle;
    FillTransition monthAnim, circleAnim;
    ParallelTransition transitAnim;
    DropShadow effect;
    boolean isSelected, isThisMonth;

    public MonthLabel(int month) {
        this.month = month;
        monthText = new Text();
        setMonthText(month);
        monthText.setFill(Color.WHITE);
        circle = new Circle();
        circle.setRadius(20);
        circle.setFill(Constants.BackgroundColorLight);
        effect = new DropShadow();
        monthAnim = new FillTransition(Duration.millis(500));
        circleAnim = new FillTransition(Duration.millis(500));
        monthAnim.setShape(monthText);
        circleAnim.setShape(circle);
        transitAnim = new ParallelTransition(circleAnim, monthAnim);
        getChildren().addAll(circle, monthText);
        setAlignment(Pos.CENTER);
        addEventHandler(MouseEvent.ANY, this::handleMouse);
    }
    void setMonthText(int month){
        switch (month){
            case 1 -> monthText.setText("Jan");
            case 2 -> monthText.setText("Feb");
            case 3 -> monthText.setText("Mar");
            case 4 -> monthText.setText("Apr");
            case 5 -> monthText.setText("May");
            case 6 -> monthText.setText("Jun");
            case 7 -> monthText.setText("Jul");
            case 8 -> monthText.setText("Aug");
            case 9 -> monthText.setText("Sep");
            case 10 -> monthText.setText("Oct");
            case 11 -> monthText.setText("Nov");
            case 12 -> monthText.setText("Dec");
        }
    }
    void handleMouse(MouseEvent e){
        if(isSelected || isThisMonth) return;
        if(e.getEventType() == MouseEvent.MOUSE_ENTERED){
            transitAnim.stop();
            circleAnim.setToValue(Constants.BackgroundColor);
            monthAnim.setToValue(Color.WHEAT);
            transitAnim.play();
            setEffect(effect);
        }
        else if(e.getEventType() == MouseEvent.MOUSE_EXITED){
            transitAnim.stop();
            circleAnim.setToValue(Constants.BackgroundColorLight);
            monthAnim.setToValue(Color.WHITE);
            transitAnim.play();
            setEffect(null);
        }
    }
    public void setSelected(boolean value){
        isSelected = value;
        if(isSelected){
            circle.setFill(Color.CORNFLOWERBLUE);
            monthText.setFill(Color.BLACK);
            setEffect(effect);
        }
        else{
            circle.setFill(Constants.BackgroundColorLight);
            monthText.setFill(Color.WHITE);
            setEffect(null);
        }
    }
    public void setThisMonth(boolean value){
        isThisMonth = value;
        if(isSelected) return;
        if(isThisMonth){
            circle.setFill(Color.CORAL);
            monthText.setFill(Color.BLACK);
            setEffect(effect);
        }
        else{
            circle.setFill(Constants.BackgroundColorLight);
            monthText.setFill(Color.WHITE);
            setEffect(null);
        }
    }
    public int getMonthNo(){
        return month;
    }
}

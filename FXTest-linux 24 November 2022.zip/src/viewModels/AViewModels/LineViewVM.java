package viewModels.AViewModels;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import model.PinSeries;

public class LineViewVM {
    private char alps[] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', '0'};
    private List<PinSeries> series;
    public ObjectProperty<List<PinSeries>> seriesProperty;

    public LineViewVM() {
        series = List.of(
            new PinSeries("A Title", List.of(100d, 200d), 100),
            new PinSeries("B Title", List.of(50d, 100d), 280),
            new PinSeries("C Title", List.of(200d, 30d), 200),
            new PinSeries("D Title", List.of(300d, 0d), 150),
            new PinSeries("E Title", List.of(200d, 100d), 50));

            seriesProperty = new SimpleObjectProperty<>(series);
        
        PieViewVM.selectedSliceProperty.addListener((o, ov, nv) ->{
            series = nv == null ? null : getSeries();
            seriesProperty.set(series);
        });
    }

    private ArrayList<PinSeries> getSeries(){
        var list = new ArrayList<PinSeries>();
        var rand = new Random();
        int size = rand.nextInt(7) + 8;
        for(int i = 0; i < size; i++){
            list.add(new PinSeries(alps[i] + " Title", List.of(rand.nextDouble(100) + 0, rand.nextDouble(100) + 0), rand.nextDouble(100) + 50));
        }
        return list;
    }
}

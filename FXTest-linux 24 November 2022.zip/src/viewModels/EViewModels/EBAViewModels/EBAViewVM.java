package viewModels.EViewModels.EBAViewModels;

import javafx.beans.property.ListProperty;
import javafx.beans.property.SimpleListProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Tenant;

public class EBAViewVM {
    private ObservableList<Tenant> tenants;
    public ListProperty<Tenant> tenantsProperty;

    public EBAViewVM() {
        tenants = FXCollections.observableArrayList();
        tenantsProperty = new SimpleListProperty<>(tenants);

        tenants.add(new Tenant("House 1", "Tenant 1", "Space 1", 1000, 2000));
        tenants.add(new Tenant("House 1", "Tenant 1", "Space 2", 1000, 2000));
        tenants.add(new Tenant("House 2", "Tenant 2", "Space 1", 1000, 2000));
        tenants.add(new Tenant("House 2", "Tenant 2", "Space 2", 1000, 2000));
        tenants.add(new Tenant("House 3", "Tenant 3", "Space 1", 1000, 2000));
        tenants.add(new Tenant("House 3", "Tenant 3", "Space 2", 1000, 2000));
    }
}

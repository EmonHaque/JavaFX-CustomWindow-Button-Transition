package viewModels.EViewModels.EAAViewModels;

import model.Tenant;

public class EAAViewVM {
    public Tenant tenant;

    public EAAViewVM() {
        tenant = new Tenant();
    }

    public void addTenant(){
        System.out.println("added: " + tenant);

        tenant.houseProperty.set(null);
        tenant.tenantProperty.set(null);
        tenant.spaceProperty.set(null);
        tenant.rentProperty.set(0);
        tenant.dueProperty.set(0);
    }
}

package viewModels.FViewModels;

import java.util.Random;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import model.HorizontalSeries;

public class FBAViewVM {
    private String titles[] = {"A Title 1 fsdfs  sdf sdf sdfsdf sdf sdfsdf", "B Title 2", "C Title 2", "D Title 2", "E Title 2"};
    private FilteredList<HorizontalSeries> filteredSeries;

    private ObservableList<HorizontalSeries> series;
    public ObjectProperty<ObservableList<HorizontalSeries>> seriesProperty;
    public StringProperty queryProperty;

    public FBAViewVM() {
        
        series = FXCollections.observableArrayList(
                new HorizontalSeries("A Title 1 fsdfs  sdf sdf sdfsdf sdf sdfsdf", 100, 200, 300),
                new HorizontalSeries("B Title 2", 100, 200, 150),
                new HorizontalSeries("C Title 3", 50, 100, 70),
                new HorizontalSeries("D Title 4", 175, 75, 55),
                new HorizontalSeries("E Title 5", 80, 90, 200));

        
        queryProperty = new SimpleStringProperty();

        filteredSeries = new FilteredList<>(series, this::filterPredicate);        
        seriesProperty = new SimpleObjectProperty<>(filteredSeries);
        queryProperty.addListener(this::onQuery);
    }

    private boolean filterPredicate(HorizontalSeries s){
        if(s == null) return true;
        if(queryProperty.get() == null || queryProperty.get().isEmpty()) return true;
        return s.getTitle().toLowerCase().contains(queryProperty.get().toLowerCase());
    }

    private void onQuery(ObservableValue<?> o, String ov, String nv){
        filteredSeries.setPredicate(this::filterPredicate);
    }

    public void generateSeries(){
        var rand = new Random();
        int size = rand.nextInt(50) + 5;
        series = FXCollections.observableArrayList();
        for(int i = 0; i < size; i++){
            
            series.add(new HorizontalSeries(titles[rand.nextInt(5)], rand.nextDouble(200) + 100,  rand.nextDouble(200) + 100, rand.nextDouble(200) + 100));
        }
        filteredSeries = new FilteredList<>(series, this::filterPredicate); 
        seriesProperty.set(filteredSeries);
    }
}

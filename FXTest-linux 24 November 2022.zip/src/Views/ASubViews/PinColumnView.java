package Views.ASubViews;

import abstracts.View;
import controls.pinchart.PinColumns;
import javafx.geometry.Insets;
import javafx.scene.layout.BorderPane;
import viewModels.AViewModels.PinColumnViewVM;

public class PinColumnView extends View {
    PinColumnViewVM vm;
    @Override
    protected String getHeader() {
        return "PinColumn View";
    }
    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight PinColumnView");

        vm = new PinColumnViewVM();
        var pinColumn = new PinColumns();
        pinColumn.seriesProperty.bind(vm.seriesProperty);

        BorderPane.setMargin(pinColumn, new Insets(10,0,0,0));
        setCenter(pinColumn);
    }
}

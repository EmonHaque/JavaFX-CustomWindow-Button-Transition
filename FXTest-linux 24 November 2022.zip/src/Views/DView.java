package Views;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import abstracts.View;
import controls.ActionButton;
import controls.TextBox;
import helpers.Icons;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.print.Printer;
import javafx.print.PrinterJob;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import model.TreeSeries;
import skinned.ExtendedTreeView;
import templates.TenantTemplate;

public class DView extends View {
    HashMap<String, Map<String, List<TreeSeries>>> maps;
    TreeItem<TreeSeries> root;
    ExtendedTreeView<TreeSeries> tree;
    Text pageNoText;
    Label countLabel;
    List<TreeSeries> series;
    TextBox queryBox;

    @Override
    protected String getIcon() {
        return Icons.DCircle;
    }

    @Override
    protected String getHeader() {
        return "D view";
    }

    @Override
    protected String getTip() {
        return "TreeView";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight DView");
        var box = new VBox();

        var hBox = new HBox();
        queryBox = new TextBox("Query", Icons.Magnify);
        countLabel = new Label();
        countLabel.setTextFill(Color.WHITE);
        var spacer = new Region();
        var button = new ActionButton(Icons.Print, 16, "Print");
        button.setAction(this::print);
        HBox.setHgrow(spacer, Priority.ALWAYS);
        hBox.getChildren().addAll(queryBox, spacer, countLabel, button);
        hBox.setAlignment(Pos.CENTER);
        HBox.setMargin(countLabel, new Insets(0, 5, 0, 0));
        box.getChildren().add(hBox);
        VBox.setMargin(hBox, new Insets(5, 0, 2.5, 0));

        series = new ArrayList<>();
        for (int i = 0; i < 50; i++) {
            for (int j = 0; j < 50; j++) {
                // if (j == 1) {
                //     var s = new TreeSeries("House " + i, "Tenant " + j, "Space " + j, 5000, 5000);
                //     series.add(s);
                // }
                // else {
                    for (int k = 0; k < 5; k++) {
                        var s = new TreeSeries("House " + i, "Tenant " + j, "Space " + k, 5000, 5000);
                        series.add(s);
                    }
                // }
            }
        }

        maps = new LinkedHashMap<String, Map<String, List<TreeSeries>>>();

        for (TreeSeries house : series) {
            if (maps.containsKey(house.getHouse())) {
                var tenants = maps.get(house.getHouse());
                boolean isFound = false;
                for (var tenant : tenants.keySet()) {
                    if (house.getTenant().equals(tenant)) {
                        tenants.get(tenant).add(house);
                        isFound = true;
                        break;
                    }
                }
                if (!isFound) {
                    var list = new ArrayList<TreeSeries>();
                    list.add(house);
                    tenants.put(house.getTenant(), list);
                }
            }
            else {
                var subMap = new LinkedHashMap<String, List<TreeSeries>>();
                var list = new ArrayList<TreeSeries>();
                list.add(house);
                subMap.put(house.getTenant(), list);
                maps.put(house.getHouse(), subMap);
            }
        }

        tree = new ExtendedTreeView<TreeSeries>();
        root = new TreeItem<TreeSeries>(new TreeSeries("Root", "", "", 0, 0));

        // filterTask =
        createUnfilteredTree();
        queryBox.textProperty.addListener((obs, oldValue, newValue) -> {
            root.getChildren().clear();
            tree.getSelectionModel().clearSelection();
            if (newValue.isEmpty()) {
                createUnfilteredTree();
            }
            else {
                int count = 0;
                for (var x : maps.keySet()) {
                    var houseSeries = new TreeSeries(x, "", "", 0, 0);
                    var house = new TreeItem<>(houseSeries);
                    var tenants = maps.get(x);

                    for (var w : tenants.keySet()) {
                        var tenantSeries = new TreeSeries("", w, "", 0, 0);
                        var tenant = new TreeItem<>(tenantSeries);
                        var v = tenants.get(w);

                        if (v.size() == 1) {
                            var s = v.get(0);
                            if (s.getSpace().toLowerCase().contains(newValue.toLowerCase()) || s.getTenant().toLowerCase().contains(newValue.toLowerCase())) {
                                tenantSeries.setSpace(s.getSpace());
                                tenantSeries.setDue(s.getDue());
                                tenantSeries.setRent(s.getRent());
                                count++;
                            }

                        }
                        else {
                            for (var u : v) {
                                if (u.getSpace().toLowerCase().contains(newValue.toLowerCase())) {
                                    var space = new TreeItem<>(new TreeSeries("", "", u.getSpace(), u.getRent(), u.getDue()));
                                    int rent = tenantSeries.getRent() + u.getRent();
                                    int due = tenantSeries.getDue() + u.getDue();
                                    tenantSeries.setRent(rent);
                                    tenantSeries.setDue(due);
                                    tenant.getChildren().add(space);
                                    tenant.setExpanded(true);
                                    count++;
                                }
                            }
                            if (tenant.getChildren().size() > 0 || (tenantSeries.getTenant().toLowerCase().contains(newValue.toLowerCase()) || tenantSeries.getSpace().toLowerCase().contains(newValue.toLowerCase()))) {
                                int rent = houseSeries.getRent() + tenantSeries.getRent();
                                int due = houseSeries.getDue() + tenantSeries.getDue();
                                houseSeries.setRent(rent);
                                houseSeries.setDue(due);
                                house.getChildren().add(tenant);
                                house.setExpanded(true);
                            }
                        }
                    }

                    if (house.getChildren().size() > 0 || houseSeries.getHouse().toLowerCase().contains(newValue.toLowerCase())) {
                        root.getChildren().add(house);
                    }
                }
                countLabel.setText("Total: " + String.format("%,d", count) + " items");
            }
        });
        tree.setRoot(root);
        tree.setShowRoot(false);
        tree.setCellFactory(v -> new TenantTemplate(queryBox.textProperty));

        VBox.setVgrow(tree, Priority.ALWAYS);
        box.getChildren().add(tree);
        setCenter(box);
    }

    void createUnfilteredTree() {
        for (var x : maps.keySet()) {
            var houseSeries = new TreeSeries(x, "", "", 0, 0);
            var house = new TreeItem<>(houseSeries);
            var tenants = maps.get(x);

            for (var w : tenants.keySet()) {
                var tenantSeries = new TreeSeries("", w, "", 0, 0);
                var tenant = new TreeItem<>(tenantSeries);
                var v = tenants.get(w);

                if (v.size() == 1) {
                    var s = v.get(0);
                    tenantSeries.setSpace(s.getSpace());
                    tenantSeries.setDue(s.getDue());
                    tenantSeries.setRent(s.getRent());
                }
                else {
                    for (var u : v) {

                        var space = new TreeItem<>(new TreeSeries("", "", u.getSpace(), u.getRent(), u.getDue()));
                        int rent = tenantSeries.getRent() + u.getRent();
                        int due = tenantSeries.getDue() + u.getDue();
                        tenantSeries.setRent(rent);
                        tenantSeries.setDue(due);
                        tenant.getChildren().add(space);
                        tenant.setExpanded(true);
                    }
                    int rent = houseSeries.getRent() + tenantSeries.getRent();
                    int due = houseSeries.getDue() + tenantSeries.getDue();
                    houseSeries.setRent(rent);
                    houseSeries.setDue(due);
                    house.getChildren().add(tenant);
                    house.setExpanded(true);
                }
            }

            root.getChildren().add(house);

        }

        countLabel.setText("Total: " + String.format("%,d", series.size()) + " items");

    }

    Node getHeader(double width) {
        var header = new VBox();
        var row1 = new Text("Header Title");
        var row2 = new Text("Header Subtitle");
        var row3 = new Text("for the period from 01 January 2022 to 31 December 2022");
        row1.setFont(Font.font(null, FontWeight.BOLD, 16));
        row2.setFont(Font.font(null, FontWeight.BOLD, 14));
        row3.setFont(Font.font(null, FontPosture.ITALIC, -1));

        var tableHeader = new GridPane();
        var particulars = new Text("Particulars");
        var due = new Text("Due");
        var rent = new Text("Rent");
        particulars.setFont(Font.font(null, FontWeight.BOLD, -1));
        due.setFont(Font.font(null, FontWeight.BOLD, -1));
        rent.setFont(Font.font(null, FontWeight.BOLD, -1));

        var cons1 = new ColumnConstraints();
        var cons2 = new ColumnConstraints();
        cons1.setHgrow(Priority.ALWAYS);
        cons2.setPrefWidth(70);
        tableHeader.getColumnConstraints().add(cons1);
        tableHeader.getColumnConstraints().add(cons2);
        tableHeader.getColumnConstraints().add(cons2);
        GridPane.setHalignment(due, HPos.RIGHT);
        GridPane.setHalignment(rent, HPos.RIGHT);
        tableHeader.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(1, 0, 1, 0))));
        tableHeader.addColumn(0, particulars);
        tableHeader.addColumn(1, due);
        tableHeader.addColumn(2, rent);

        header.getChildren().addAll(row1, row2, row3, tableHeader);
        header.setAlignment(Pos.TOP_CENTER);
        header.setPrefWidth(width);

        return header;
    }

    Node getFooter(double width) {
        var footer = new GridPane();
        var left = new Text("Auto generated Page");
        pageNoText = new Text();
        footer.addColumn(0, left);
        footer.addColumn(1, pageNoText);
        var cons1 = new ColumnConstraints();
        cons1.setHgrow(Priority.ALWAYS);
        footer.getColumnConstraints().add(cons1);
        footer.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(1, 0, 0, 0))));
        footer.setPrefWidth(width);

        return footer;
    }

    void setPageNo(int pageNo) {
        pageNoText.setText("Page No: " + pageNo);
    }

    void print() {
        PrinterJob printer = null;
        Iterator<Printer> iter = Printer.getAllPrinters().iterator();
        while (iter.hasNext()) {
            var current = iter.next();
            if (current.getName().equals("Virtual_PDF_Printer")) {
                printer = PrinterJob.createPrinterJob(current);
            }
        }
        var dialog = printer.showPrintDialog(null);
        if(!dialog) {
            System.out.println("cancelled in Print Dialog");
            return;
        }

        dialog = printer.showPageSetupDialog(null);
        if(!dialog){
            System.out.println("cancelled in Page Setup Dialog");
            return;
        }

        var layout = printer.getJobSettings().getPageLayout();
        double width = layout.getPrintableWidth();

        var header = getHeader(width);
        var footer = getFooter(width);
        double leftOver = layout.getPrintableHeight() - header.prefHeight(-1) - footer.prefHeight(-1);

        // System.out.println("Printable H " + layout.getPrintableHeight() + " W " +
        // layout.getPrintableWidth());
        // System.out.println("Header Height " + header.prefHeight(-1));
        // System.out.println("Footer Height " + footer.prefHeight(-1));

        var contentGrid = new GridPane();
        contentGrid.setMinSize(width, leftOver);

        contentGrid.setPrefSize(width, leftOver);
        contentGrid.setMaxSize(width, leftOver);
        var pageGrid = new GridPane();
        pageGrid.addRow(0, header);
        pageGrid.addRow(1, contentGrid);
        pageGrid.addRow(2, footer);

        // var nodes = tree.getRoot().getChildren();
        // System.out.println("Total nodes : " + nodes.size());
        // for(var item : nodes){

        // //if(graphic == null) System.out.println("Graphic null");
        // contentGrid.addRow(contentGrid.getRowCount(), item.getGraphic());
        // }
        int pageNo = 1;
        double accumulatedHeight = 0, requiredHeight;

        setPageNo(pageNo);
        var start = System.currentTimeMillis();

        System.out.println("Printing started");
        for (var house : maps.keySet()) {
            var houseName = new Text(house);
            houseName.setFont(Font.font(null, FontWeight.BOLD, -1));
            var houseStack = new StackPane(houseName);
            StackPane.setAlignment(houseName, Pos.CENTER_LEFT);
            houseStack.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(0, 0, 1, 0))));

            requiredHeight = houseStack.prefHeight(-1);
            accumulatedHeight += requiredHeight;

            if ((leftOver - accumulatedHeight) < 0) {
                System.out.println("Page " + pageNo);
                printer.printPage(pageGrid);
                contentGrid.getChildren().clear();
                setPageNo(++pageNo);
                accumulatedHeight = requiredHeight;
            }
            contentGrid.addRow(contentGrid.getRowCount(), houseStack);

            var tenants = maps.get(house);
            for (var tenant : tenants.keySet()) {
                var spaces = tenants.get(tenant);

                if (spaces.size() == 1) {
                    var tenantName = new Text(tenant);
                    tenantName.setFont(Font.font(null, FontWeight.BOLD, -1));
                    var space = new Text(" - " + spaces.get(0).getSpace());
                    var grid = new GridPane();
                    var spaceName = new TextFlow(tenantName, space);
                    var due = new Text(String.format("%,d", spaces.get(0).getDue()));
                    var rent = new Text(String.format("%,d", spaces.get(0).getRent()));

                    grid.addColumn(0, spaceName);
                    grid.addColumn(1, due);
                    grid.addColumn(2, rent);

                    var cons1 = new ColumnConstraints();
                    var cons2 = new ColumnConstraints();
                    cons1.setHgrow(Priority.ALWAYS);
                    cons2.setPrefWidth(70);
                    grid.getColumnConstraints().add(cons1);
                    grid.getColumnConstraints().add(cons2);
                    grid.getColumnConstraints().add(cons2);
                    GridPane.setHalignment(due, HPos.RIGHT);
                    GridPane.setHalignment(rent, HPos.RIGHT);
                    grid.setPrefWidth(width);
                    GridPane.setMargin(grid, new Insets(0, 0, 0, 15));

                    requiredHeight = grid.prefHeight(-1);
                    accumulatedHeight += requiredHeight;
                    if ((leftOver - accumulatedHeight) < 0) {
                        System.out.println("Page " + pageNo);
                        printer.printPage(pageGrid);
                        contentGrid.getChildren().clear();
                        setPageNo(++pageNo);
                        accumulatedHeight = requiredHeight;
                    }
                    contentGrid.addRow(contentGrid.getRowCount(), grid);

                }
                else {
                    var tenantName = new Text(tenant);
                    tenantName.setFont(Font.font(null, FontWeight.BOLD, -1));
                    var tenantStack = new StackPane(tenantName);
                    StackPane.setAlignment(tenantName, Pos.CENTER_LEFT);
                    tenantStack.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(0, 0, 1, 0))));

                    GridPane.setMargin(tenantStack, new Insets(0, 0, 0, 15));

                    requiredHeight = tenantStack.prefHeight(-1);
                    accumulatedHeight += requiredHeight;
                    if ((leftOver - accumulatedHeight) < 0) {
                        System.out.println("Page " + pageNo);
                        printer.printPage(pageGrid);
                        contentGrid.getChildren().clear();
                        setPageNo(++pageNo);
                        accumulatedHeight = requiredHeight;
                    }

                    contentGrid.addRow(contentGrid.getRowCount(), tenantStack);

                    for (var space : spaces) {
                        var grid = new GridPane();
                        var spaceName = new Text(space.getSpace());
                        var due = new Text(String.format("%,d", space.getDue()));
                        var rent = new Text(String.format("%,d", space.getRent()));

                        grid.addColumn(0, spaceName);
                        grid.addColumn(1, due);
                        grid.addColumn(2, rent);

                        var cons1 = new ColumnConstraints();
                        var cons2 = new ColumnConstraints();
                        cons1.setHgrow(Priority.ALWAYS);
                        cons2.setPrefWidth(70);
                        grid.getColumnConstraints().add(cons1);
                        grid.getColumnConstraints().add(cons2);
                        grid.getColumnConstraints().add(cons2);
                        GridPane.setHalignment(due, HPos.RIGHT);
                        GridPane.setHalignment(rent, HPos.RIGHT);
                        grid.setPrefWidth(width);
                        GridPane.setMargin(grid, new Insets(0, 0, 0, 25));

                        requiredHeight = grid.prefHeight(-1);
                        accumulatedHeight += requiredHeight;
                        if ((leftOver - accumulatedHeight) < 0) {
                            System.out.println("Page " + pageNo);
                            printer.printPage(pageGrid);
                            contentGrid.getChildren().clear();
                            setPageNo(++pageNo);
                            accumulatedHeight = requiredHeight;
                        }

                        contentGrid.addRow(contentGrid.getRowCount(), grid);
                    }
                    var bottomStack = new StackPane();
                    bottomStack.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(0, 0, 1, 0))));

                    GridPane.setMargin(bottomStack, new Insets(0, 0, 0, 15));
                    if (leftOver - accumulatedHeight > 10)
                        contentGrid.addRow(contentGrid.getRowCount(), bottomStack);
                }
            }
        }

        printer.printPage(pageGrid);
        printer.endJob();

        var end = System.currentTimeMillis();
        System.out.println("Printing completed in " + ((end - start) / 1000));
    }
}

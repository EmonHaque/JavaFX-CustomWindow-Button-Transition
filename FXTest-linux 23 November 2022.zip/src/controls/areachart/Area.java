package controls.areachart;

import java.util.Comparator;
import java.util.List;

import javafx.animation.FadeTransition;
import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.Group;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Scale;
import javafx.util.Duration;

public class Area extends Region {
    private int size;
    private boolean isLoaded;
    private AreaStroke stroke;
    private AreaFill fill;
    private Group circles;
    private List<Double> values;
    private double yMax, width, height;

    private Timeline strokeAnim, fillAnim;
    private KeyFrame widthFrame, heightFrame;
    private FadeTransition circleAnim;
    private Rectangle widthClip, heightClip;

    public ObjectProperty<List<Double>> seriesProperty; // take some sort of series with label

    public Area() {
        circles = new Group();
        stroke = new AreaStroke();
        fill = new AreaFill();

        stroke.setManaged(false);
        fill.setManaged(false);
        circles.setManaged(false);

        stroke.setMouseTransparent(true);
        fill.setMouseTransparent(false);

        stroke.getTransforms().add(new Scale(1, -1));
        fill.getTransforms().add(new Scale(1, -1));
        getChildren().addAll(fill, stroke, circles);

        widthClip = new Rectangle(0, 0, 0, 0);
        heightClip = new Rectangle(0, 0, 0, 0);
        stroke.setClip(widthClip);
        fill.setClip(heightClip);

        seriesProperty = new SimpleObjectProperty<>();
        seriesProperty.addListener(this::onSeriesChanged);

        strokeAnim = new Timeline();
        fillAnim = new Timeline();
        circleAnim = new FadeTransition(Duration.millis(1000), circles);
        circleAnim.setDelay(Duration.seconds(1));
        circleAnim.setToValue(1);

        strokeAnim.setOnFinished(e -> stroke.setClip(null));
        fillAnim.setOnFinished(e -> fill.setClip(null));
    }

    private void onSeriesChanged(ObservableValue<?> obs, List<Double> ov, List<Double> nv) {
        for (var circle : circles.getChildren()) {
            getChildren().remove(circle);
        }
        circles.getChildren().clear();
        circles.setOpacity(0);

        if(nv == null){
            stroke.clear();
            fill.clear();
            return;
        }

        stroke.setData(nv);
        fill.setData(nv);
        values = nv;
        size = values.size();
        yMax = values.stream().max(Comparator.comparingDouble(x -> x)).get();
        for (int i = 0; i < size; i++) {
            var circle = new Circle();
            circle.setRadius(3);
            circle.setFill(Color.CORAL);
            circles.getChildren().add(circle);
            circle.setManaged(false);
        }
       
        widthClip.setWidth(0);
        widthClip.setHeight(height);
        heightClip.setHeight(0);
        heightClip.setWidth(width);
        stroke.setClip(widthClip);
        fill.setClip(heightClip);

        strokeAnim.getKeyFrames().clear();
        fillAnim.getKeyFrames().clear();
        var widthkey = new KeyValue(widthClip.widthProperty(), width, Interpolator.EASE_IN);
        var heightKey = new KeyValue(heightClip.heightProperty(), height, Interpolator.EASE_IN);
        widthFrame = new KeyFrame(Duration.millis(1000), widthkey);
        heightFrame = new KeyFrame(Duration.millis(1000), heightKey);
        strokeAnim.getKeyFrames().add(widthFrame);
        fillAnim.getKeyFrames().add(heightFrame);

        fillAnim.play();
        strokeAnim.play();
        circleAnim.play();

        if (isLoaded)
            requestLayout();
    }

    @Override
    protected void layoutChildren() {
        if (!isLoaded)
            isLoaded = true;  

        width = getWidth();
        height = getHeight();

        fill.setTranslateY(height);
        stroke.setTranslateY(height);

        fill.setValue(width, height, yMax); // same computation thrice
        stroke.setValue(width, height, yMax); // same computation thrice

        double xGap = width / (size - 1);
        double yFactor = height / yMax;
        double x = 0, y;
        for (int i = 0; i < size; i++) {
            // same computation thrice
            y = height - (values.get(i) * yFactor);
            var circle = (Circle) circles.getChildren().get(i);
            circle.setCenterX(x);
            circle.setCenterY(y);
            x += xGap;
        }

    }
}

package controls.pinchart;

import controls.columnstackchart.Column;
import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Scale;
import javafx.util.Duration;
import model.PinColumnSeries;

public class PinColumn extends StackPane {
    private double width, height, midPoint, yMax, ballY, radius = 3;
    private Column column;
    private PinSegment pin;
    private Circle ball;

    private Timeline anim;
    private TranslateTransition ballAnim;
    private DoubleProperty pinHeight;
    private PinColumnSeries series;

    public PinColumn(PinColumnSeries series) {
        this.series = series;
        getTransforms().add(new Scale(1, -1));
        column = new Column(Color.GREEN, Color.CORAL, true);
        pin = new PinSegment(Color.CORAL, Color.WHITE);
        ball = new Circle();
        ball.setFill(Color.CORNFLOWERBLUE);
        ball.setRadius(radius);
        getChildren().addAll(column, pin, ball);

        column.setManaged(false);
        pin.setManaged(false);
        ball.setManaged(false);

        column.setMouseTransparent(true);
        pin.setMouseTransparent(true);
        ball.setMouseTransparent(true);

        pinHeight = new SimpleDoubleProperty(0);
        var clip = new Rectangle();
        layoutBoundsProperty().addListener((observable, oldValue, newValue) -> {
            clip.setWidth(newValue.getWidth());
            clip.setHeight(newValue.getHeight());
        });
        setClip(clip);

        setOnMouseEntered(this::onMouseEntered);
        setOnMouseExited(this::onMouseExited);
    }

    public void makePin(double width, double height, double yMax) {
        this.width = width;
        this.height = height;
        this.yMax = yMax;

        midPoint = width / 2;
        pinHeight.addListener((o, ov, nv) -> {
            setHeight(nv.doubleValue());
        });
        var key = new KeyValue(pinHeight, height, Interpolator.EASE_IN);
        var frame = new KeyFrame(Duration.millis(500), key);
        anim = new Timeline(frame);
        anim.setDelay(Duration.millis(500));
        anim.play();

        ball.setOpacity(0);
        anim.setOnFinished(e -> {
            setClip(null);
            ball.setOpacity(1);
            ball.setTranslateY(height - ballY);
            ballAnim.play();
            anim.setOnFinished(null);
        });

        ballAnim = new TranslateTransition(Duration.millis(500), ball);
        //ballAnim.setDelay(Duration.millis(1000));
        ballAnim.setToY(0);
        
    }

   

    @Override
    protected void layoutChildren() {
        // if(!isLoaded){
        //     isLoaded = true;
        //     double yFactor = height / yMax;
        //     var pinHeight = yFactor * series.getPin();
        //     ball.setTranslateY(-pinHeight);
        // }
        if (pinHeight.get() == 0)
            return;


        double yFactor = height / yMax;
        var pinHeight = yFactor * series.getPin();
        var columnHeight = yFactor * series.getColumn();

        ball.setCenterX(midPoint);
        ball.setCenterY(pinHeight);
        ballY = pinHeight;

        pin.setValue(midPoint, 0, pinHeight - radius / 2);
        column.setValue(0, 0, width, columnHeight);
    }

    void onMouseEntered(MouseEvent e) {
        column.highlightColor();
        pin.highlightColor();
        // var point = localToScreen(width / 2, height);
        // var x = point.getX() - content.prefWidth(-1) / 2;
        // var y = point.getY() - content.prefHeight(-1) - 15;
        // pop.show(this, x, y);
    }

    void onMouseExited(MouseEvent e) {
        column.normalColor();
        pin.normalColor();
        // pop.hide();
    }
}

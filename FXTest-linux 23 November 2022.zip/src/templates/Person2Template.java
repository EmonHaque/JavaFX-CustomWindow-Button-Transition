package templates;

import controls.states.BiState;
import helpers.Constants;
import javafx.beans.binding.StringBinding;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.ListCell;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import model.Person2;

public class Person2Template extends ListCell<Person2> {

    @Override
    protected void updateItem(Person2 item, boolean empty) {
        super.updateItem(item, empty);
        setText(null);
        if (item == null || empty) {
            setGraphic(null);
            setBackground(null);
        }
        else {
            setPadding(new Insets(1,0,1,0));
            prefWidth(0);
            var name = new Text();
            var age = new Text();
            var gender = new BiState(true, "is male");
            name.setFill(Color.WHITE);
            age.setFill(Color.WHITE);

            name.textProperty().bind(item.name);
            age.textProperty().bind(new StringBinding() {
                { bind(item.age); }
                @Override
                protected String computeValue() {
                    return String.valueOf(item.age.get());
                }
            });
            gender.isCheckedProperty().bind(item.isMale);

            var grid = new GridPane();
            
            grid.addColumn(0, name);
            grid.addColumn(1, age);
            grid.addColumn(2, gender);
            grid.setMouseTransparent(true);
            var cons1 = new ColumnConstraints();
            var cons2 = new ColumnConstraints(70);
            cons1.setHgrow(Priority.ALWAYS);
            //cons2.setPrefWidth(50);
            grid.getColumnConstraints().addAll(cons1, cons2, cons2);
            GridPane.setHalignment(age, HPos.CENTER);
            GridPane.setHalignment(gender, HPos.RIGHT);
            setGraphic(grid);

            if (isSelected())
                setBackground(new Background(new BackgroundFill(Constants.BackgroundColorLight, null, null)));
            else
                setBackground(null);
        }
    }
}

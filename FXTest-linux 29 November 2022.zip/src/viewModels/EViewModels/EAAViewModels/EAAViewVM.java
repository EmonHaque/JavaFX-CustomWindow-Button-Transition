package viewModels.EViewModels.EAAViewModels;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Person3;
import model.Tenant;

public class EAAViewVM {
    public Tenant tenant;
    public ObservableList<String> houses, spaces;
    public ObservableList<Person3> people;
    public EAAViewVM() {
        tenant = new Tenant();
        houses = FXCollections.observableArrayList();
        spaces = FXCollections.observableArrayList();
        people = FXCollections.observableArrayList();
        for(int i = 0; i < 50; i++){
            houses.addAll("House " + i);
            spaces.add("Space " + i);
            people.add(new Person3("Test Name " + i, "1234"));
        }
    }

    public void addTenant(){
        System.out.println("added: " + tenant);
        tenant.houseProperty.set(null);
        tenant.tenantProperty.set(null);
        tenant.spaceProperty.set(null);
        tenant.rentProperty.set(0);
        tenant.dueProperty.set(0);
    }
}

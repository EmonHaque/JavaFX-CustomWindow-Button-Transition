package templates;

import controls.HiText;
import controls.SVGIcon;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TreeCell;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import model.TreeSeries;

public class TenantTemplate extends TreeCell<TreeSeries> {
    private Node expanded = new SVGIcon(Icons.PlusCircle);
    private Node collapsed = new SVGIcon(Icons.MinusCircle);
    public StringProperty query;

    public TenantTemplate(StringProperty q) {
        query = new SimpleStringProperty();
        query.bind(q);
        hoverProperty().addListener((obs, wasHovered, isNowHovered) -> {
            if (isNowHovered && !isEmpty()) {
                if(!isSelected())
                    setBackground(new Background(new BackgroundFill(Constants.BackgroundColorLight, null, null)));
            } else {
                if(!isSelected())
                    setBackground(null);
            }
        });
    }
    @Override
    protected void updateItem(TreeSeries item, boolean empty) {
        super.updateItem(item, empty);
        setText(null);
        if (item == null || empty) {
            setGraphic(null);
            setBackground(null);
            setDisclosureNode(null);
        }
        else {
            setPrefWidth(0);
            var treeItem = getTreeItem();
            setDisclosureNode(treeItem.isExpanded() ? expanded : collapsed);
            int numLeaf = treeItem.getChildren().size();
            int level = getTreeView().getTreeItemLevel(treeItem);

            var grid = new GridPane();
            var nameFlow = new HiText();
            var name = new Text();
            var due = new Label(String.format("%,d", item.getDue()));
            var rent = new Label(String.format("%,d", item.getRent()));
            
            nameFlow.getChildren().add(name);
            name.setFill(Color.WHITE);
            due.setTextFill(Color.WHITE);
            rent.setTextFill(Color.WHITE);
            grid.addColumn(0, nameFlow);
            grid.addColumn(1, due);
            grid.addColumn(2, rent);

            GridPane.setValignment(due, VPos.CENTER);
            GridPane.setValignment(rent, VPos.CENTER);

            var cons1 = new ColumnConstraints();
            var cons2 = new ColumnConstraints();
            cons1.setHgrow(Priority.ALWAYS);
            cons2.setPrefWidth(100);
            grid.getColumnConstraints().add(cons1);
            grid.getColumnConstraints().add(cons2);
            grid.getColumnConstraints().add(cons2);
            GridPane.setHalignment(due, HPos.RIGHT);
            GridPane.setHalignment(rent, HPos.RIGHT);

            if (level == 3) {
                name.setText(item.getSpace());
                GridPane.setMargin(nameFlow, new Insets(0, 0, 0, -12));
                setGraphic(grid);
            }
            else if (level == 2) {
                name.setText(item.getTenant());
                name.setFont(Font.font(null, FontWeight.BOLD, -1));
                rent.setFont(Font.font(null, FontWeight.BOLD, -1));
                due.setFont(Font.font(null, FontWeight.BOLD, -1));
                var stack = new StackPane(grid);

                double borderWidth = 0.25;
                if (numLeaf == 0) {
                    if(!item.getSpace().isEmpty()){
                        var space = new Text(" - " + item.getSpace());
                        space.setFill(Color.WHITE);
                        nameFlow.getChildren().add(space);
                        StackPane.setMargin(grid, new Insets(0, 0, 0, -12));
                        borderWidth = 0;
                    }
                }
                stack.setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0, 0, borderWidth, 0))));
                setGraphic(stack);
            }
            else {
                name.setText(item.getHouse());
                name.setFont(Font.font(null, FontWeight.BOLD, -1));
                rent.setFont(Font.font(null, FontWeight.BOLD, -1));
                due.setFont(Font.font(null, FontWeight.BOLD, -1));
                var stack = new StackPane(grid);
                stack.setBorder(Constants.BottomLine);
                setGraphic(stack);
            }
            if (isSelected()) {
                setBackground(new Background(new BackgroundFill(Constants.BackgroundColorLight, null, null)));
            }
            else {
                setBackground(null);
            }

            nameFlow.query.bind(query);
        }
    }
}

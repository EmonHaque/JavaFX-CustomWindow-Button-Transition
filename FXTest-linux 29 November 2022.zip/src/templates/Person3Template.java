package templates;

import controls.HiText;
import helpers.Constants;
import javafx.beans.property.StringProperty;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.layout.Background;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import model.Person3;

public class Person3Template extends ListCell<Person3> {
    StringProperty query;
    public Person3Template(StringProperty query) {
        this.query = query;
    }
    @Override
    protected void updateItem(Person3 item, boolean empty) {
        super.updateItem(item, empty);
      
        if(item == null || empty){
            setBackground(null);
            setText(null);
            setGraphic(null);
        }
        else{
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            var name = new HiText(item.getName());
            var phone = new Text(item.getPhone());
            //name.setFill(Color.WHITE);
            phone.setFill(Color.WHITE);
            var spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);
            var box = new HBox(name, spacer, phone);
            setGraphic(box);
            if(isSelected()){
                setBackground(Background.fill(Constants.BackgroundColorLight));
            }
            else{
                setBackground(null);
            }
            name.query.bind(query);
        }
    }
}

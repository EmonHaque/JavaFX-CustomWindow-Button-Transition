package abstracts;

import controls.ActionButton;
import helpers.Constants;
import helpers.Icons;
import javafx.animation.Animation;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.stage.Popup;
import javafx.stage.WindowEvent;
import skinned.ExtendedTextField;

public abstract class SelectionControlBase extends HintedControlBase {
    protected Popup popup;
    protected GridPane popupGrid;
    protected ActionButton open, close;
    protected ExtendedTextField input;
    protected boolean isOpen;
    protected HBox selectedBox;

    public SelectionControlBase(String hint, String leftIcon) {
        super(hint, leftIcon);
        input = new ExtendedTextField();
        input.setDisable(true);
        input.setMouseTransparent(true);
        setHgrow(input, Priority.ALWAYS);
        open = new ActionButton(getRightIcon(), 16, "show");
        add(input, 1, 0);
        add(open, 2, 0);

        addPopup();
        addSelectedBox();

        close.setAction(this::removeSelected);
        open.setAction(this::togglePopup);
        selectedBox.setOnMouseClicked(e -> togglePopup());
        addEventHandler(MouseEvent.ANY, this::onMouseEvents);
        popup.setOnShowing(this::onPopupShowing);
        popup.setOnHiding(this::onPopupHiding);
    }

    protected abstract String getRightIcon();

    protected Node getSelectedContent() {
        return null;
    }

    protected void onPopupShowing(WindowEvent e){
        isOpen = true;
    }

    protected void onPopupHiding(WindowEvent e){
        isOpen = false;
    }

    protected void addPopup() {
        popupGrid = new GridPane();
        popupGrid.setBackground(new Background(new BackgroundFill(Constants.BackgroundColor, new CornerRadii(5, false), null)));
        popupGrid.setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5, 5, 5, 5, false), new BorderWidths(0.25))));
        popupGrid.setPadding(new Insets(10));
        popup = new Popup();
        popup.setAutoHide(true);
        //popup.setConsumeAutoHidingEvents(true);
        popup.getContent().add(popupGrid);
    }

    protected void addSelectedBox() {
        var content = getSelectedContent();
        close = new ActionButton(Icons.CloseCircle, 16, "remove");
        selectedBox = new HBox(close);
        if (content != null) {
            var spacer = new Region();
            selectedBox.getChildren().add(0, content);
            selectedBox.getChildren().add(1, spacer); // content is Text and it doesn't grow
            HBox.setMargin(spacer, new Insets(0, 0, 0, 5));
            HBox.setHgrow(spacer, Priority.ALWAYS);
        }
        selectedBox.setAlignment(Pos.CENTER_LEFT);
        selectedBox.setBackground(new Background(new BackgroundFill(Constants.BackgroundColorLight, new CornerRadii(5), null)));
        setMargin(selectedBox, new Insets(0, 5, 0, 5));
        add(selectedBox, 1, 0);
    }

    protected void setSelectedContent(Node content) {
        selectedBox.getChildren().add(0, content);
        HBox.setMargin(content, new Insets(0, 0, 0, 5));
        HBox.setHgrow(content, Priority.ALWAYS);
    }

    protected void removeSelected() {
        selectedBox.setVisible(false);
        input.setDisable(false);
        input.setText("");
        input.requestFocus();
    }

    protected void onSelected(){
        if(isOpen){
            popup.hide();
        }
        if(!isHintMoved){
            moveHintUp();
            moveHint.setOnFinished(ev -> {
                selectedBox.setVisible(true);
                moveHint.setOnFinished(null);
            });
        }
        else{
            input.setText("");
            input.setDisable(true);
            selectedBox.setVisible(true);
        }
    }

    protected void togglePopup() {
        if (!isOpen) {
            var point = input.localToScreen(0, 0);
            if(popup.getContent().get(0) instanceof ListView){
                ((ListView<?>)popup.getContent().get(0)).setMinWidth(input.getWidth());
            }
            popup.show(input, point.getX(), point.getY() + input.getHeight());
        }
        else {
            popup.hide();
        }
    }

    private void onMouseEvents(MouseEvent e) {
        if (moveHint.getStatus() == Animation.Status.RUNNING)
            return;

        if (e.getEventType() == MouseEvent.MOUSE_ENTERED) {
            setFocusColor();
            if (!selectedBox.isVisible() && input.getText().isEmpty()) {
                if (!isHintMoved)
                    moveHintUp();
                input.requestFocus();
            }
        }
        else if (e.getEventType() == MouseEvent.MOUSE_EXITED) {
            resetFocusColor();
            if (!selectedBox.isVisible() && input.getText().isEmpty()) {
                if (isHintMoved)
                    moveHintDown();
                leftIcon.requestFocus();
            }
        }
    }
}

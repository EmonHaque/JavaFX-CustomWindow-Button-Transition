package Views.GSubViews;

public class GDView extends GAbstractView {

    @Override
    protected String getName() {
        return "GD";
    }
}

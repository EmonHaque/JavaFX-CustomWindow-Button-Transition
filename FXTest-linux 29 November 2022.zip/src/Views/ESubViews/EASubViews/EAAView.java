package Views.ESubViews.EASubViews;

import abstracts.View;
import controls.CommandButton;
import controls.DoubleBox;
import controls.IntegerBox;
import controls.SuggestionBox;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.util.StringConverter;
import model.Person3;
import templates.Person3Template;
import viewModels.EViewModels.EAAViewModels.EAAViewVM;

public class EAAView extends View {
    SuggestionBox<String> houseText, spaceText;
    SuggestionBox<Person3> tenantText;
    IntegerBox rentText;
    DoubleBox dueText;
    CommandButton add;

    EAAViewVM vm;

    @Override
    protected String getHeader() {
        return "EAA View";
    }

    @Override
    protected String getIcon() {
        return Icons.ACircle;
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight EAA View");

        vm = new EAAViewVM();
        initializeUI();
        bind();
    }

    private void initializeUI() {
        houseText = new SuggestionBox<>("House", Icons.Building, vm.houses, null, null);
        tenantText = new SuggestionBox<>("Tenant", Icons.User, vm.people, "Name", Person3Template.class.getName());
        spaceText = new SuggestionBox<>("Space", Icons.Home, vm.spaces, null, null);

        rentText = new IntegerBox("Rent", Icons.Transact);
        dueText = new DoubleBox("Due", Icons.Transact);

        add = new CommandButton(Icons.Add, 16, "add");

        var amountBox = new HBox(rentText, dueText);
        HBox.setHgrow(rentText, Priority.ALWAYS);
        HBox.setHgrow(dueText, Priority.ALWAYS);
        amountBox.setSpacing(10);

        var box = new VBox(houseText, tenantText, spaceText, amountBox, add);
        box.setAlignment(Pos.CENTER_RIGHT);
        box.setSpacing(5);
        box.setPadding(new Insets(5, 0, 0, 0));
        VBox.setMargin(add, new Insets(10, 0, 0, 0));
        setCenter(box);
    }

    private void bind() {
        houseText.textProperty.bindBidirectional(vm.tenant.houseProperty);
        tenantText.textProperty.bindBidirectional(vm.tenant.tenantProperty);
        spaceText.textProperty.bindBidirectional(vm.tenant.spaceProperty);

        Bindings.bindBidirectional(rentText.textProperty, vm.tenant.rentProperty, new StringConverter<Number>() {
            @Override
            public Number fromString(String s) {
                if (s == null || s.isEmpty() || s.isBlank())
                    return 0;
                else {
                    try {
                        return Integer.parseInt(s);
                    }
                    catch (Exception e) {
                        return 0;
                    }
                }
            }

            @Override
            public String toString(Number n) {
                return n.intValue() == 0 ? "" : n.toString();
            }
        });
        Bindings.bindBidirectional(dueText.textProperty, vm.tenant.dueProperty, new StringConverter<Number>() {
            @Override
            public Number fromString(String s) {
                if (s == null || s.isEmpty() || s.isBlank())
                    return 0;
                else {
                    try {
                        return Double.parseDouble(s);
                    }
                    catch (Exception e) {
                        return 0;
                    }
                }
            }

            @Override
            public String toString(Number n) {
                return n.doubleValue() == 0 ? "" : n.toString();
            }
        });

        add.setAction(vm::addTenant);
        add.disableProperty().bind((houseText.textProperty.isEmpty()
                .or(tenantText.textProperty.isEmpty())
                .or(spaceText.textProperty.isEmpty())
                .or(rentText.textProperty.isEmpty())
                .or(dueText.textProperty.isEmpty())));
    }
}

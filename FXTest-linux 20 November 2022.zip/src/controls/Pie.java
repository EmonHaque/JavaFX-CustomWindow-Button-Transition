package controls;

import javafx.animation.*;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.util.Duration;
import model.PieSeries;
import java.util.List;

import helpers.Constants;

public class Pie extends Region {
    private boolean isLoaded;
    private double width, height, cx, cy, radius, sliceTotal;
    private Circle circle;
    private Group info, slices;
    private Text label, value, percent;
    private Slice selected;
    private ScaleTransition circleAnim, infoAnim, pieScaleAnim;
    private RotateTransition pieRotateAnim;
    private ParallelTransition pieAnim;

    public ObjectProperty<List<PieSeries>> seriesProperty;
    public ObjectProperty<PieSeries> selectedProperty;

    public Pie() {
        slices = new Group();
        slices.setManaged(false);
        getChildren().add(slices);

        circle = new Circle();
        circle.setFill(Constants.BackgroundColor);
        circle.setManaged(false);
        getChildren().add(circle);

        label = new Text();
        label.setFont(Font.font(null, FontWeight.BOLD, 14));
        label.setFill(Color.CORNFLOWERBLUE);
        value = new Text();
        value.setFont(Font.font(null, FontWeight.BOLD, 12));
        value.setFill(Color.GREEN);
        percent = new Text();
        percent.setFont(Font.font(null, FontPosture.ITALIC, 12));
        percent.setFill(Color.GRAY);

        var infoBox = new VBox(label, value, percent);
        infoBox.setAlignment(Pos.CENTER);
        info = new Group(infoBox);
        infoBox.setMouseTransparent(true);
        getChildren().add(info);

        infoAnim = new ScaleTransition(Duration.millis(500), info);
        info.setScaleX(0);
        info.setScaleY(0);

        circleAnim = new ScaleTransition(Duration.millis(500), circle);
        circleAnim.setDelay(Duration.millis(250));
        circle.setScaleX(0);
        circle.setScaleY(0);

        pieScaleAnim = new ScaleTransition(Duration.seconds(1), slices);
        pieRotateAnim = new RotateTransition(Duration.seconds(1), slices);
        pieAnim = new ParallelTransition(pieScaleAnim, pieRotateAnim);
        pieAnim.setOnFinished(this::onPieAnimationFinished);

        selectedProperty = new SimpleObjectProperty<>();
        seriesProperty = new SimpleObjectProperty<>();
        seriesProperty.addListener(this::onSeriesChanged);
    }

    public Pie(List<PieSeries> series) {
        this();
        bakePie(series);
    }

    private void onPieAnimationFinished(ActionEvent e) {
        if (selected != null) {
            boolean isFound = false;
            for (var s : slices.getChildren()) {
                var slice = (Slice) s;
                if (slice.getSeries().title.equals(selected.getSeries().title)) {
                    isFound = true;
                    selected = slice;
                    label.setText(slice.getSeries().title);
                    value.setText((int) slice.getSeries().value + "");
                    percent.setText(String.format("%.2f", slice.getSeries().value / sliceTotal * 100) + "%");
                    break;
                }
            }
            if (isFound) {
                playReveal();
                selectedProperty.set(selected.getSeries());
                circleAnim.setOnFinished(ev ->{
                    selected.setSelected(true);
                    circleAnim.setOnFinished(null);
                });
            }
            else {
                selected = null;
                selectedProperty.set(null);
            }

        }
    }

    private void onSeriesChanged(ObservableValue<?> obs, List<PieSeries> ov, List<PieSeries> nv) {
        // do you remove handlers when you clear? slice.addEventHandler(MouseEvent.ANY,
        // this::onMouse);
        slices.getChildren().clear();
        if (nv != null) {
            if (selected != null) {
                info.setScaleX(0);
                info.setScaleY(0);
                circle.setScaleX(0);
                circle.setScaleY(0);
            }
            bakePie(nv);

            if(pieAnim.getStatus() == Animation.Status.RUNNING){
                pieAnim.stop();
            }
            slices.setScaleX(0);
            slices.setScaleY(0);
            pieScaleAnim.setByX(1);
            pieScaleAnim.setByY(1);
            pieRotateAnim.setFromAngle(0);
            pieRotateAnim.setToAngle(360);
            pieAnim.play();
        }
    }

    private void bakePie(List<PieSeries> series) {
        if (!isLoaded)
            return;
        double startAngle = 0;
        sliceTotal = series.stream().mapToDouble(x -> x.value).sum();
        for (PieSeries s : series) {
            var degree = s.value / sliceTotal * 360.0;
            var endAngle = degree * Math.PI / 180;
            var isLarge = s.value / sliceTotal > 0.5;
            var slice = new Slice(startAngle, endAngle, isLarge, s);
            slice.setValue(new Point2D(cx, cy), radius);
            startAngle += endAngle;
            slices.getChildren().add(slice);
            slice.setManaged(false);
            slice.addEventHandler(MouseEvent.ANY, this::onMouse);
        }
    }

    @Override
    protected void layoutChildren() {
        width = getWidth();
        height = getHeight();
        cx = width / 2;
        cy = height / 2;
        radius = width > height ? height / 2 - 20 : width / 2 - 20;

        circle.setRadius(radius * 0.7);
        circle.setCenterX(cx);
        circle.setCenterY(cy);

        info.setTranslateX(cx - info.prefWidth(-1) / 2);
        info.setTranslateY(cy - info.prefHeight(-1) / 2);

        if (!isLoaded) {
            isLoaded = true;
            bakePie(seriesProperty.get());
        }
        else {
            for (var s : slices.getChildren()) {
                ((Slice) s).setValue(new Point2D(cx, cy), radius);
            }
        }
    }

    void onMouse(MouseEvent e) {
        if (e.getEventType() == MouseEvent.MOUSE_ENTERED) {
            var slice = (Slice) e.getSource();
            label.setText(slice.getSeries().title);
            value.setText((int) slice.getSeries().value + "");
            percent.setText(String.format("%.2f", slice.getSeries().value / sliceTotal * 100) + "%");

            if (selected != null)
                return;

            if (circleAnim.getStatus() == Animation.Status.RUNNING) {
                circleAnim.stop();
            }
            if (infoAnim.getStatus() == Animation.Status.RUNNING) {
                infoAnim.stop();
            }
            playReveal();
        }
        else if (e.getEventType() == MouseEvent.MOUSE_EXITED) {
            if (selected != null)
                return;

            if (circleAnim.getStatus() == Animation.Status.RUNNING) {
                circleAnim.stop();
            }

            if (infoAnim.getStatus() == Animation.Status.RUNNING) {
                infoAnim.stop();
            }
            playConceal();
        }
        else if (e.getEventType() == MouseEvent.MOUSE_RELEASED) {
            if (!(e.getSource() instanceof Slice))
                return;
            var source = (Slice) e.getSource();
            if (selected != null) {
                if (selected == source) {
                    selected = null;
                    selectedProperty.set(null);
                }
                else {
                    selected.setSelected(false);
                    selected = source;
                    selectedProperty.set(selected.getSeries());
                }
            }
            else {
                selected = source;
                selectedProperty.set(selected.getSeries());
            }
        }
    }

    private void playReveal() {
        circleAnim.setFromX(circle.getScaleX());
        circleAnim.setFromY(circle.getScaleY());
        circleAnim.setToX(1);
        circleAnim.setToY(1);
        circleAnim.play();

        infoAnim.setDelay(Duration.millis(250));
        infoAnim.setFromX(info.getScaleX());
        infoAnim.setFromY(info.getScaleY());
        infoAnim.setToX(1);
        infoAnim.setToY(1);
        infoAnim.play();
    }

    private void playConceal() {
        infoAnim.setDelay(Duration.millis(100));
        infoAnim.setFromX(info.getScaleX());
        infoAnim.setFromY(info.getScaleY());
        infoAnim.setToX(0);
        infoAnim.setToY(0);
        infoAnim.play();

        circleAnim.setFromX(circle.getScaleX());
        circleAnim.setFromY(circle.getScaleY());
        circleAnim.setToX(0);
        circleAnim.setToY(0);
        circleAnim.play();
    }
}

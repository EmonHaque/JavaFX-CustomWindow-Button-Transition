package controls;

import javafx.scene.paint.Color;
import javafx.scene.shape.SVGPath;

public class SVGIcon extends SVGPath{

    public SVGIcon(String path) {
        setContent(path);
        setFill(Color.WHITE);
        setScaleX(12 / prefWidth(-1));
        setScaleY(12 / prefHeight(-1));
    }
    public SVGIcon(String path, double size) {
        setContent(path);
        setFill(Color.WHITE);
        setScaleX(size / prefWidth(-1));
        setScaleY(size / prefHeight(-1));
    }
}

package controls;

import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Separator;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.scene.transform.Scale;
import javafx.stage.Popup;
import javafx.util.Duration;
import model.ColumnSeries;

import java.util.List;

public class ColumnStack extends StackPane {
    ColumnSeries series;
    Popup pop;
    VBox content;
    double total, width, height;
    List<Double> values;

    Timeline anim;
    DoubleProperty columnHeight;

    public ColumnStack(ColumnSeries series) {
        getTransforms().add(new Scale(1, -1));
        this.series = series;
        values = series.getValues();
        total = values.stream().mapToDouble(s -> s).sum();

        content = new VBox(new Text(series.getName()), new Separator());
        for (int i = 0; i < values.size(); i++) {
            content.getChildren().add(new Text("Value " + (i + 1) + " is " + String.format("%.2f", values.get(i))));
            var rect = new Region();
            if (i > 0) {
                rect.setBackground(new Background(new BackgroundFill(Color.GREEN, new CornerRadii(0, 0, 10, 10, false), null)));
            }
            else {
                if (values.get(1) == 0) {
                    rect.setBackground(new Background(new BackgroundFill(Color.CORNFLOWERBLUE, new CornerRadii(0, 0, 10, 10, false), null)));
                }
                else {
                    rect.setBackground(new Background(new BackgroundFill(Color.CORNFLOWERBLUE, null, null)));
                }
            }
            getChildren().add(rect);
            rect.setManaged(false);
        }
        content.setPadding(new Insets(10));
        content.setAlignment(Pos.CENTER);
        content.setBackground(new Background(new BackgroundFill(Color.CORAL, new CornerRadii(10), null)));
        pop = new Popup();
        pop.getContent().add(content);

        setOnMouseEntered(this::onMouseEntered);
        setOnMouseExited(this::onMouseExited);

        var clip = new Rectangle();
        layoutBoundsProperty().addListener((observable, oldValue, newValue) -> {
            clip.setWidth(newValue.getWidth());
            clip.setHeight(newValue.getHeight());
        });
        columnHeight = new SimpleDoubleProperty(0);
        setClip(clip);
    }

    public double getTotal() {
        return total;
    }

    public void makeColumn(double width, double height) {
        this.width = width;
        this.height = height;

        columnHeight.addListener((o, ov, nv) -> {
            setHeight(nv.doubleValue());
        });
        var key = new KeyValue(columnHeight, height, Interpolator.EASE_IN);
        var frame = new KeyFrame(Duration.millis(500), key);
        anim = new Timeline(frame);
        anim.setDelay(Duration.millis(500));
        anim.play();
        anim.setOnFinished(e -> setClip(null));
    }

    @Override
    protected void layoutChildren() {
        if (columnHeight.get() == 0)
            return;
        double y = 0;
        for (int i = 0; i < values.size(); i++) {
            var h = height / total * values.get(i);
            var rect = (Region) getChildren().get(i);
            rect.resizeRelocate(0, y, width, h);
            y += h;
        }
    }

    void onMouseEntered(MouseEvent e) {
        var point = localToScreen(width, height);
        // var y = point.getY() - height - content.prefHeight(-1) - 5; // without Scale Transform
        var x = point.getX() - content.prefWidth(-1) / 2 - width / 2;
        var y = point.getY() - content.prefHeight(-1) - 5;
        pop.show(this, x, y);
    }

    void onMouseExited(MouseEvent e) {
        pop.hide();
    }

    void onMouse(MouseEvent e) {
        // System.out.println("Source " + e.getSource() + " Target " + e.getTarget());
        if (e.getEventType() == MouseEvent.MOUSE_ENTERED) {
            var point = localToScreen(0.0, 0.0);
            var x = point.getX() - content.getWidth() / 2 + width / 2;
            var y = point.getY() - height - content.getHeight() - 5;
            pop.show(this, x, y);
        }
        else if (e.getEventType() == MouseEvent.MOUSE_EXITED) {
            pop.hide();
        }
    }
}

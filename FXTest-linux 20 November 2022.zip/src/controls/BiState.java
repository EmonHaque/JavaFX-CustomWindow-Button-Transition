package controls;

import helpers.Icons;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class BiState extends GridPane {
    private SVGIcon icon;
    private Text textLabel;
    private BooleanProperty checkedProperty;

    public BiState(boolean isChecked) {
        icon = new SVGIcon(Icons.CheckCircle);
        icon.setFill(Color.LIGHTGREEN);
        icon.setMouseTransparent(true);
        addColumn(0, icon);
        checkedProperty = new SimpleBooleanProperty();
        checkedProperty.addListener(this::onCheckedChanged);
        checkedProperty.set(isChecked);
        // bound property cannot be modified!
        setOnMouseClicked(e -> checkedProperty.set(!checkedProperty.get()));

        // setFocusTraversable(true);
        // focusVisibleProperty().addListener((o,ov,nv) ->{
        //     System.out.println("old " + ov + " new " + nv);
        // });
    }

    public BiState(boolean isChecked, String text) {
        this(isChecked);
        textLabel = new Text(text);
        textLabel.setFill(Color.WHITE);
        textLabel.setMouseTransparent(true);
        addColumn(1, textLabel);
    }

    private void onCheckedChanged(ObservableValue<?> obs, boolean oldValue, boolean newValue) {
        if (newValue) {
            icon.setContent(Icons.CheckCircle);
            icon.setFill(Color.LIGHTGREEN);
        }
        else {
            icon.setContent(Icons.CloseCircle);
            icon.setFill(Color.LIGHTCORAL);
        }
    }
    
    public void setChecked(boolean value){
        checkedProperty.set(value);
    }

    public StringProperty textProperty() {
        // null if you don't give it text in constructor
        return textLabel.textProperty();
    }

    public BooleanProperty isCheckedProperty() {
        return checkedProperty;
    }
}

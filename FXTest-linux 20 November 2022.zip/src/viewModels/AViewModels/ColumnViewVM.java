package viewModels.AViewModels;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import model.ColumnSeries;

public class ColumnViewVM {
    private char alps[] = {'A', 'B', 'C', 'D', 'E', 'F', 'G'};
    private List<ColumnSeries> series;
    public ObjectProperty<List<ColumnSeries>> seriesProperty;

    public ColumnViewVM() {
        series = List.of(
                new ColumnSeries("A Title", List.of(100d, 200d)),
                new ColumnSeries("B Title", List.of(50d, 100d)),
                new ColumnSeries("C Title", List.of(200d, 30d)),
                new ColumnSeries("D Title", List.of(300d, 0d)),
                new ColumnSeries("E Title", List.of(70d, 30d)));

        seriesProperty = new SimpleObjectProperty<>(series);
        
        PieViewVM.selectedSliceProperty.addListener((o, ov, nv) ->{
            series = nv == null ? null : getSeries();
            seriesProperty.set(series);
        });
    }

    private ArrayList<ColumnSeries> getSeries(){
        var list = new ArrayList<ColumnSeries>();
        var rand = new Random();
        int size = rand.nextInt(4) + 3;
        for(int i = 0; i < size; i++){
            list.add(new ColumnSeries(alps[i] + " Title", List.of(rand.nextDouble(100) + 0, rand.nextDouble(100) + 0)));
        }
        return list;
    }
}

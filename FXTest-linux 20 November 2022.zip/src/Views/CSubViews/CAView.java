package Views.CSubViews;

import abstracts.View;
import helpers.Constants;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import skinned.ExtendedListView;
import templates.Person2Template;
import viewModels.CViewModels.CAViewModel;

public class CAView extends View {
    CAViewModel vm;

    @Override
    protected String getHeader() {
        return "CA View";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight CAView");

        vm = new CAViewModel();

        var header = getTableHeader();
        VBox.setMargin(header, new Insets(0, Constants.ScrollBarSize, 5, 0));
        
        var list = new ExtendedListView<>(vm.people);
        list.setPadding(new Insets(0));
        list.setCellFactory(v -> new Person2Template());

        var box = new VBox();
        VBox.setVgrow(list, Priority.ALWAYS);
        box.getChildren().addAll(header, list);
        setCenter(box);

        CAViewModel.selected.bind(list.getSelectionModel().selectedItemProperty());
    }

    private Node getTableHeader(){
        var header = new GridPane();
        header.setPadding(new Insets(2,0,2,0));
        var name = new SortHeader("Name", false, vm::sortName);
        var age = new SortHeader("Age", true, vm::sortAge);
        var gender = new SortHeader("Gender", true, vm::sortGender);

        header.addColumn(0, name);
        header.addColumn(1, age);
        header.addColumn(2, gender);
        var cons1 = new ColumnConstraints();
        var cons2 = new ColumnConstraints(70);
        cons1.setHgrow(Priority.ALWAYS);

        header.getColumnConstraints().addAll(cons1, cons2, cons2);
        header.setBorder(Constants.BottomLine);
        GridPane.setHalignment(age, HPos.CENTER);
        GridPane.setHalignment(gender, HPos.RIGHT);
        
        return header;
    }
}

package Views.ASubViews;

import abstracts.View;
import controls.Columns;
import viewModels.AViewModels.ColumnViewVM;

public class ColumnView extends View {
    ColumnViewVM vm;

    @Override
    protected String getHeader() {
        return "Column View";
    }
    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight ColumnView");

        vm = new ColumnViewVM();
        var column = new Columns();
        column.seriesProperty.bind(vm.seriesProperty);
        setCenter(column);
    }
}

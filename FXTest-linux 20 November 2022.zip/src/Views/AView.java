package Views;

import java.util.ArrayList;
import java.util.List;

import Views.ASubViews.ColumnView;
import Views.ASubViews.LineView;
import Views.ASubViews.PieView;
import Views.ASubViews.TestControls;
import abstracts.View;
import helpers.Constants;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;

public class AView extends View {

    View testControls, pieView, columnView, lineView;

    public AView() {
        super();
        testControls = new TestControls();
        pieView = new PieView();
        columnView = new ColumnView();
        lineView = new LineView();
    }

    @Override
    protected String getIcon() {
        return Icons.ACircle;
    }

    @Override
    protected String getTip() {
        return "A View";
    }

    @Override
    public boolean isContainer() {
        return true;
    }

    @Override
    public List<View> initialViews() {
        super.views = new ArrayList<>();
        views.add(testControls);
        views.add(pieView);
        views.add(columnView);
        views.add(lineView);
        return super.views;
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight AView");

        var grid = new GridPane();
        grid.add(testControls, 0, 0, 3, 1);
        grid.add(pieView, 0, 1);
        grid.add(columnView, 1, 1);
        grid.add(lineView, 2, 1);

        var colCon = new ColumnConstraints();
        var rowCon = new RowConstraints();
        colCon.setPercentWidth(33.33);
        rowCon.setPercentHeight(50);
        grid.getColumnConstraints().addAll(colCon, colCon, colCon);
        grid.getRowConstraints().addAll(rowCon, rowCon);

        grid.setVgap(Constants.CardMargin);
        grid.setHgap(Constants.CardMargin);
        BorderPane.setMargin(grid, new Insets(Constants.CardMargin));
    
        setCenter(grid);
    }

}

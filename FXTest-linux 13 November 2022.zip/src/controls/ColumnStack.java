package controls;

import javafx.animation.ScaleTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.control.Separator;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import javafx.util.Duration;
import model.ColumnSeries;
import java.util.List;

public class ColumnStack extends Group {
    ColumnSeries series;
    Popup pop;
    VBox content;
    ScaleTransition anim;
    double total, height, width;
    List<Double> values;

    public ColumnStack(ColumnSeries series) {
        this.series = series;
        values = series.getValues();
        total = values.stream().mapToDouble(s -> s).sum();

        content = new VBox(new Text(series.getName()), new Separator());
        for (int i = 0; i < values.size(); i++) {
            content.getChildren().add(new Text("Value " + (i + 1) + " is " + values.get(i)));
            var rect = new Rectangle();
            rect.setWidth(width);
            rect.setHeight(height / total * values.get(i));
            if (i > 0)
                rect.setFill(Color.GREEN);
            else
                rect.setFill(Color.RED);
            getChildren().add(rect);
            rect.setManaged(false);
        }
        content.setPadding(new Insets(10));
        content.setAlignment(Pos.CENTER);
        content.setBackground(new Background(new BackgroundFill(Color.CORAL, new CornerRadii(10), null)));
        pop = new Popup();
        pop.getContent().add(content);

        anim = new ScaleTransition(Duration.millis(1000));
        anim.setNode(this);

        //addEventHandler(MouseEvent.ANY, this::onMouse);
        setOnMouseEntered(this::onMouseEntered);
        setOnMouseExited(this::onMouseExited);
    }

    public double getTotal() {
        return total;
    }

    public void makeColumn(double width, double height) {
        this.height = height;
        this.width = width;
        requestLayout();
    }

    @Override
    protected void layoutChildren() {
        var rects = getChildren().stream().filter(x -> x instanceof Rectangle).map(x -> (Rectangle) x).toList();
        double y = 0;
        for (int i = 0; i < values.size(); i++) {
            rects.get(i).setWidth(width);
            rects.get(i).setHeight(height / total * values.get(i));
            rects.get(i).setY(y);
            y += rects.get(i).getHeight();
        }
    }
    void onMouseEntered(MouseEvent e){
        var point = localToScreen(0.0, 0.0);
        var x = point.getX() - content.getWidth() / 2 + width / 2;
        var y = point.getY() - height - content.getHeight() - 5;
        pop.show(this, x, y);
    }
    void onMouseExited(MouseEvent e){
        pop.hide();
    }
    // void onMouse(MouseEvent e) {
    //     System.out.println("Source " + e.getSource() + " Target " + e.getTarget());
    //     if (e.getEventType() == MouseEvent.MOUSE_ENTERED) {
    //         var point = localToScreen(0.0, 0.0);
    //         var x = point.getX() - content.getWidth() / 2 + width / 2;
    //         var y = point.getY() - height - content.getHeight() - 5;
    //         pop.show(this, x, y);
    //     }
    //     else if (e.getEventType() == MouseEvent.MOUSE_EXITED) {
    //         pop.hide();
    //     }
    // }
}

package helpers;

import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.paint.Color;

public class Constants {
    public static double ScrollBarSize = 10;
    public static Border BottomLine = new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0,0,0.25,0)));
    public static Color BackgroundColor = Color.rgb(50, 50, 50);
    public static Color BackgroundColorLight = Color.rgb(60, 60, 60);
}

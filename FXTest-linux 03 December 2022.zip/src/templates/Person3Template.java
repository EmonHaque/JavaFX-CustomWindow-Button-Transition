package templates;

import controls.texts.HiText;
import helpers.Constants;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.layout.Background;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import model.Person3;

@SuppressWarnings("unused")
public class Person3Template extends ListCell<Person3> {
    private StringProperty query;
    private HBox box;
    private HiText name;
    private Text phone;
    private Region spacer;

    public Person3Template(StringProperty query) {
        this.query = query;
        setBackground(null);
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        //initializeUI();
        //itemProperty().addListener(this::onItemChanged);
    }

    private void initializeUI() {
        name = new HiText();
        phone = new Text();

        phone.setFill(Color.WHITE);
        spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        box = new HBox(name, spacer, phone);
    }

    private void onItemChanged(ObservableValue<?> o, Person3 ov, Person3 nv) {
        if(ov != null){
            phone.textProperty().unbind();
        }
        if (nv != null) {
            name.setText(nv.getName());
            phone.textProperty().bind(nv.phone);
            name.query.set(query.get());
        }
    }

    @Override
    protected void updateItem(Person3 item, boolean empty) {
        super.updateItem(item, empty);
        if (empty) {
            setGraphic(null);
        }
        else {
            name = new HiText(item.getName());
            phone = new Text(item.getPhone());
            name.query.set(query.get());
            phone.setFill(Color.WHITE);
            var spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);
            box = new HBox(name, spacer, phone);

            setGraphic(box);
            setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
        }
    }
}

package templates;

import controls.SVGIcon;
import helpers.Constants;
import helpers.Icons;
import javafx.beans.value.ObservableValue;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.Background;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import model.Tenant;

public class TenantTemplate2 extends TreeCell<Tenant> {
    private SVGIcon expanded, collapsed;
    private StackPane stack;
    private GridPane grid;
    private TextFlow nameFlow;
    private Text name, rent, due, space;

    private TreeItem<Tenant> treeItem;
    private int numLeaf, level;
    private Font normal, bold;

    public TenantTemplate2() {
        setText(null);
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        setBackground(null);
        setPadding(new Insets(0));

        initializeUI();
        itemProperty().addListener(this::onItemChanged);
        hoverProperty().addListener(this::onHover);
    }

    private void initializeUI(){
        expanded = new SVGIcon(Icons.PlusCircle);
        collapsed = new SVGIcon(Icons.MinusCircle);
    
        normal = Font.font(null, FontWeight.NORMAL, -1);
        bold = Font.font(null, FontWeight.BOLD, -1);

        stack = new StackPane();
        grid = new GridPane();

        nameFlow = new TextFlow();
        name = new Text();
        due = new Text();
        rent = new Text();
        space = new Text();

        name.setFill(Color.WHITE);
        due.setFill(Color.WHITE);
        rent.setFill(Color.WHITE);
        space.setFill(Color.WHITE);

        grid.addColumn(0, nameFlow);
        grid.addColumn(1, due);
        grid.addColumn(2, rent);

        GridPane.setValignment(due, VPos.CENTER);
        GridPane.setValignment(rent, VPos.CENTER);

        var cons1 = new ColumnConstraints();
        var cons2 = new ColumnConstraints();
        cons1.setHgrow(Priority.ALWAYS);
        cons2.setPrefWidth(100);
        grid.getColumnConstraints().add(cons1);
        grid.getColumnConstraints().add(cons2);
        grid.getColumnConstraints().add(cons2);
        GridPane.setHalignment(due, HPos.RIGHT);
        GridPane.setHalignment(rent, HPos.RIGHT);
    }

    private void onHover(ObservableValue<?> o, boolean ov, boolean nv){
        if (nv && !isEmpty()) {
            if (!isSelected())
                setBackground(Background.fill(Constants.BackgroundColorLight));
        }
        else {
            if (!isSelected())
                setBackground(null);
        }
    }

    private void onItemChanged(ObservableValue<?> o, Tenant ov, Tenant nv){
        if(ov != null){
            setDisclosureNode(null);
            stack.getChildren().clear();
            nameFlow.getChildren().clear();
        }
        if(nv != null){
            treeItem = getTreeView().getTreeItem(getIndex());
            level = getTreeView().getTreeItemLevel(treeItem);
            numLeaf = treeItem.getChildren().size();
            setDisclosureNode(treeItem.isExpanded() ? expanded : collapsed);

            rent.setText(String.format("%,d", nv.getRent()));
            due.setText(String.format("%,.2f", nv.getDue()));
            
            if (level == 3) {
                name.setText(nv.getSpace());
                name.setFont(normal);
                rent.setFont(normal);
                due.setFont(normal);
            }
            else if (level == 2) {
                name.setText(nv.getTenant());
                name.setFont(bold);
                rent.setFont(bold);
                due.setFont(bold);
    
                double borderWidth = 0.25;
                if (numLeaf == 0) {
                    if (!nv.getSpace().isEmpty()) {
                        space.setText(" - " + nv.getSpace());
                        nameFlow.getChildren().add(space);
                        borderWidth = 0;
                    }
                    else {
                        nameFlow.getChildren().remove(space);
                    }
                }
                stack.setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, null, new BorderWidths(0, 0, borderWidth, 0))));
                stack.getChildren().add(grid);
            }
            else {
                name.setText(nv.getHouse());
                name.setFont(bold);
                rent.setFont(bold);
                due.setFont(bold);
                stack.setBorder(Constants.BottomLine);
                stack.getChildren().add(grid);
            }
            nameFlow.getChildren().add(name);
        }
    }

    @Override
    protected void updateItem(Tenant item, boolean empty) {
        super.updateItem(item, empty);
        if (empty) {
            setGraphic(null);
        }
        else {     
            setGraphic(level == 3 ? grid : stack);
            setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
        }
    }
}

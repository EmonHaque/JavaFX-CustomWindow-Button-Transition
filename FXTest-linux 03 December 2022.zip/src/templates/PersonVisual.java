package templates;

import controls.texts.HiText;
import interfaces.ISetContent;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import model.Person;

public class PersonVisual extends HBox implements ISetContent<Person> {
    HiText name;
    Text phone;
    Region spacer;

    public PersonVisual() {
        name = new HiText();
        spacer = new Region();
        phone = new Text();

        phone.setFill(Color.WHITE);
        HBox.setHgrow(spacer, Priority.ALWAYS);
        // doesn't center name HiText
        setAlignment(Pos.CENTER);
        getChildren().addAll(new Group(name), spacer, phone);
    }

    public void setContent(Person p) {
        name.setText(p.name);
        phone.setText(p.phone);
    }

    public HiText getHiText() {
        return name;
    }

    @Override
    public HBox getVisual() {
        return this;
    }
}

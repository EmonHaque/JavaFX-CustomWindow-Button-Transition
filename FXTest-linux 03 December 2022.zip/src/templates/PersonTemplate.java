package templates;

import helpers.Constants;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import model.Person;

@SuppressWarnings("unused")
public class PersonTemplate extends ListCell<Person> {
    public StringProperty query;
    private PersonVisual visual;

    public PersonTemplate(StringProperty query) {
        this.query = query;
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        setBackground(null);
        //initializeUI();
        //itemProperty().addListener(this::onItemChanged);
        hoverProperty().addListener(this::onHover);
    }
   
    private void initializeUI(){
        visual = new PersonVisual();
    }

    private void onHover(ObservableValue<?> o, boolean ov, boolean nv){
        if (nv && !isEmpty()) {
            if(!isSelected())
                setBackground(new Background(new BackgroundFill(Constants.BackgroundColorLight, null, null)));
        } else {
            if(!isSelected())
                setBackground(null);
        }
    }

    private void onItemChanged(ObservableValue<?> o, Person ov, Person nv){
        if(nv != null){
            visual.setContent(nv);
            visual.getHiText().query.bind(query);
        }
    }

    @Override
    protected void updateItem(Person item, boolean empty) {
        super.updateItem(item, empty);
        if (empty) {
            setGraphic(null);
        }
        else {
            visual = new PersonVisual();
            visual.setContent(item);
            visual.getHiText().query.set(query.get());

            setGraphic(visual);
            setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
        }
    }
}

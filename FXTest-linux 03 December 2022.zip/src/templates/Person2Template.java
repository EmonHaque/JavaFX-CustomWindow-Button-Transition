package templates;

import controls.states.BiState;
import helpers.Constants;
import javafx.beans.binding.StringBinding;
import javafx.beans.value.ObservableValue;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.layout.Background;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import model.Person2;

public class Person2Template extends ListCell<Person2> {
    private GridPane grid;
    private Text name, age;
    private BiState gender;

    public Person2Template() {
        setPadding(new Insets(1,0,1,0));
        setBackground(null);
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);

        initializeUI();
        itemProperty().addListener(this::onItemChanged);
    }

    private void initializeUI(){
        name = new Text();
        age = new Text();
        gender = new BiState(true, "is male");
        name.setFill(Color.WHITE);
        age.setFill(Color.WHITE);

        grid = new GridPane();
        grid.addColumn(0, name);
        grid.addColumn(1, age);
        grid.addColumn(2, gender);

        grid.setMouseTransparent(true);

        var cons1 = new ColumnConstraints();
        var cons2 = new ColumnConstraints(70);
        cons1.setHgrow(Priority.ALWAYS);
        grid.getColumnConstraints().addAll(cons1, cons2, cons2);
        GridPane.setHalignment(age, HPos.CENTER);
        GridPane.setHalignment(gender, HPos.RIGHT);
    }

    private void onItemChanged(ObservableValue<?> o, Person2 ov, Person2 nv){
        if(ov != null){
            name.textProperty().unbind();
            age.textProperty().unbind();
            gender.isCheckedProperty().unbind();
        }
        if(nv != null){
            name.textProperty().bind(nv.name);
            age.textProperty().bind(new StringBinding() {
                { bind(nv.age); }
                @Override
                protected String computeValue() {
                    return String.valueOf(nv.age.get());
                }
            });
            gender.isCheckedProperty().bind(nv.isMale);
        }
    }

    @Override
    protected void updateItem(Person2 item, boolean empty) {
        super.updateItem(item, empty);
        if (empty) {
            setGraphic(null);
        }
        else {
            setGraphic(grid);
            setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
        }
    }
}

package controls.texts;

import java.util.ArrayList;
import java.util.List;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.paint.Color;
import javafx.scene.text.*;

public class HiText extends TextFlow {
    public StringProperty query;
    private List<Text> items;
    private Text item;

    public HiText() {
        // doesn't align Text vertically center
        query = new SimpleStringProperty();
        query.addListener(this::changed);
    }

    public HiText(String text) {
        this();
        checkAndCreateItem();
        item.setText(text);
    }

    public void setText(String text) {
        checkAndCreateItem();
        item.setText(text);
    }

    public void add(Text node) {
        if (items == null) {
            items = new ArrayList<>();
        }
        items.add(node);
        getChildren().add(node);
    }

    public void remove(Text node) {
        items.remove(node);
        getChildren().remove(node);
    }

    public void clear() {
        if (items != null) {
            items.clear();
        }
        getChildren().clear();
    }

    private void checkAndCreateItem() {
        if (item == null) {
            item = new Text();
            item.setFill(Color.WHITE);
            getChildren().add(item);
        }
    }

    private void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
        getChildren().clear();
        if (newValue == null || newValue.isEmpty() || newValue.isBlank()) {
            if (item != null) {
                getChildren().add(item);
            }
            else {
                getChildren().addAll(items);
            }
            return;
        }

        if (item != null) {
            int index = 0;
            var filter = query.get().toLowerCase();
            int filterLength = filter.length();

            var content = item.getText();
            var text = content.toLowerCase();

            for (int i = text.indexOf(filter); i > -1; i = text.indexOf(filter, i + 1)) {
                var unmatchedContent = content.substring(index, i);
                if (unmatchedContent.length() > 0) {
                    var unmatched = new Text(unmatchedContent);
                    unmatched.setFill(Color.WHITE);
                    getChildren().add(unmatched);
                }
                var match = new Text(content.substring(i, i + filterLength));
                match.setFont(Font.font(null, FontWeight.BOLD, -1));
                match.setFill(Color.CORNFLOWERBLUE);

                match.setUnderline(true);
                getChildren().add(match);
                index = i + filterLength;
            }
            if (index < text.length()) {
                var unmatched = new Text(content.substring(index));
                unmatched.setFill(Color.WHITE);
                getChildren().add(unmatched);
            }
        }
        else {
            for (var segment : items) {
                int index = 0;
                var filter = query.get().toLowerCase();
                int filterLength = filter.length();
                var text = segment.getText().toLowerCase();
                for (int i = text.indexOf(filter); i > -1; i = text.indexOf(filter, i + 1)) {
                    var unmatchedContent = segment.getText().substring(index, i);
                    if (unmatchedContent.length() > 0) {
                        var unmatched = new Text(unmatchedContent);
                        unmatched.setFill(Color.WHITE);
                        unmatched.setFont(segment.getFont());
                        getChildren().add(unmatched);
                    }
                    var match = new Text(segment.getText().substring(i, i + filterLength));
                    match.setFill(Color.CORNFLOWERBLUE);
                    match.setFont(Font.font(null, FontWeight.BOLD, 12));
                    match.setUnderline(true);
                    getChildren().add(match);
                    index = i + filterLength;
                }
                if (index < text.length()) {
                    var unmatched = new Text(segment.getText().substring(index));
                    unmatched.setFill(Color.WHITE);
                    unmatched.setFont(segment.getFont());
                    getChildren().add(unmatched);
                }
            }
        }
    }
}

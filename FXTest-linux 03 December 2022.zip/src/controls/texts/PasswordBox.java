package controls.texts;

import abstracts.HintedControlBase;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.PasswordField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Priority;
import skinned.ExtendedPasswordField;

public class PasswordBox extends HintedControlBase {
    protected PasswordField input;
    public StringProperty textProperty;

    public PasswordBox(String hint, String icon) {
        super(hint, icon);
        input = new ExtendedPasswordField();
        input.setMouseTransparent(true);

        add(input, 1, 0);
        setHgrow(input, Priority.ALWAYS);
        textProperty = input.textProperty();

        addEventHandler(MouseEvent.ANY, this::onMouseEvents);
        input.focusedProperty().addListener(this::onFocusChanged);
        input.textProperty().addListener(this::onTextChanged);
    }

    private void onMouseEvents(MouseEvent e) {
        if (e.getEventType() == MouseEvent.MOUSE_ENTERED) {
            input.requestFocus();
            input.selectEnd();
        }
        else if (e.getEventType() == MouseEvent.MOUSE_EXITED) {
            leftIcon.requestFocus();
        }
    }

    protected void onTextChanged(ObservableValue<?> observable, String oldValue, String newValue) {
        if (textIsNullOrEmpty(newValue)) {
            if (isHintMoved && !input.isFocused()) {
                moveHintDown();
            }
        }
        else {
            if (!isHintMoved) {
                moveHintUp();
            }
        }
    }

    protected void onFocusChanged(ObservableValue<?> observable, Boolean oldValue, Boolean newValue) {
        if (newValue) {
            setFocusColor();
            if (!isHintMoved)
                moveHintUp();
        }
        else {
            resetFocusColor();
            if (textIsNullOrEmpty(input.getText())) {
                if (isHintMoved)
                    moveHintDown();
            }
        }
    }

    protected boolean textIsNullOrEmpty(String text) {
        return text == null || text.isEmpty() || text.isBlank();
    }

    public String getText() {
        return input.getText();
    }

    public void setText(String value) {
        input.setText(value);
    }
}

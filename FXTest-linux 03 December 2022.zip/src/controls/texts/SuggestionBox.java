package controls.texts;

import java.lang.reflect.InvocationTargetException;

import helpers.Constants;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.Point2D;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.control.SelectionMode;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;
import javafx.scene.shape.Path;
import javafx.stage.Popup;
import skinned.ExtendedResizableListView;

public class SuggestionBox<T> extends TextBox {
    private FilteredList<T> filteredList;
    private ExtendedResizableListView<T> listView;
    private Popup popup;
    private String property;
    private boolean isTabOrEnter;

    public SuggestionBox(String hint, String icon, ObservableList<T> list, String property, String template) {
        super(hint, icon);
        this.property = property;
        filteredList = new FilteredList<>(list, this::filter);

        listView = new ExtendedResizableListView<T>(filteredList);
        listView.setBorder(Constants.BottomLine);
        listView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        listView.setMaxHeight(200);
        listView.setBackground(Background.fill(Constants.BackgroundColor));
        listView.setBorder(new Border(new BorderStroke(Color.WHITE, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(0.25))));

        if (template != null) {
            setCells(template);
        }
        else {
            listView.setCellFactory(v -> new ListCell<T>() {
                {
                    setBackground(null);
                    setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
                }
                
                @Override
                protected void updateItem(T item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setGraphic(null);
                    }
                    else {
                        var hiText = new HiText(item.toString());
                        hiText.query.set(input.getText());
                        setGraphic(hiText);
                        setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
                    }
                }
            });
        }

        popup = new Popup();
        popup.getContent().add(listView);
        //popup.setHideOnEscape(true);

        // listView.setOnKeyPressed(this::onKeyPressed);
        listView.addEventFilter(KeyEvent.KEY_PRESSED, this::onKeyPressed);
    }

    @SuppressWarnings("unchecked")
    private void setCells(String template) {
        try {
            var tor = Class.forName(template).getConstructor(StringProperty.class);
            listView.setCellFactory(v -> {
                try {
                    return (ListCell<T>) tor.newInstance(input.textProperty());
                }
                catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
                    e.printStackTrace();
                }
                return null;
            });
        }
        catch (ClassNotFoundException | NoSuchMethodException | SecurityException e) {
            e.printStackTrace();
        }
    }

    private void onKeyPressed(KeyEvent e) {
        var key = e.getCode();
        if (key == KeyCode.ENTER || key == KeyCode.TAB) {
            if (!popup.isShowing()) {
                return;
            }
            isTabOrEnter = true;
            popup.hide();
            input.requestFocus();
            var item = listView.getSelectionModel().getSelectedItem();
            if(item == null){
                item = listView.getItems().get(0);
            }
            if (item instanceof String) {
                input.setText(item.toString());
                input.end();
            }
            else {
                try {
                    var getter = item.getClass().getMethod("get" + property);
                    var name = getter.invoke(item).toString();
                    input.setText(name);
                    input.end();
                }
                catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e1) {
                    e1.printStackTrace();
                }
            }
        }
    }

    @Override
    protected void onTextChanged(ObservableValue<?> observable, String oldValue, String newValue) {
        if (isTabOrEnter) {
            isTabOrEnter = false;
            return;
        }
        super.onTextChanged(observable, oldValue, newValue);
        if (newValue != null && !newValue.isEmpty() && !newValue.isBlank()) {
            Path caret = findCaret(input);
            Point2D screenLoc = findScreenLocation(caret);
            filteredList.setPredicate(this::filter);
            if (filteredList.size() > 0) {
                if(!popup.isShowing()){
                    popup.show(input, screenLoc.getX(), screenLoc.getY() + 20);
                }
                else{
                    popup.setX(screenLoc.getX());
                    popup.setY(screenLoc.getY() + 20);
                }
            }
            else{
                popup.hide();
            }
        }
        else{
            filteredList.setPredicate(p -> true);
        }
    }

    @Override
    protected void onFocusChanged(ObservableValue<?> observable, Boolean oldValue, Boolean newValue) {
        super.onFocusChanged(observable, oldValue, newValue);
        if (popup.isShowing()) {
            popup.hide();
        }
    }

    private boolean filter(T item) {
        boolean result = false;
        if (item instanceof String) {
            result = ((String) item).toLowerCase().contains(input.getText().toLowerCase());
        }
        else {
            try {
                var getter = item.getClass().getMethod("get" + property);
                var name = getter.invoke(item).toString();
                result = name.toLowerCase().contains(input.getText().toLowerCase());
            }
            catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
                e.printStackTrace();
                result = true;
            }
        }
        return result;
    }

    // https://community.oracle.com/tech/developers/discussion/2534556/how-to-get-caret-screen-coordinates-in-textarea

    private Point2D findScreenLocation(Node node) {
        // double x = 0;
        // double y = 0;
        // for (Node n = node; n != null; n = n.getParent()) {
        //     var parentBounds = n.getBoundsInParent();
        //     x += parentBounds.getMinX();
        //     y += parentBounds.getMinY();
        // }
        // var scene = node.getScene();
        // x += scene.getX();
        // y += scene.getY();
        // var window = scene.getWindow();
        // x += window.getX();
        // y += window.getY();
        // Point2D screenLoc = new Point2D(x, y);
        // return screenLoc;

        return node.localToScreen(new Point2D(0, 0));       
    }

    private Path findCaret(final Parent parent) {
        // Warning: this is an ENORMOUS HACK
        for (Node n : parent.getChildrenUnmodifiable()) {
            if (n instanceof Path) {
                return (Path) n;
            }
            else if (n instanceof Parent) {
                Path p = findCaret((Parent) n);
                if (p != null) {
                    return p;
                }
            }
        }
        return null;
    }
}

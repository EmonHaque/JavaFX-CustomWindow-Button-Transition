package viewModels.EViewModels.ECAViewModels;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import model.Tenant;

public class ECAViewVM {
    public ObjectProperty<Tenant> tenantProperty;

    public ECAViewVM() {
        tenantProperty = new SimpleObjectProperty<>();
        tenantProperty.addListener((o, ov, nv) ->{
            
        });
    }
}

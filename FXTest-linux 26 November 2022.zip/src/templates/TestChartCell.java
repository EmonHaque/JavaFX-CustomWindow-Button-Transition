package templates;

import controls.HiText;
import controls.HorizontalListChart;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.control.Separator;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import model.HorizontalSeries;

public class TestChartCell extends StackPane {
    private HiText text;
    private Rectangle value1, value2;
    private Line value3;
    private Circle ball;
    private HorizontalSeries item, previous;
    private double percentOfChartArea, topBottomPadding, topMax, bottomMax;

    private Popup pop;
    private VBox content;

    private HorizontalListChart chart;

    public TestChartCell(HorizontalSeries item, HorizontalSeries previous, double percentOfChartArea, double topBottomPadding, double topMax, double bottomMax) {
        this.item = item;
        this.previous = previous;
        this.percentOfChartArea = percentOfChartArea;
        this.topBottomPadding = topBottomPadding;
        this.topMax = topMax;
        this.bottomMax = bottomMax;

        text = new HiText();

        value1 = new Rectangle();
        value2 = new Rectangle();
        ball = new Circle();
        ball.setRadius(3);
        ball.setFill(Color.CORAL);

        if (previous != null) {
            value3 = new Line();
            value3.setStroke(Color.WHITE);
            value3.setStrokeWidth(1);
            value3.setManaged(false);
            value3.setMouseTransparent(true);
            getChildren().add(value3);
        }

        text.setContent(item.getTitle());
        value1.setFill(Color.GRAY);
        value2.setFill(Color.GREEN);
        value1.setOpacity(0.2);
        value2.setOpacity(0.2);

        text.setManaged(false);
        value1.setManaged(false);
        value2.setManaged(false);
        ball.setManaged(false);

        text.setMouseTransparent(true);
        value1.setMouseTransparent(true);
        value2.setMouseTransparent(true);
        ball.setMouseTransparent(true);

        getChildren().addAll(text, value1, value2, ball);

        content = new VBox(new Text(item.getTitle()), new Separator());
        content.setPadding(new Insets(10));
        content.setAlignment(Pos.CENTER);
        content.setBackground(new Background(new BackgroundFill(Color.CORAL, new CornerRadii(10), null)));
        content.getChildren().add(new Text("Value 1 is " + String.format("%.1f", item.getValue1())));
        content.getChildren().add(new Text("Value 2 is " + String.format("%.1f", item.getValue2())));
        content.getChildren().add(new Text("Value 3 is " + String.format("%.1f", item.getValue3())));
        pop = new Popup();
        pop.getContent().add(content);

        setOnMouseEntered(this::onMouseEntered);
        setOnMouseExited(this::onMouseExited);
    }

    void onMouseEntered(MouseEvent e) {
        var point = localToScreen(e.getX(), e.getY());
        var x = point.getX() - content.prefWidth(-1) / 2;
        var y = point.getY() - content.prefHeight(-1) - 15;
        pop.show(this, x, y);

        setBackground(new Background(new BackgroundFill(Color.rgb(100, 100, 100, 0.3), null, null)));
    }

    void onMouseExited(MouseEvent e) {
        pop.hide();
        setBackground(null);
    }

    @Override
    protected void layoutChildren() {
        if (chart == null) {
            var instance = getParent();
            while(!(instance instanceof HorizontalListChart)){
                instance = instance.getParent();
            }
            chart = (HorizontalListChart) instance;
            text.query.bind(chart.queryProperty);
        }
        
        double width = getWidth();
        double height = getHeight();
        double paddedHeight = height - 2 * topBottomPadding;

        double startX = width * (1 - percentOfChartArea);
        var chartArea = width - startX;
        double total = item.getValue1() + item.getValue2();
        var totalWidth = chartArea / topMax * total;
        var value1Width = item.getValue1() / total * totalWidth;
        var value2Width = item.getValue2() / total * totalWidth;

        value1.setX(startX);
        value1.setY(topBottomPadding);
        value1.setHeight(paddedHeight);
        value1.setWidth(value1Width);

        value2.setX(startX + value1.getWidth());
        value2.setY(topBottomPadding);
        value2.setHeight(paddedHeight);
        value2.setWidth(value2Width);
        layoutInArea(text, 0, topBottomPadding, startX, paddedHeight, 0, HPos.LEFT, VPos.CENTER);

        // positionInArea(value1, startX, topBottomPadding, value1Width, paddedHeight,
        // 0, HPos.LEFT, VPos.CENTER);
        // positionInArea(value2, startX + value1Width, topBottomPadding, value2Width,
        // paddedHeight, 0, HPos.LEFT, VPos.CENTER);

        // positionInArea(value1, startX, topBottomPadding, value1Width, paddedHeight,
        // 0, HPos.LEFT, VPos.CENTER);
        // positionInArea(value2, startX + value1Width, topBottomPadding, value2Width,
        // paddedHeight, 0, HPos.LEFT, VPos.CENTER);

        var x2 = startX + item.getValue3() / bottomMax * chartArea;
        var y2 = height / 2;
        ball.setCenterX(x2);
        ball.setCenterY(y2);
        if (previous != null) {
            var prevText = new Text(previous.getTitle());
            prevText.setWrappingWidth(startX);
            var prevHeight = prevText.prefHeight(-1) + 2 * topBottomPadding;

            var x1 = startX + previous.getValue3() / bottomMax * chartArea;

            var y1 = -prevHeight / 2;

            value3.setStartX(x1);
            value3.setEndX(x2);
            value3.setStartY(y1);
            value3.setEndY(y2);
        }

    }
}

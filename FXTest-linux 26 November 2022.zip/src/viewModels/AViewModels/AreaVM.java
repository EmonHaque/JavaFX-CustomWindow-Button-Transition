package viewModels.AViewModels;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;

public class AreaVM {
    private List<Double> series;
    public ObjectProperty<List<Double>> seriesProperty;
    
    public AreaVM() {
        series = List.of(50.0, 100.0, 200.0, 150.0, 120.0, 60.0, 90.0);
        seriesProperty = new SimpleObjectProperty<>(series);

        PieViewVM.selectedSliceProperty.addListener((o, ov, nv) ->{
            series = nv == null ? null : getSeries();
            seriesProperty.set(series);
        });
    }

    private ArrayList<Double> getSeries(){
        var list = new ArrayList<Double>();
        var rand = new Random();
        int size = rand.nextInt(7) + 8;
        for(int i = 0; i < size; i++){
            list.add(rand.nextDouble(300) + 20);
        }
        return list;
    }
}

package viewModels.GViewModels;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class GService {
    private static ExecutorService executor;

    public GService() {
        executor = Executors.newSingleThreadExecutor();
    }

    public static Future<String> execute(String arg) {
        var result = executor.submit(new Callable<String>() {

            @Override
            public String call() throws Exception {
                Thread.sleep(2000);
                return "Modified " + arg;
            }
            
        });
        return result;
    }

    public static void shutDown(){
        executor.shutdown();
    }
}

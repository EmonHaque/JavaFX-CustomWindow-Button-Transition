package viewModels.GViewModels;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class GService {
    private static ExecutorService executor;

    public GService() {
        executor = Executors.newSingleThreadExecutor();
    }

    public static Future<String> execute(String arg) {
        return executor.submit(() -> {
            Thread.sleep(2000);
            return "Modified " + arg;
        });
    }

    public static void shutDown() {
        executor.shutdown();
    }
}

package controls.pinchart;

import java.util.ArrayList;
import java.util.List;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.layout.Region;
import model.PinColumnSeries;

public class PinColumns extends Region {
    private double yMax, height, width;
    private List<PinColumnSeries> series;
    private List<PinColumn> pins;

    public ObjectProperty<List<PinColumnSeries>> seriesProperty;

    public PinColumns() {
        pins = new ArrayList<>();
        seriesProperty = new SimpleObjectProperty<>();
        seriesProperty.addListener(this::onSeriesChanged);
    }

    private void onSeriesChanged(ObservableValue<?> obs, List<PinColumnSeries> ov, List<PinColumnSeries> nv) {
        for (var n : pins) {
            getChildren().remove(n);
        }
        pins.clear();
        if (nv == null) {

        }
        else {
            series = nv;
            yMax = 0;
            for (var s : series) {
                if (yMax < s.getPin())
                    yMax = s.getPin();
                if (yMax < s.getColumn())
                    yMax = s.getColumn();

                var pin = new PinColumn(s);
                pin.setManaged(false);
                getChildren().add(pin);
                pins.add(pin);
            }
        }
    }

    @Override
    protected void layoutChildren() {
        width = getWidth();
        height = getHeight();
        double gap = 5;
        double availableWidth = width - gap * series.size();
        var colWidth = availableWidth / series.size();
        double x = 0;
        for (var p : pins) {
            p.makePin(colWidth, height, yMax);
            p.resizeRelocate(x, height, colWidth, height);
            x += colWidth + gap;
        }
    }
}

package model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Tenant {
    public StringProperty houseProperty;
    public StringProperty tenantProperty;
    public StringProperty spaceProperty;
    public IntegerProperty rentProperty;
    public IntegerProperty dueProperty;

    public Tenant(){
        houseProperty = new SimpleStringProperty();
        tenantProperty = new SimpleStringProperty();
        spaceProperty = new SimpleStringProperty();
        rentProperty = new SimpleIntegerProperty();
        dueProperty = new SimpleIntegerProperty();
    }

    public Tenant(String house, String tenant, String space, int rent, int due) {
        houseProperty = new SimpleStringProperty(house);
        tenantProperty = new SimpleStringProperty(tenant);
        spaceProperty = new SimpleStringProperty(space);
        rentProperty = new SimpleIntegerProperty(rent);
        dueProperty = new SimpleIntegerProperty(due);
    }

    @Override
    public String toString() {
        return "House: " + houseProperty.get() +
                " Tenant: " + tenantProperty.get() +
                " Space: " + spaceProperty.get() +
                " Rent: " + rentProperty.get() +
                " Due: " + dueProperty.get();
    }
}

package skinned;

import javafx.scene.control.Skin;
import javafx.scene.control.TextField;
import skins.ExtendedTextFieldSkin;

public class ExtendedTextField extends TextField {
    public ExtendedTextField() {
        super();
        setBackground(null);
    }
    @Override
    protected Skin<?> createDefaultSkin() {
        return new ExtendedTextFieldSkin(this);
    }
}

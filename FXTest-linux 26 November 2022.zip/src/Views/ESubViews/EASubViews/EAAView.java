package Views.ESubViews.EASubViews;

import abstracts.View;
import controls.ActionButton;
import controls.TextBox;
import helpers.Icons;
import javafx.beans.binding.Bindings;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.util.StringConverter;
import viewModels.EViewModels.EAAViewModels.EAAViewVM;

public class EAAView extends View {
    TextBox houseText, tenantText, spaceText, rentText, dueText;
    ActionButton add;
    EAAViewVM vm;

    @Override
    protected String getHeader() {
        return "EAA View";
    }

    @Override
    protected String getIcon() {
        return Icons.ACircle;
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight EAA View");

        vm = new EAAViewVM();
        initializeUI();
        bind();
    }

    private void initializeUI() {
        houseText = new TextBox("House", Icons.Building);
        tenantText = new TextBox("Tenant", Icons.User);
        spaceText = new TextBox("Space", Icons.Home);
        rentText = new TextBox("Rent", Icons.Transact);
        dueText = new TextBox("Due", Icons.Transact);
        add = new ActionButton(Icons.Add, 16, "add");

        var amountBox = new HBox(rentText, dueText);
        HBox.setHgrow(rentText, Priority.ALWAYS);
        HBox.setHgrow(dueText, Priority.ALWAYS);
        amountBox.setSpacing(10);
        
        var box = new VBox(houseText, tenantText, spaceText, amountBox, add);
        box.setAlignment(Pos.CENTER_RIGHT);
        box.setSpacing(5);
        box.setPadding(new Insets(5, 0, 0, 0));
        VBox.setMargin(add, new Insets(10, 0, 0, 0));
        setCenter(box);
    }

    private void bind() {
        houseText.textProperty.bindBidirectional(vm.tenant.houseProperty);
        tenantText.textProperty.bindBidirectional(vm.tenant.tenantProperty);
        spaceText.textProperty.bindBidirectional(vm.tenant.spaceProperty);

        Bindings.bindBidirectional(rentText.textProperty, vm.tenant.rentProperty, new StringConverter<Number>() {
            @Override
            public Number fromString(String s) {
                if (s == null || s.isEmpty() || s.isBlank())
                    return 0;
                else{
                    try {
                        return Integer.parseInt(s);
                    } catch (Exception e) {
                       return 0;
                    }
                }
            }

            @Override
            public String toString(Number n) {
                return n.intValue() == 0 ? "" : n.toString();
            }

        });
        Bindings.bindBidirectional(dueText.textProperty, vm.tenant.dueProperty, new StringConverter<Number>() {
            @Override
            public Number fromString(String s) {
                if (s == null || s.isEmpty() || s.isBlank())
                    return 0;
                else{
                    try {
                        return Integer.parseInt(s);
                    } catch (Exception e) {
                       return 0;
                    }
                }
            }

            @Override
            public String toString(Number n) {
                return n.intValue() == 0 ? "" : n.toString();
            }

        });

        add.setAction(vm::addTenant);
    }
}

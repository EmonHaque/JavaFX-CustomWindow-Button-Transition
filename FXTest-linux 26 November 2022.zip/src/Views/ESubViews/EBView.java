package Views.ESubViews;

import abstracts.View;
import helpers.Icons;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

public class EBView extends View {

    @Override
    protected String getIcon() {
        return Icons.BSquare;
    }

    @Override
    protected String getHeader() {
        return "EB View";
    }

    @Override
    protected String getTip() {
        return "EB View";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight EB View");
        var label = new Label("Test EB");
        label.setTextFill(Color.WHITE);
        var box = new VBox(label);
        setCenter(box);
    }
    
}

package Views.ESubViews.EBSubViews;

import abstracts.View;
import helpers.Icons;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import model.Tenant;
import viewModels.EViewModels.EBAViewModels.EBAViewVM;

public class EBAView extends View {
    TreeView<Tenant> tree;
    TreeItem<Tenant> houses, tenants, spaces;
    EBAViewVM vm;

    @Override
    protected String getHeader() {
        return "EBA View";
    }

    @Override
    protected String getIcon() {
        return Icons.ACircle;
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight EBA View");

        vm = new EBAViewVM();
    }
}

package Views.GSubViews;

import java.util.concurrent.ExecutionException;

import abstracts.View;
import controls.ActionButton;
import helpers.Icons;
import javafx.application.Platform;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import viewModels.GViewModels.GService;

public class GEView extends View {
    private Label label;
    private int count;

    @Override
    protected String getHeader() {
        return "GE View";
    }
    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight GE View");

        var button = new ActionButton(Icons.Reload, 16, "request");
        button.setAction(this::request);
        addAction(button);

        label = new Label("Test");
        label.setTextFill(Color.WHITE);
        setCenter(label);

        request();
    }

    private void request(){
        count++;
        label.setText("waiting ... " + count);
        var future = GService.execute("From GE " + count);
        new Thread(() ->{
            try {
                var str = future.get();
                Platform.runLater(() -> label.setText(str));
            }
            catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
            
        }).start();
    }
}

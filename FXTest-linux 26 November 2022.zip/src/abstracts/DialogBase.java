package abstracts;

import helpers.Constants;
import javafx.animation.Interpolator;
import javafx.animation.ScaleTransition;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.WindowEvent;
import javafx.util.Duration;

// In WPF, I've a BusyDialog that's a Dispatcher and animates on a different thread
// How do you start Dialog and animation on it on a Different thread in JavaFX?

public class DialogBase extends Stage {
    protected BorderPane root;
    protected StackPane titlePane;
    protected GridPane buttonsPane;
    protected Label titlelabel;

    public DialogBase() {
        initStyle(StageStyle.TRANSPARENT);
        initModality(Modality.APPLICATION_MODAL);
        //setResizable(false);

        var radius = Constants.CardRadius;
        root = new BorderPane();

        titlePane = new StackPane();
        buttonsPane = new GridPane();

        root.setBackground(new Background(new BackgroundFill(Color.rgb(0, 0, 0, 0.5), new CornerRadii(radius, false), null)));
        titlePane.setBackground(new Background(new BackgroundFill(Color.rgb(0, 0, 1), new CornerRadii(radius, radius, 0, 0, false), null)));
        buttonsPane.setBackground(new Background(new BackgroundFill(Color.rgb(0, 0, 1), new CornerRadii(0, 0, radius, radius, false), null)));

        root.setTop(titlePane);
        root.setBottom(buttonsPane);

        titlelabel = new Label();
        titlelabel.setFont(Font.font(null, FontWeight.BOLD, -1));
        titlelabel.setTextFill(Color.WHITE);
        StackPane.setMargin(titlelabel, new Insets(10, 0, 10, 0));
        titlePane.getChildren().add(titlelabel);

        setOnShown(this::animateShow);
    }

    public void showDialog(double width, double height) {
        var scene = new Scene(root, width, height);
        scene.setFill(Color.TRANSPARENT);
        setScene(scene);
    }

    public void closeDialog(){
        var animation = new ScaleTransition(Duration.millis(500), root);
        animation.setInterpolator(Interpolator.EASE_IN);
        animation.setFromX(1);
        animation.setFromY(1);
        animation.setToX(0);
        animation.setToY(0);
        animation.play();
        animation.setOnFinished(e -> close());
    }

    private void animateShow(WindowEvent e){
        var animation = new ScaleTransition(Duration.millis(500), root);
        animation.setInterpolator(Interpolator.EASE_IN);
        animation.setFromX(0);
        animation.setFromY(0);
        animation.setToX(1);
        animation.setToY(1);
        animation.play();
    }
}

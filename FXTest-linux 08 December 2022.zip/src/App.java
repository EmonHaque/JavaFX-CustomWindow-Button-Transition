import Views.*;
import controls.LoadingWindow;
import controls.MainPanel;
import controls.Window;
import javafx.application.Application;
import javafx.concurrent.Task;
import javafx.concurrent.Worker;
import javafx.stage.Stage;
import viewModels.GViewModels.GService;

public class App extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        var loading = new LoadingWindow();
        loading.show();
        var task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                for(int i = 0; i < 3; i++){
                    updateMessage("Loading ... " + (i + 1));
                    Thread.sleep(3333);
                }
                return null;
            }
        };
        loading.messageProperty.bind(task.messageProperty());
        task.stateProperty().addListener((o, ov, nv) -> {
            if (nv == Worker.State.SUCCEEDED) {
                launchMain(stage);
                loading.close();
            }
        });
        new Thread(task).start();
    }

    private void launchMain(Stage stage){
        var window = new Window(stage);
        var panel = new MainPanel(stage);
        panel.addView(new AView());
        panel.addView(new BView());
        panel.addView(new CView());
        panel.addView(new DView());
        panel.addView(new EView());
        panel.addView(new FView());
        panel.addView(new GView());
        panel.setTitle("Java FX");
        window.setContent(panel);
        window.show();
    }
    
    @Override
    public void stop() throws Exception {
        GService.shutDown();
        super.stop();
    }
    public static void main(String[] a) {
        //System.setProperty("quantum.multithreaded", "false");
        launch(a);
    }
}

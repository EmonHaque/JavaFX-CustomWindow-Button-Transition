package templates;

import helpers.Constants;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import model.Person;

public class PersonTemplate extends ListCell<Person> {
    public StringProperty query;
    private PersonVisual visual;
    private Text name;

    public PersonTemplate(StringProperty query) {
        this.query = query;
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        setBackground(null);
        initializeUI();
        itemProperty().addListener(this::onItemChanged);
        hoverProperty().addListener(this::onHover);
    }
   
    private void initializeUI(){
        name = new Text();
        name.setFill(Color.WHITE);
        visual = new PersonVisual();
    }

    private void onHover(ObservableValue<?> o, boolean ov, boolean nv){
        if (nv && !isEmpty()) {
            if(!isSelected())
                setBackground(new Background(new BackgroundFill(Constants.BackgroundColorLight, null, null)));
        } else {
            if(!isSelected())
                setBackground(null);
        }
    }

    private void onItemChanged(ObservableValue<?> o, Person ov, Person nv){
        if(ov != null){
            var hiText = visual.getHiText();
            hiText.clear();
            hiText.query.unbind();
            hiText.query.set("");

            visual.getPhoneText().setText(null);
            name.setText(null);
        }
        if(nv != null){
            var hiText = visual.getHiText();
            hiText.add(name);
            name.setText(nv.name);
            visual.getPhoneText().setText(nv.phone);
            
            hiText.query.set(query.get());
            hiText.query.bind(query);
        }
    }

    @Override
    protected void updateItem(Person item, boolean empty) {
        super.updateItem(item, empty);
        if (empty) {
            setGraphic(null);
        }
        else {
            setGraphic(visual);
            setBackground(isSelected() ? Background.fill(Constants.BackgroundColorLight) : null);
        }
    }
}

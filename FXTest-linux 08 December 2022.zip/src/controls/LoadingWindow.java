package controls;

import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.property.StringProperty;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

public class LoadingWindow extends Stage {
    private double radius = 200;
    private double strokeWidth = 5;
    private Timeline anim;
    public StringProperty messageProperty;

    public LoadingWindow() {
        initStyle(StageStyle.TRANSPARENT);
        double halfStroke = strokeWidth / 2;
        var arc = new Arc(radius, radius, radius - halfStroke, radius - halfStroke, 0, 0);
        arc.setStrokeWidth(strokeWidth);
        arc.setType(ArcType.OPEN);
        arc.setStroke(Color.DODGERBLUE);
        arc.setFill(null);
        arc.setManaged(false);

        var circle = new Circle(radius, Color.BLACK);
        var text = new Text();
        messageProperty = text.textProperty();
        text.setFill(Color.WHITE);
        text.setFont(Font.font(null, 32));

        var stack = new StackPane(circle, text, arc);
        var scene = new Scene(stack);
        stack.setBackground(null);
        scene.setFill(null);
        setScene(scene);
        centerOnScreen();

        var kv = new KeyValue(arc.lengthProperty(), -360, Interpolator.EASE_BOTH);
        var kf = new KeyFrame(Duration.seconds(3.33), kv);

        anim = new Timeline();
        anim.setCycleCount(3);
        anim.getKeyFrames().add(kf);
        anim.play();

        setOnShown(e -> anim.play());
    }

}

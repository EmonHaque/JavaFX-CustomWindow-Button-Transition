package controls.buttons;
import abstracts.ActionButtonBase;
import interfaces.IExecute;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

public class ActionButton extends ActionButtonBase {
    protected IExecute executor;

    public ActionButton(String icon, double size, String tip) {
        super(icon, size, tip);
        setOnMouseClicked(this::onClicked);
    }

    protected void onClicked(MouseEvent e){
        animate(Color.CORAL);
        if(executor != null) executor.execute();
    }
    
    public void setAction(IExecute executor){
        this.executor = executor;
    }
}

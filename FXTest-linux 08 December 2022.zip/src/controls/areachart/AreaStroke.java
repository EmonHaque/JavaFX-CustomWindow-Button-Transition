package controls.areachart;

import java.util.List;

import javafx.scene.paint.Color;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;

public class AreaStroke extends Path {
    List<Double> points;
    MoveTo start;

    public AreaStroke() {
        setStroke(Color.WHITE);
        start = new MoveTo();
    }

    public void setData(List<Double> points) {
        this.points = points;
        getElements().clear();
        getElements().add(start);
        for (int i = 1; i < points.size(); i++) {
            getElements().add(new LineTo());
        }
    }

    public void clear(){
        getElements().clear();
    }

    public void setValue(double width, double height, double yMax) {
        double xGap = width / (points.size() - 1);
        double yFactor = height / yMax;

        double x = 0;
        double y = points.get(0) * yFactor;
        start.setY(y);

        for (int i = 1; i < points.size(); i++) {
            x += xGap;
            y = points.get(i) * yFactor;
            var line = (LineTo) (getElements().get(i));
            line.setX(x);
            line.setY(y);
        }
    }
}

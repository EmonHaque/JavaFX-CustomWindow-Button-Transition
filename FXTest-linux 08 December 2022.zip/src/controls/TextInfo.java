package controls;

import java.util.Timer;
import java.util.TimerTask;

import javafx.animation.ScaleTransition;
import javafx.application.Platform;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class TextInfo extends Text {
    private ScaleTransition anim;
    private boolean hasMessage;
    private Timer timer;

    public TextInfo() {
        setScaleY(0);
        setFill(Color.WHITE);
        anim = new ScaleTransition(Duration.millis(250), this);
        anim.setOnFinished(this::onAnimFinished);
        textProperty().addListener(this::onTextChanged);
    }

    private void onTextChanged(ObservableValue<?> o, String ov, String nv) {
        if (nv != null && !nv.isEmpty()) {
            anim.setToY(1);
            anim.play();
            hasMessage = true;
        }
    }

    private void onAnimFinished(ActionEvent e){
        if(hasMessage){
            clearMessage();
        }
        else{
            setText("");
            timer.cancel();
            timer.purge();
        }
    }

    private void clearMessage(){
        timer = new Timer();
        var task = new TimerTask() {
            @Override
            public void run() {
                Platform.runLater(() ->{
                    anim.setToY(0);
                    anim.play();
                    hasMessage = false;
                });
                
            }
        };
        timer.schedule(task, 5000);
    }
}

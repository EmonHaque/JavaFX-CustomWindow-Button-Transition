package skinned;

import javafx.scene.control.PasswordField;
import javafx.scene.control.Skin;
import skins.ExtendedTextFieldSkin;

public class ExtendedPasswordField extends PasswordField{
    public ExtendedPasswordField() {
        super();
        setBackground(null);
    }
    @Override
    protected Skin<?> createDefaultSkin() {
        return new ExtendedTextFieldSkin(this);
    }
}

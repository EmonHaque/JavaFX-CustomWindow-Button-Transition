package Views.ASubViews;

import abstracts.View;
import controls.areachart.Area;
import javafx.geometry.Insets;
import javafx.scene.layout.BorderPane;
import viewModels.AViewModels.AreaVM;

public class AreaView extends View {
    Area area;
    AreaVM vm;

    @Override
    protected String getHeader() {
        return "Area View";
    }
    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight AreaView");

        vm = new AreaVM();
        area = new Area();
        area.seriesProperty.bind(vm.seriesProperty);
        BorderPane.setMargin(area, new Insets(10,0,0,0));
        setCenter(area);
    }
}

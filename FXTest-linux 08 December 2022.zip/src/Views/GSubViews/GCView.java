package Views.GSubViews;

public class GCView extends GAbstractView {

    @Override
    protected String getName() {
        return "GC";
    }
}

package Views.GSubViews;

public class GBView extends GAbstractView {

    @Override
    protected String getName() {
        return "GB";
    }
}

package Views;
import java.util.ArrayList;
import java.util.List;

import Views.CSubViews.CAView;
import Views.CSubViews.CBView;
import abstracts.View;
import helpers.Constants;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;

public class CView extends View {
    View caView, cbView;

    public CView() {
        super();
        cbView = new CBView();
        caView = new CAView();
        
    }
    @Override
    public List<View> initialViews() {
        super.views = new ArrayList<>();
        views.add(caView);
        views.add(cbView);
        return super.views;
    }
    @Override
    protected String getIcon() {
        return Icons.CCircle;
    }

    @Override
    protected String getTip() {
        return "C View";
    }
    @Override
    public boolean isContainer() {
        return true;
    }
    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight CView");
        var grid = new GridPane();
        var colCon = new ColumnConstraints();
        colCon.setPercentWidth(50);
        grid.getColumnConstraints().addAll(colCon, colCon);
        grid.addColumn(0, caView);
        grid.addColumn(1, cbView);
        GridPane.setVgrow(caView, Priority.ALWAYS);
        grid.setHgap(Constants.CardMargin);
        BorderPane.setMargin(grid, new Insets(Constants.CardMargin));
        setCenter(grid);
    }
}

package Views.ESubViews.EBSubViews;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import abstracts.View;
import controls.SortHeader;
import controls.states.MultiState;
import controls.texts.TextBox;
import helpers.Constants;
import helpers.Icons;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.TreeItem;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import model.Tenant;
import skinned.ExtendedTreeView;
import templates.TenantTemplate2;
import viewModels.EViewModels.EAViewVM;
import viewModels.EViewModels.EBAViewModels.EBAViewVM;

public class EBAView extends View {
    private TextBox query;
    private ExtendedTreeView<Tenant> tree;
    private MultiState primaryState, secondaryState;
    private EBAViewVM vm;

    @Override
    protected String getHeader() {
        return "EBA View";
    }

    @Override
    protected String getIcon() {
        return Icons.ACircle;
    }

    @Override
    protected String getTip() {
        return "EBA View";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight EBA View");

        vm = new EBAViewVM();
        initializeUI();
        bind();
    }

    private void initializeUI() {
        primaryState = new MultiState(new String[] { Icons.Building, Icons.User, Icons.Home }, new String[] { "House", "Tenant", "Space" }, false);
        secondaryState = new MultiState(false);

        addAction(primaryState);
        addAction(secondaryState);

        query = new TextBox("Query", Icons.Magnify);
        tree = new ExtendedTreeView<>();
        //tree.setBackground(null);
        //tree.setPadding(new Insets(0));
        generateTree();
        tree.setCellFactory(v -> new TenantTemplate2());
        var header = getTableHeader();
        var box = new VBox(query, header, tree);
        box.setSpacing(5);
        VBox.setMargin(header, new Insets(0, Constants.ScrollBarSize, 0, 0));
        VBox.setVgrow(tree, Priority.ALWAYS);

        setCenter(box);
    }

    private void bind() {
        vm.primaryStateProperty.bind(primaryState.stateProperty);
        secondaryState.statesProperty.bind(vm.secondaryStatesProperty);
        vm.secondaryStateProperty.bind(secondaryState.stateProperty);
    }

    private Node getTableHeader() {
        var header = new GridPane();
        header.setPadding(new Insets(2, 0, 2, 0));
        var particulars = new SortHeader("Particulars", false, vm::sortParticulars);
        var rent = new SortHeader("Rent", true, vm::sortDue);
        var due = new SortHeader("Due", true, vm::sortRent);

        header.addColumn(0, particulars);
        header.addColumn(1, rent);
        header.addColumn(2, due);
        var cons1 = new ColumnConstraints();
        var cons2 = new ColumnConstraints(100);
        cons1.setHgrow(Priority.ALWAYS);

        header.getColumnConstraints().addAll(cons1, cons2, cons2);
        header.setBorder(Constants.BottomLine);
        GridPane.setHalignment(rent, HPos.RIGHT);
        GridPane.setHalignment(due, HPos.RIGHT);

        return header;
    }

    private void generateTree() {
        var maps = new LinkedHashMap<String, Map<String, List<Tenant>>>();

        for (Tenant house : EAViewVM.tenants) {
            if (maps.containsKey(house.getHouse())) {
                var tenants = maps.get(house.getHouse());
                boolean isFound = false;
                for (var tenant : tenants.keySet()) {
                    if (house.getTenant().equals(tenant)) {
                        tenants.get(tenant).add(house);
                        isFound = true;
                        break;
                    }
                }
                if (!isFound) {
                    var list = new ArrayList<Tenant>();
                    list.add(house);
                    tenants.put(house.getTenant(), list);
                }
            }
            else {
                var subMap = new LinkedHashMap<String, List<Tenant>>();
                var list = new ArrayList<Tenant>();
                list.add(house);
                subMap.put(house.getTenant(), list);
                maps.put(house.getHouse(), subMap);
            }
        }

        var root = new TreeItem<Tenant>();
        for (var x : maps.keySet()) {
            var houseSeries = new Tenant(x, "", "", 0, 0);
            var house = new TreeItem<>(houseSeries);
            var tenants = maps.get(x);

            for (var w : tenants.keySet()) {
                var tenantSeries = new Tenant("", w, "", 0, 0);
                var tenant = new TreeItem<>(tenantSeries);
                var v = tenants.get(w);

                if (v.size() == 1) {
                    var s = v.get(0);
                    tenantSeries.setSpace(s.getSpace());
                    tenantSeries.setDue(s.getDue());
                    tenantSeries.setRent(s.getRent());

                }
                else {
                    for (var u : v) {
                        var space = new TreeItem<>(new Tenant("", "", u.getSpace(), u.getRent(), u.getDue()));
                        int rent = tenantSeries.getRent() + u.getRent();
                        double due = tenantSeries.getDue() + u.getDue();
                        tenantSeries.setRent(rent);
                        tenantSeries.setDue(due);
                        tenant.getChildren().add(space);
                        tenant.setExpanded(true);
                    }

                    int rent = houseSeries.getRent() + tenantSeries.getRent();
                    double due = houseSeries.getDue() + tenantSeries.getDue();
                    houseSeries.setRent(rent);
                    houseSeries.setDue(due);
                    house.getChildren().add(tenant);
                    house.setExpanded(true);
                }
            }
            root.getChildren().add(house);
        }
        tree.setRoot(root);
        tree.setShowRoot(false);
    }
}

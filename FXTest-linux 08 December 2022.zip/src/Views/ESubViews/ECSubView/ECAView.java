package Views.ESubViews.ECSubView;

import abstracts.View;
import controls.buttons.ActionButton;
import controls.texts.TextBox;
import helpers.Icons;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import viewModels.EViewModels.ECAViewModels.ECAViewVM;

public class ECAView extends View {
    TextBox houseText, tenantText, spaceText, rentText, dueText;
    ActionButton edit;
    ECAViewVM vm;

    @Override
    protected String getHeader() {
        return "ECA View";
    }

    @Override
    protected String getIcon() {
        return Icons.ACircle;
    }

    @Override
    protected String getTip() {
        return "ECA View";
    }

    @Override
    public void onFirstSight() {
        super.onFirstSight();
        System.out.println("Lazy onFirstSight ECA View");

        vm = new ECAViewVM();
        initializeUI();

    }

    void initializeUI() {
        houseText = new TextBox("House", Icons.Building);
        tenantText = new TextBox("Tenant", Icons.User);
        spaceText = new TextBox("Space", Icons.Home);
        rentText = new TextBox("Rent", Icons.Transact);
        dueText = new TextBox("Due", Icons.Transact);
        edit = new ActionButton(Icons.Edit, 16, "edit");

        var amountBox = new HBox(rentText, dueText);
        HBox.setHgrow(rentText, Priority.ALWAYS);
        HBox.setHgrow(dueText, Priority.ALWAYS);
        amountBox.setSpacing(10);

        var box = new VBox(houseText, tenantText, spaceText, amountBox, edit);
        box.setAlignment(Pos.CENTER_RIGHT);
        box.setSpacing(5);
        box.setPadding(new Insets(5, 0, 0, 0));
        VBox.setMargin(edit, new Insets(10, 0, 0, 0));
        setCenter(box);
    }
}

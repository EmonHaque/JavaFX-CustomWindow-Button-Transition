package viewModels.FViewModels;

import java.io.FileWriter;
import java.io.IOException;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.stage.FileChooser;

public class FABViewVM {
    public StringProperty contentProperty, messageProperty;

    public FABViewVM() {
        contentProperty = new SimpleStringProperty();
        messageProperty = new SimpleStringProperty();
    }

    public void save() {
        var content = contentProperty.get();
        if(content.isBlank() || content.isEmpty()){
            messageProperty.set("add some text");
            return;
        }
        var chooser = new FileChooser();
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text file", "*.txt"));
        var file = chooser.showSaveDialog(null);
        if (file != null) {
            try (var writer = new FileWriter(file)) {
                writer.write(contentProperty.get());
                messageProperty.set("saved successfully!");
            }
            catch (IOException e) {
                e.printStackTrace();
                messageProperty.set("error saving file!");
            }
        }
    }

    
}

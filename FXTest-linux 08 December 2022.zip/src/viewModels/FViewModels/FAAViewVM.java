package viewModels.FViewModels;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.image.Image;
import javafx.stage.FileChooser;
import model.ImageFile;

public class FAAViewVM {
    public ObservableList<ImageFile> imageList;
    public ObjectProperty<ImageFile> selectedFile;
    public ObjectProperty<Image> selectedImage;

    public FAAViewVM() {
        imageList = FXCollections.observableArrayList();
        selectedFile = new SimpleObjectProperty<>();
        selectedImage = new SimpleObjectProperty<>();

        selectedFile.addListener((o, ov, nv) -> {
            // var image = new Image(new File(nv.getPath()).toURI().toString());
            var image = new Image("file:" + nv.getPath());
            selectedImage.set(image);
        });
    }

    public void openFolder() {
        var chooser = new FileChooser();
        chooser.setTitle("Select files");
        chooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("JPEG Files", "*.jpg"),
                new FileChooser.ExtensionFilter("PNG Files", "*.png"));
        var files = chooser.showOpenMultipleDialog(null);

        if (files == null)
            return;

        for (var file : files) {
            imageList.add(new ImageFile(file.getName(), file.getAbsolutePath(), file.length()));
        }
        
        if(selectedFile.get() == null){
            selectedFile.set(imageList.get(0));
        }
    }

    public void removeFile(ImageFile file){
        imageList.remove(file);   
    }
}

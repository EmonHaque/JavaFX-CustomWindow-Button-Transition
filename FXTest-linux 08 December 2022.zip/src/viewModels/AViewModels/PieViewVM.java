package viewModels.AViewModels;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import model.PieSeries;

public class PieViewVM {
    private char alps[] = {'A', 'B', 'C', 'D', 'E', 'F', 'G'};
    private List<PieSeries> series;
    public ObjectProperty<List<PieSeries>> seriesProperty;
    public static ObjectProperty<PieSeries> selectedSliceProperty;

    public PieViewVM() {
        series = new ArrayList<>();
        series.add(new PieSeries("A Title", 100));
        series.add(new PieSeries("B Title", 70));
        series.add(new PieSeries("C Title", 50));
        series.add(new PieSeries("D Title", 120));
        series.add(new PieSeries("E Title", 20));
        seriesProperty = new SimpleObjectProperty<>(series);
        selectedSliceProperty = new SimpleObjectProperty<>();
        selectedSliceProperty.addListener(this::onSelectionChange);
    }

    public void generateSeries(){
        series = new ArrayList<>();
        var rand = new Random();
        int size = rand.nextInt(4) + 3;
        for(int i = 0; i < size; i++){
            series.add(new PieSeries(alps[i] + " Title", rand.nextInt(100) + 20));
        }
        seriesProperty.set(series);
    }

    private void onSelectionChange(ObservableValue<?> o, PieSeries ov, PieSeries nv){
        System.out.println("Old: " + ov + " New " + nv);
    }
}

package viewModels.AViewModels;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import model.PinColumnSeries;

public class PinColumnViewVM {
    private List<PinColumnSeries> series;
    public ObjectProperty<List<PinColumnSeries>> seriesProperty;

    public PinColumnViewVM() {
        series = List.of(
            new PinColumnSeries(100, 200),
            new PinColumnSeries(200, 100),
            new PinColumnSeries(100, 100),
            new PinColumnSeries(75, 50),
            new PinColumnSeries(40, 60)
        );
        seriesProperty = new SimpleObjectProperty<>(series);
        
        PieViewVM.selectedSliceProperty.addListener((o, ov, nv) ->{
            series = nv == null ? null : getSeries();
            seriesProperty.set(series);
        });
    }

    private ArrayList<PinColumnSeries> getSeries(){
        var list = new ArrayList<PinColumnSeries>();
        var rand = new Random();
        int size = rand.nextInt(7) + 8;
        for(int i = 0; i < size; i++){
            list.add(new PinColumnSeries(rand.nextDouble(100) + 50, rand.nextDouble(100) + 50));
        }
        return list;
    }
}
